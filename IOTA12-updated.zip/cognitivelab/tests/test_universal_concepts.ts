import { UniversalConceptEngine } from '../src/dsl/universalConceptEngine';

const testPrompts = [
  "Press F for Car and D for Cake",
  "Press 1 for Happy and 2 for Sad",
  "Show lion vs tiger, press L for lion and T for tiger",
  "Categorize weapons vs tools with J and K",
  "Rock (1), Paper (2), Scissors (3)",
  "Show doctor and firefighter, press D or F",
  "Go No-Go: press space for Rocket, withhold for Asteroid",
  "Compare apple vs banana",
  "If you see Sword press S, if Shield press K"
];

for (const p of testPrompts) {
  const result = UniversalConceptEngine.parseConceptsAndKeys(p);
  console.log(`\nPROMPT: "${p}"`);
  console.log(`EXTRACTED ${result.length} CONCEPTS:`, result.map(c => `${c.displayText} [key: ${c.key}]`));
}
