// Prototype test for Universal Semantic Parser concepts
import { EMOJI_DICTIONARY, getEmojiForWord } from '../src/dsl/semanticParser';

const testPrompts = [
  "Press F for Car and D for Cake",
  "Press 1 for Happy and 2 for Sad",
  "Show lion vs tiger, press L for lion and T for tiger",
  "Categorize weapons vs tools with J and K",
  "Rock (1), Paper (2), Scissors (3)",
  "Show doctor and firefighter, press D or F",
  "Go No-Go: press space for Rocket, withhold for Asteroid",
  "Compare apple vs banana",
  "Create a reaction game"
];

console.log("Ready to build Universal Parser testing...");
