import { TrialRecord, SessionCalibration } from '../types/dsl';

const DB_NAME = 'CognitiveLab_OfflineDB';
const DB_VERSION = 1;
const TRIALS_STORE = 'buffered_trials';
const SESSIONS_STORE = 'sessions';
const FALLBACK_KEY = 'cl_offline_trials_backup';

export class LocalExperimentStorage {
  private static dbPromise: Promise<IDBDatabase> | null = null;

  private static getDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      try {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(TRIALS_STORE)) {
            const store = db.createObjectStore(TRIALS_STORE, { keyPath: 'id' });
            store.createIndex('sessionId', 'sessionId', { unique: false });
            store.createIndex('trialIndex', 'trialIndex', { unique: false });
          }
          if (!db.objectStoreNames.contains(SESSIONS_STORE)) {
            db.createObjectStore(SESSIONS_STORE, { keyPath: 'sessionId' });
          }
        };

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      } catch (err) {
        reject(err);
      }
    });

    return this.dbPromise;
  }

  public static async bufferTrial(trial: TrialRecord): Promise<void> {
    // 1. Always write to synchronous backup first for guaranteed zero-loss
    try {
      const existing: TrialRecord[] = JSON.parse(localStorage.getItem(FALLBACK_KEY) || '[]');
      const filtered = existing.filter(t => t.id !== trial.id);
      filtered.push(trial);
      localStorage.setItem(FALLBACK_KEY, JSON.stringify(filtered));
    } catch (e) {
      console.warn('LocalStorage backup error', e);
    }

    // 2. Commit to IndexedDB
    try {
      const db = await this.getDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(TRIALS_STORE, 'readwrite');
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.objectStore(TRIALS_STORE).put(trial);
      });
    } catch (e) {
      console.warn('IndexedDB write deferred, using local backup', e);
    }

    // Notify listeners
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('cognitivelab_data_updated'));
    }
  }

  public static async getAllStoredTrials(): Promise<TrialRecord[]> {
    // Try IndexedDB first
    try {
      const db = await this.getDB();
      const idbTrials = await new Promise<TrialRecord[]>((resolve) => {
        const tx = db.transaction(TRIALS_STORE, 'readonly');
        const store = tx.objectStore(TRIALS_STORE);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve([]);
      });

      if (idbTrials.length > 0) return idbTrials;
    } catch {
      // Fallback
    }

    // Fallback to localStorage backup
    try {
      return JSON.parse(localStorage.getItem(FALLBACK_KEY) || '[]');
    } catch {
      return [];
    }
  }

  public static async saveCalibration(calib: SessionCalibration): Promise<void> {
    try {
      const db = await this.getDB();
      const tx = db.transaction(SESSIONS_STORE, 'readwrite');
      tx.objectStore(SESSIONS_STORE).put(calib);
    } catch {
      localStorage.setItem(`cl_calib_${calib.sessionId}`, JSON.stringify(calib));
    }
  }

  public static async clearAll(): Promise<void> {
    try {
      const db = await this.getDB();
      const tx = db.transaction([TRIALS_STORE, SESSIONS_STORE], 'readwrite');
      tx.objectStore(TRIALS_STORE).clear();
      tx.objectStore(SESSIONS_STORE).clear();
    } catch {
      // Ignore
    }
    localStorage.removeItem(FALLBACK_KEY);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('cognitivelab_data_updated'));
    }
  }
}
