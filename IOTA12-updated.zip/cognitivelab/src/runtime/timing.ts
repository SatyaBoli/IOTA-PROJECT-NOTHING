export class HighPrecisionTimer {
  /**
   * Captures sub-millisecond DOM high-resolution time
   */
  public static now(): number {
    return performance.now();
  }

  /**
   * Measures screen refresh rate and frame-to-frame delta stability over N frames
   */
  public static async benchmarkDisplay(sampleFrames = 120): Promise<{
    refreshHz: number;
    jitterStdMs: number;
    isStable: boolean;
    deltas: number[];
  }> {
    return new Promise((resolve) => {
      const deltas: number[] = [];
      let lastTime: number | null = null;
      let frameCount = 0;

      const step = (timestamp: number) => {
        if (lastTime !== null) {
          const delta = timestamp - lastTime;
          deltas.push(delta);
        }
        lastTime = timestamp;
        frameCount++;

        if (frameCount < sampleFrames) {
          requestAnimationFrame(step);
        } else {
          // Analyze frame deltas
          const sum = deltas.reduce((a, b) => a + b, 0);
          const meanDelta = sum / deltas.length;
          const refreshHz = Math.round(1000 / meanDelta);

          // Standard deviation
          const variance =
            deltas.reduce((acc, d) => acc + Math.pow(d - meanDelta, 2), 0) /
            deltas.length;
          const jitterStdMs = Math.sqrt(variance);

          // If standard deviation > 4ms, display scheduling is erratic
          const isStable = jitterStdMs < 4.0;

          resolve({
            refreshHz,
            jitterStdMs: parseFloat(jitterStdMs.toFixed(3)),
            isStable,
            deltas,
          });
        }
      };

      requestAnimationFrame(step);
    });
  }

  /**
   * Synchronizes an action to the next display V-Sync window
   */
  public static waitForVSync(): Promise<number> {
    return new Promise((resolve) => {
      requestAnimationFrame((timestamp) => {
        resolve(timestamp);
      });
    });
  }
}
