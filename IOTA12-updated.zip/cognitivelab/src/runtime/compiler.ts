import { ExperimentDSL, DSLNode, ResponseType, BranchRule, GameSkinTheme, ExperimentPlan } from '../types/dsl';
import { FactorialEngine, BalancedTrialItem, Mulberry32 } from '../dsl/randomization';
import { assetService } from '../services/assets/AssetService';

export interface CompiledTrialItem extends BalancedTrialItem {
  trialIndex: number;
  templateId?: string;
  questionText?: string;
  responseType: ResponseType;
  responseOptions?: string[];
  scaleMin?: number;
  scaleMax?: number;
  scaleLabels?: { min: string; max: string; mid?: string };
  expectedValue?: string | number | null;
  branching?: BranchRule[];
  conditionVariables?: Record<string, any>;
  assetSource?: string;
  visualScale?: number;
  primaryEmoji?: string;
  secondaryEmoji?: string;
}

export interface CompiledExperiment {
  title: string;
  ethicsProtocolId: string;
  consentStatement: string;
  requireCheckbox: boolean;
  minAge: number;
  instructionTitle: string;
  instructionContent: string;
  continueButtonText: string;
  allowedKeys: string[];
  responseDeadlineMs: number;
  fixationDurationMs: number;
  fixationJitterMs: number;
  itiDurationMs: number;
  trials: CompiledTrialItem[];
  gameSkinEnabled: boolean;
  theme: GameSkinTheme;
  soundEnabled: boolean;
  scoreRules: {
    basePoints: number;
    streakMultiplier: number;
  };
  debriefTitle: string;
  debriefContent: string;
  plan?: ExperimentPlan;
}

export class ExperimentCompiler {
  public static compile(dsl: ExperimentDSL, sessionSeed: number): CompiledExperiment {
    // 1. Locate presentation, instruction, and debrief nodes
    const consentNode = dsl.nodes.find(n => n.type === 'presentation_text' && (n.id.includes('consent') || n.label.toLowerCase().includes('consent')));
    const instructionNode = dsl.nodes.find(n => n.type === 'presentation_text' && (n.id.includes('instruction') || n.label.toLowerCase().includes('instruction') || n.label.toLowerCase().includes('briefing')));
    const debriefNode = dsl.nodes.find(n => n.type === 'presentation_text' && (n.id.includes('debrief') || n.label.toLowerCase().includes('debrief') || n.label.toLowerCase().includes('accomplished')));

    const randomizationNode = dsl.nodes.find(n => n.type === 'randomization_balanced_block');
    const trialBlockNode = dsl.nodes.find(n => n.type === 'trial_template_block');
    const fixationNode = dsl.nodes.find(n => n.type === 'presentation_fixation');
    const responseNode = dsl.nodes.find(n => n.type === 'response_keyboard' || n.type === 'response_multimodal');
    const rewardNode = dsl.nodes.find(n => n.type === 'game_reward' && (n.id.includes('correct') || (n.config.points && n.config.points > 0)));
    const itiNode = dsl.nodes.find(n => n.type === 'timing_wait');

    const prng = new Mulberry32(sessionSeed);
    let compiledTrials: CompiledTrialItem[] = [];

    // PATH A: Scalable Template & Condition Tree Compilation
    const hasTemplates = (dsl.trial_templates && dsl.trial_templates.length > 0) || (trialBlockNode && trialBlockNode.config.templates?.length > 0);
    const hasConditions = (dsl.conditions && dsl.conditions.length > 0) || (trialBlockNode && trialBlockNode.config.conditions?.length > 0);

    if (hasTemplates && hasConditions) {
      const templates = dsl.trial_templates || trialBlockNode?.config.templates || [];
      const conditions = dsl.conditions || trialBlockNode?.config.conditions || [];
      const totalTrials = dsl.plan?.randomization.total_trials || trialBlockNode?.config.randomization?.total_trials || dsl.variables?.total_trials?.default || 30;

      const rawPool: CompiledTrialItem[] = [];
      const cellsCount = Math.max(conditions.length * templates.length, 1);
      const reps = Math.max(Math.ceil(totalTrials / cellsCount), 1);

      for (let r = 0; r < reps; r++) {
        for (const cond of conditions) {
          for (const tmpl of templates) {
            // Variable interpolation helper
            const resolveVar = (text: string) => {
              let res = text;
              Object.entries(cond.variables || {}).forEach(([k, v]) => {
                res = res.replace(new RegExp(`{{${k}}}`, 'g'), String(v));
              });
              res = res.replace(/{{label}}/g, cond.label);
              res = res.replace(/{{condition}}/g, cond.id);
              return res;
            };

            const questionText = resolveVar(tmpl.question_template);
            const stimulusValue = resolveVar(tmpl.stimulus_template);
            const emoji = cond.variables?.primary_emoji || cond.variables?.emoji || assetService.getEmojiSync(cond.stimulus_ref?.asset_id || cond.variables?.concept || cond.id);
            const rawExpectedValue = tmpl.correct_value_rule
              ? resolveVar(tmpl.correct_value_rule)
              : cond.variables?.correct_answer;

            // Determine expected key / value
            let expectedKey = cond.variables?.expected_key || 'a';
            if (tmpl.response_type === 'true_false_unknown') {
              expectedKey = '1'; // 1 = True, 2 = False, 3 = Unknown
            } else if (tmpl.response_type === 'rating_scale') {
              expectedKey = '3';
            }

            rawPool.push({
              trialIndex: rawPool.length + 1,
              templateId: tmpl.id,
              condition: cond.id,
              conditionVariables: cond.variables || {},
              stimulusType: 'text',
              stimulusValue,
              stimulusText: emoji ? `${emoji}  ${cond.label}` : cond.label,
              hexColor: cond.variables?.visual_scale ? '#34d399' : '#38bdf8',
              expectedKey: String(expectedKey).toLowerCase(),
              factorState: cond.variables || {},
              questionText,
              responseType: tmpl.response_type,
              expectedValue: rawExpectedValue === undefined || rawExpectedValue === null ? null : String(rawExpectedValue),
              responseOptions: tmpl.response_options ? [...tmpl.response_options] : undefined,
              scaleMin: tmpl.scale_min,
              scaleMax: tmpl.scale_max,
              scaleLabels: tmpl.scale_labels,
              branching: tmpl.branching ? [...tmpl.branching] : undefined,
              assetSource: cond.stimulus_ref ? `${cond.stimulus_ref.provider}:${cond.stimulus_ref.asset_id}` : 'asset_service:local',
              visualScale: cond.variables?.visual_scale || 1.0,
              primaryEmoji: emoji,
              secondaryEmoji: cond.variables?.secondary_emoji
            });
          }
        }
      }

      // Seeded deterministic shuffle
      let shuffled = prng.shuffle(rawPool).slice(0, totalTrials);
      // Re-index trials sequentially 1..N
      shuffled.forEach((t, i) => { t.trialIndex = i + 1; });
      compiledTrials = shuffled;
    } else {
      // PATH B: Legacy Factorial Block (Backward Compatibility)
      const baseTrials = FactorialEngine.generateBalancedBlock(
        randomizationNode ? randomizationNode.config : {},
        prng
      );

      compiledTrials = baseTrials.map((bt, i) => ({
        ...bt,
        trialIndex: i + 1,
        responseType: 'keyboard_reaction',
        assetSource: 'legacy_factorial_block'
      }));
    }

    // Extract allowed keys
    let allowedKeys: string[] = ['a', 'l'];
    if (responseNode?.config.allowed_keys) {
      allowedKeys = responseNode.config.allowed_keys.map((k: string) => String(k).toLowerCase());
    } else if (hasTemplates) {
      // For multimodal / questions, allow number keys 1-5, T, F, U, space
      allowedKeys = ['1', '2', '3', '4', '5', 't', 'f', 'u', 'a', 'd', 'j', 'k', 'l', 'space'];
    }

    const theme = dsl.game_skin.theme || (dsl.plan?.presentation_skin) || 'academic-clean';

    return {
      title: dsl.experiment.title || 'Cognitive Experiment',
      ethicsProtocolId: dsl.consent_settings.ethics_protocol_id || 'IRB-UNSPECIFIED',
      consentStatement: dsl.consent_settings.statement_text || (consentNode?.config.content_markdown || 'Participation is voluntary and anonymous.'),
      requireCheckbox: dsl.consent_settings.require_checkbox ?? true,
      minAge: dsl.consent_settings.minimum_age ?? 18,
      instructionTitle: instructionNode?.config.title || 'Study Instructions',
      instructionContent: instructionNode?.config.content_markdown || 'Respond to stimuli as rapidly and accurately as possible.',
      continueButtonText: instructionNode?.config.continue_button_text || 'Begin Experiment',
      allowedKeys,
      responseDeadlineMs: responseNode?.config.deadline_ms || 3000,
      fixationDurationMs: fixationNode?.config.duration_ms || 400,
      fixationJitterMs: fixationNode?.config.jitter_ms || 100,
      itiDurationMs: itiNode?.config.duration_ms || 300,
      trials: compiledTrials,
      gameSkinEnabled: dsl.game_skin.enabled,
      theme,
      soundEnabled: dsl.game_skin.sound_enabled ?? true,
      scoreRules: {
        basePoints: rewardNode?.config.points || dsl.game_skin.score_rules?.correct_base_points || 100,
        streakMultiplier: dsl.game_skin.score_rules?.streak_bonus_multiplier || 1.25,
      },
      debriefTitle: debriefNode?.config.title || 'Session Complete',
      debriefContent: debriefNode?.config.content_markdown || 'Thank you for your scientific participation!',
      plan: dsl.plan
    };
  }
}
