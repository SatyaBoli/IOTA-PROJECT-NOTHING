import { ExperimentDSL, DSLNode, DSLEdge } from '../types/dsl';
import { defaultExperimentDSL } from '../dsl/defaultExperiment';
import { ExperimentPlanner } from '../dsl/experimentPlanner';

const EXPERIMENTS_STORAGE_KEY = 'cognitivelab_saved_experiments';
const ACTIVE_EXP_ID_KEY = 'cognitivelab_active_experiment_id';

// Curated Canonical Experiment Library
const treePerceptionDemo = ExperimentPlanner.planExperiment(
  'Create a tree perception survey with 18 trials. Show small, medium, and large trees. Ask whether each tree is larger than average, ask participants to classify its size, and ask them to rate how safe it feels on a 1 to 5 scale.'
).dsl;
treePerceptionDemo.experiment.id = 'exp_tree_perception_demo';
treePerceptionDemo.experiment.slug = 'tree-size-safety-perception';
treePerceptionDemo.experiment.title = 'Tree Size & Safety Perception Survey';
treePerceptionDemo.experiment.description = 'A non-speeded example study with categorical, uncertainty, and 1–5 rating responses.';
treePerceptionDemo.experiment.author = {
  user_id: 'cognitivelab_demo',
  institution: 'CognitiveLab Example Library'
};

export const canonicalExperiments: ExperimentDSL[] = [
  // 1. Default Space Orbit Reaction Task
  defaultExperimentDSL,

  // 2. Non-reaction-time template demonstrating choice, uncertainty, and ratings
  treePerceptionDemo,

  // 2. Classic Stroop Color-Word Conflict
  {
    $schema: "https://cognitivelab.io/schemas/v1/experiment.json",
    experiment: {
      id: 'exp_stroop_canonical',
      slug: 'stroop-color-word-conflict',
      version: 2,
      title: 'Stroop Color-Word Interference Task',
      description: 'Cognitive control task measuring semantic interference between printed color word and display ink hue.',
      created_at: '2026-03-01T00:00:00.000Z',
      author: {
        user_id: 'usr_researcher_demo',
        institution: 'Laboratory for Cognitive & Behavioral Science'
      },
      reproducibility: {
        dsl_version: '1.0.0',
        target_runtime: 'jspsych-7.3.4'
      }
    },
    participant_settings: {
      allow_anonymous: true,
      enforce_fullscreen: true,
      minimum_display_hz: 58,
      device_allowlist: ['desktop', 'laptop'],
      required_inputs: ['keyboard']
    },
    consent_settings: {
      required: true,
      statement_text: 'Participation is voluntary and anonymous. You will respond to the ink color of presented words.',
      require_checkbox: true,
      minimum_age: 18,
      ethics_protocol_id: 'IRB-2026-STROOP'
    },
    variables: {
      total_score: { type: 'number', default: 0, scope: 'global' }
    },
    game_skin: {
      enabled: false,
      theme: 'academic-clean',
      sound_enabled: true,
      hud_elements: {
        show_score: true,
        show_streak: true,
        show_progress_bar: true
      },
      score_rules: { correct_base_points: 100, streak_bonus_multiplier: 1.25, incorrect_penalty: 0, max_rt_for_bonus_ms: 450 }
    },
    nodes: [
      { id: 'n_start', type: 'flow_start', label: 'Start', config: {}, position: { x: 50, y: 180 } },
      { id: 'n_consent', type: 'presentation_text', label: 'Informed Consent', config: { title: 'IRB Ethics Consent', content_markdown: 'Respond strictly to the **INK COLOR** of the words.', continue_button_text: 'I Agree & Proceed' }, position: { x: 260, y: 180 } },
      { id: 'n_calibration', type: 'timing_calibration', label: 'Display Calibration', config: { measure_fps_frames: 120, reject_frame_jitter_ms: 8 }, position: { x: 480, y: 180 } },
      { id: 'n_instruction', type: 'presentation_text', label: 'Stroop Briefing', config: { title: 'Task Instructions', content_markdown: '* If ink is **RED**, press **R**\n* If ink is **BLUE**, press **B**\n\nIgnore the written word text!', continue_button_text: 'Begin Stroop Trials' }, position: { x: 700, y: 180 } },
      { id: 'n_generator', type: 'randomization_balanced_block', label: 'Stroop Matrix', config: {
        factors: [{
          name: 'congruency',
          levels: [
            { value: 'congruent_red', metadata: { hex: '#ef4444', text: 'RED', expected_key: 'r', type: 'word_ink' } },
            { value: 'incongruent_blue_word_red', metadata: { hex: '#ef4444', text: 'BLUE', expected_key: 'r', type: 'word_ink' } },
            { value: 'congruent_blue', metadata: { hex: '#3b82f6', text: 'BLUE', expected_key: 'b', type: 'word_ink' } },
            { value: 'incongruent_red_word_blue', metadata: { hex: '#3b82f6', text: 'RED', expected_key: 'b', type: 'word_ink' } }
          ]
        }],
        total_trials: 32,
        repetitions_per_level: 8,
        max_consecutive_identical: 2,
        prng_algorithm: 'mulberry32'
      }, position: { x: 920, y: 180 } },
      { id: 'n_loop', type: 'logic_loop', label: 'Trial Loop (32)', config: { max_iterations: 32 }, position: { x: 1140, y: 180 } },
      { id: 'n_fixation', type: 'presentation_fixation', label: 'Fixation Cross', config: { duration_ms: 500, jitter_ms: 150 }, position: { x: 1360, y: 120 } },
      { id: 'n_stimulus', type: 'presentation_stimulus', label: 'Color-Word Stimulus', config: { stimulus_type: 'word_ink', duration_max_ms: 2000 }, position: { x: 1580, y: 120 } },
      { id: 'n_response', type: 'response_keyboard', label: 'Keyboard (R/B)', config: { allowed_keys: ['r', 'b'], deadline_ms: 2000, record_rt: true }, position: { x: 1800, y: 120 } },
      { id: 'n_condition', type: 'logic_condition', label: 'Evaluate Accuracy', config: {}, position: { x: 2020, y: 120 } },
      { id: 'n_reward', type: 'game_reward', label: '+100 Hit', config: { points: 100 }, position: { x: 2240, y: 60 } },
      { id: 'n_penalty', type: 'game_reward', label: 'Error Feedback', config: { points: 0 }, position: { x: 2240, y: 180 } },
      { id: 'n_iti', type: 'timing_wait', label: 'Inter-Trial Interval', config: { duration_ms: 400 }, position: { x: 2460, y: 120 } },
      { id: 'n_debrief', type: 'presentation_text', label: 'Debriefing', config: { title: 'Session Complete', content_markdown: 'Thank you! Stroop conflict trials completed.' }, position: { x: 2680, y: 180 } },
      { id: 'n_end', type: 'flow_end', label: 'End Session', config: {}, position: { x: 2900, y: 180 } }
    ],
    edges: [
      { id: 'e1', from: 'n_start', to: 'n_consent' },
      { id: 'e2', from: 'n_consent', to: 'n_calibration' },
      { id: 'e3', from: 'n_calibration', to: 'n_instruction' },
      { id: 'e4', from: 'n_instruction', to: 'n_generator' },
      { id: 'e5', from: 'n_generator', to: 'n_loop' },
      { id: 'e6', from: 'n_loop', to: 'n_fixation' },
      { id: 'e7', from: 'n_fixation', to: 'n_stimulus' },
      { id: 'e8', from: 'n_stimulus', to: 'n_response' },
      { id: 'e9', from: 'n_response', to: 'n_condition' },
      { id: 'e10', from: 'n_condition', to: 'n_reward' },
      { id: 'e11', from: 'n_condition', to: 'n_penalty' },
      { id: 'e12', from: 'n_reward', to: 'n_iti' },
      { id: 'e13', from: 'n_penalty', to: 'n_iti' },
      { id: 'e14', from: 'n_iti', to: 'n_debrief' },
      { id: 'e15', from: 'n_debrief', to: 'n_end' }
    ]
  },

  // 3. Spatial Grid Working Memory Task
  {
    $schema: "https://cognitivelab.io/schemas/v1/experiment.json",
    experiment: {
      id: 'exp_spatial_grid_001',
      slug: 'spatial-grid-working-memory',
      version: 1,
      title: 'Spatial Grid Working Memory Span',
      description: 'Visuospatial working memory task evaluating location retention across a 3x3 matrix.',
      created_at: '2026-03-01T00:00:00.000Z',
      author: {
        user_id: 'usr_researcher_demo',
        institution: 'Laboratory for Cognitive & Behavioral Science'
      },
      reproducibility: {
        dsl_version: '1.0.0',
        target_runtime: 'jspsych-7.3.4'
      }
    },
    participant_settings: {
      allow_anonymous: true,
      enforce_fullscreen: true,
      minimum_display_hz: 58,
      device_allowlist: ['desktop', 'laptop'],
      required_inputs: ['keyboard']
    },
    consent_settings: {
      required: true,
      statement_text: 'Participation is voluntary. You will observe illuminated tiles on a 3x3 spatial grid and verify target locations.',
      require_checkbox: true,
      minimum_age: 18,
      ethics_protocol_id: 'IRB-2026-SPATIAL'
    },
    variables: {
      total_score: { type: 'number', default: 0, scope: 'global' }
    },
    game_skin: {
      enabled: true,
      theme: 'deep-space-arcade',
      sound_enabled: true,
      hud_elements: {
        show_score: true,
        show_streak: true,
        show_progress_bar: true
      },
      score_rules: { correct_base_points: 150, streak_bonus_multiplier: 1.5, incorrect_penalty: 0, max_rt_for_bonus_ms: 600 }
    },
    nodes: [
      { id: 'n_start', type: 'flow_start', label: 'Start', config: {}, position: { x: 50, y: 180 } },
      { id: 'n_consent', type: 'presentation_text', label: 'Spatial Consent', config: { title: 'Spatial Memory Study', content_markdown: 'Remember which square on the 3x3 grid illuminates.', continue_button_text: 'Proceed' }, position: { x: 260, y: 180 } },
      { id: 'n_calibration', type: 'timing_calibration', label: 'V-Sync Sync', config: { measure_fps_frames: 120, reject_frame_jitter_ms: 8 }, position: { x: 480, y: 180 } },
      { id: 'n_instruction', type: 'presentation_text', label: 'Spatial Briefing', config: { title: 'Spatial Grid Rules', content_markdown: 'A 3x3 grid will appear with one highlighted tile.\n\n* If highlighted tile is on the **LEFT** (Cols 1-2), press **Z**\n* If highlighted tile is on the **RIGHT** (Col 3), press **M**\n\nKeep visual fixation at center!', continue_button_text: 'Start Spatial Task' }, position: { x: 700, y: 180 } },
      { id: 'n_generator', type: 'randomization_balanced_block', label: 'Grid Coordinate Matrix', config: {
        factors: [{
          name: 'spatial_location',
          levels: [
            { value: 'grid_top_left', metadata: { hex: '#38bdf8', text: 'GRID (1,1) TOP-LEFT', expected_key: 'z', type: 'spatial_grid', gridRow: 0, gridCol: 0 } },
            { value: 'grid_center', metadata: { hex: '#38bdf8', text: 'GRID (2,2) CENTER', expected_key: 'z', type: 'spatial_grid', gridRow: 1, gridCol: 1 } },
            { value: 'grid_bottom_left', metadata: { hex: '#38bdf8', text: 'GRID (3,1) BOTTOM-LEFT', expected_key: 'z', type: 'spatial_grid', gridRow: 2, gridCol: 0 } },
            { value: 'grid_top_right', metadata: { hex: '#f43f5e', text: 'GRID (1,3) TOP-RIGHT', expected_key: 'm', type: 'spatial_grid', gridRow: 0, gridCol: 2 } },
            { value: 'grid_bottom_right', metadata: { hex: '#f43f5e', text: 'GRID (3,3) BOTTOM-RIGHT', expected_key: 'm', type: 'spatial_grid', gridRow: 2, gridCol: 2 } }
          ]
        }],
        total_trials: 30,
        repetitions_per_level: 6,
        max_consecutive_identical: 2,
        prng_algorithm: 'mulberry32'
      }, position: { x: 920, y: 180 } },
      { id: 'n_loop', type: 'logic_loop', label: 'Trial Loop (30)', config: { max_iterations: 30 }, position: { x: 1140, y: 180 } },
      { id: 'n_fixation', type: 'presentation_fixation', label: 'Center Cross', config: { duration_ms: 600, jitter_ms: 150 }, position: { x: 1360, y: 120 } },
      { id: 'n_stimulus', type: 'presentation_stimulus', label: '3x3 Matrix Flash', config: { stimulus_type: 'spatial_grid', duration_max_ms: 2200 }, position: { x: 1580, y: 120 } },
      { id: 'n_response', type: 'response_keyboard', label: 'Spatial Response', config: { allowed_keys: ['z', 'm'], deadline_ms: 2200, record_rt: true }, position: { x: 1800, y: 120 } },
      { id: 'n_condition', type: 'logic_condition', label: 'Check Accuracy', config: {}, position: { x: 2020, y: 120 } },
      { id: 'n_reward', type: 'game_reward', label: '+150 Hit', config: { points: 150 }, position: { x: 2240, y: 60 } },
      { id: 'n_penalty', type: 'game_reward', label: 'Spatial Error', config: { points: 0 }, position: { x: 2240, y: 180 } },
      { id: 'n_iti', type: 'timing_wait', label: 'Inter-Trial Interval', config: { duration_ms: 450 }, position: { x: 2460, y: 120 } },
      { id: 'n_debrief', type: 'presentation_text', label: 'Debriefing', config: { title: 'Spatial Task Accomplished', content_markdown: 'Spatial matrix working memory session completed successfully.' }, position: { x: 2680, y: 180 } },
      { id: 'n_end', type: 'flow_end', label: 'Session Complete', config: {}, position: { x: 2900, y: 180 } }
    ],
    edges: [
      { id: 'e1', from: 'n_start', to: 'n_consent' },
      { id: 'e2', from: 'n_consent', to: 'n_calibration' },
      { id: 'e3', from: 'n_calibration', to: 'n_instruction' },
      { id: 'e4', from: 'n_instruction', to: 'n_generator' },
      { id: 'e5', from: 'n_generator', to: 'n_loop' },
      { id: 'e6', from: 'n_loop', to: 'n_fixation' },
      { id: 'e7', from: 'n_fixation', to: 'n_stimulus' },
      { id: 'e8', from: 'n_stimulus', to: 'n_response' },
      { id: 'e9', from: 'n_response', to: 'n_condition' },
      { id: 'e10', from: 'n_condition', to: 'n_reward' },
      { id: 'e11', from: 'n_condition', to: 'n_penalty' },
      { id: 'e12', from: 'n_reward', to: 'n_iti' },
      { id: 'e13', from: 'n_penalty', to: 'n_iti' },
      { id: 'e14', from: 'n_iti', to: 'n_debrief' },
      { id: 'e15', from: 'n_debrief', to: 'n_end' }
    ]
  },

  // 4. Food Evaluative Choice Task
  {
    $schema: "https://cognitivelab.io/schemas/v1/experiment.json",
    experiment: {
      id: 'exp_food_canonical',
      slug: 'food-evaluative-preference',
      version: 1,
      title: 'Food Evaluative Choice & Decision Latency',
      description: 'Appetitive decision paradigm measuring micro-latencies across high-caloric fast food vs healthy greens.',
      created_at: '2026-03-01T00:00:00.000Z',
      author: {
        user_id: 'usr_researcher_demo',
        institution: 'Laboratory for Cognitive & Behavioral Science'
      },
      reproducibility: {
        dsl_version: '1.0.0',
        target_runtime: 'jspsych-7.3.4'
      }
    },
    participant_settings: {
      allow_anonymous: true,
      enforce_fullscreen: true,
      minimum_display_hz: 58,
      device_allowlist: ['desktop', 'laptop'],
      required_inputs: ['keyboard']
    },
    consent_settings: {
      required: true,
      statement_text: 'Participation is voluntary. You will classify food items into categories as quickly as possible.',
      require_checkbox: true,
      minimum_age: 18,
      ethics_protocol_id: 'IRB-2026-FOOD'
    },
    variables: {
      total_score: { type: 'number', default: 0, scope: 'global' }
    },
    game_skin: {
      enabled: false,
      theme: 'academic-clean',
      sound_enabled: true,
      hud_elements: {
        show_score: true,
        show_streak: true,
        show_progress_bar: true
      },
      score_rules: { correct_base_points: 100, streak_bonus_multiplier: 1.25, incorrect_penalty: 0, max_rt_for_bonus_ms: 500 }
    },
    nodes: [
      { id: 'n_start', type: 'flow_start', label: 'Start', config: {}, position: { x: 50, y: 180 } },
      { id: 'n_consent', type: 'presentation_text', label: 'Consent', config: { title: 'Food Decision Study', content_markdown: 'Classify food items into categories as rapidly as possible.', continue_button_text: 'Proceed' }, position: { x: 260, y: 180 } },
      { id: 'n_calibration', type: 'timing_calibration', label: 'Calibration', config: { measure_fps_frames: 120, reject_frame_jitter_ms: 8 }, position: { x: 480, y: 180 } },
      { id: 'n_instruction', type: 'presentation_text', label: 'Food Briefing', config: { title: 'Classification Rules', content_markdown: '* If you see **PIZZA 🍕** or **BURGER 🍔**, press **A** (Fast Food)\n* If you see **SALAD 🥗** or **ICE CREAM 🍦**, press **L** (Greens & Sweets)\n\nRespond as quickly as possible!', continue_button_text: 'Start Food Task' }, position: { x: 700, y: 180 } },
      { id: 'n_generator', type: 'randomization_balanced_block', label: 'Food Items Matrix', config: {
        factors: [{
          name: 'food_category',
          levels: [
            { value: 'pizza', metadata: { hex: '#f97316', text: 'PIZZA 🍕', expected_key: 'a', type: 'text' } },
            { value: 'burger', metadata: { hex: '#eab308', text: 'BURGER 🍔', expected_key: 'a', type: 'text' } },
            { value: 'salad', metadata: { hex: '#22c55e', text: 'SALAD 🥗', expected_key: 'l', type: 'text' } },
            { value: 'ice_cream', metadata: { hex: '#ec4899', text: 'ICE CREAM 🍦', expected_key: 'l', type: 'text' } }
          ]
        }],
        total_trials: 32,
        repetitions_per_level: 8,
        max_consecutive_identical: 2,
        prng_algorithm: 'mulberry32'
      }, position: { x: 920, y: 180 } },
      { id: 'n_loop', type: 'logic_loop', label: 'Trial Loop (32)', config: { max_iterations: 32 }, position: { x: 1140, y: 180 } },
      { id: 'n_fixation', type: 'presentation_fixation', label: 'Fixation Cross', config: { duration_ms: 500, jitter_ms: 100 }, position: { x: 1360, y: 120 } },
      { id: 'n_stimulus', type: 'presentation_stimulus', label: 'Food Item Display', config: { stimulus_type: 'text', duration_max_ms: 2500 }, position: { x: 1580, y: 120 } },
      { id: 'n_response', type: 'response_keyboard', label: 'Keypress (A/L)', config: { allowed_keys: ['a', 'l'], deadline_ms: 2500, record_rt: true }, position: { x: 1800, y: 120 } },
      { id: 'n_condition', type: 'logic_condition', label: 'Evaluate Response', config: {}, position: { x: 2020, y: 120 } },
      { id: 'n_reward', type: 'game_reward', label: '+100 Correct', config: { points: 100 }, position: { x: 2240, y: 60 } },
      { id: 'n_penalty', type: 'game_reward', label: 'Classification Error', config: { points: 0 }, position: { x: 2240, y: 180 } },
      { id: 'n_iti', type: 'timing_wait', label: 'ITI (400ms)', config: { duration_ms: 400 }, position: { x: 2460, y: 120 } },
      { id: 'n_debrief', type: 'presentation_text', label: 'Debriefing', config: { title: 'Food Study Complete', content_markdown: 'Appetitive latency data recorded.' }, position: { x: 2680, y: 180 } },
      { id: 'n_end', type: 'flow_end', label: 'End Session', config: {}, position: { x: 2900, y: 180 } }
    ],
    edges: [
      { id: 'e1', from: 'n_start', to: 'n_consent' },
      { id: 'e2', from: 'n_consent', to: 'n_calibration' },
      { id: 'e3', from: 'n_calibration', to: 'n_instruction' },
      { id: 'e4', from: 'n_instruction', to: 'n_generator' },
      { id: 'e5', from: 'n_generator', to: 'n_loop' },
      { id: 'e6', from: 'n_loop', to: 'n_fixation' },
      { id: 'e7', from: 'n_fixation', to: 'n_stimulus' },
      { id: 'e8', from: 'n_stimulus', to: 'n_response' },
      { id: 'e9', from: 'n_response', to: 'n_condition' },
      { id: 'e10', from: 'n_condition', to: 'n_reward' },
      { id: 'e11', from: 'n_condition', to: 'n_penalty' },
      { id: 'e12', from: 'n_reward', to: 'n_iti' },
      { id: 'e13', from: 'n_penalty', to: 'n_iti' },
      { id: 'e14', from: 'n_iti', to: 'n_debrief' },
      { id: 'e15', from: 'n_debrief', to: 'n_end' }
    ]
  },

  // 5. Eriksen Flanker Attentional Inhibition Task
  {
    $schema: "https://cognitivelab.io/schemas/v1/experiment.json",
    experiment: {
      id: 'exp_flanker_canonical',
      slug: 'eriksen-flanker-inhibition',
      version: 1,
      title: 'Eriksen Flanker Attentional Inhibition Task',
      description: 'Attentional focus experiment measuring latency to central target arrow amid congruent or conflicting flankers.',
      created_at: '2026-03-01T00:00:00.000Z',
      author: {
        user_id: 'usr_researcher_demo',
        institution: 'Laboratory for Cognitive & Behavioral Science'
      },
      reproducibility: {
        dsl_version: '1.0.0',
        target_runtime: 'jspsych-7.3.4'
      }
    },
    participant_settings: {
      allow_anonymous: true,
      enforce_fullscreen: true,
      minimum_display_hz: 58,
      device_allowlist: ['desktop', 'laptop'],
      required_inputs: ['keyboard']
    },
    consent_settings: {
      required: true,
      statement_text: 'Participation is voluntary. You will respond to the direction of a central arrow.',
      require_checkbox: true,
      minimum_age: 18,
      ethics_protocol_id: 'IRB-2026-FLANKER'
    },
    variables: {
      total_score: { type: 'number', default: 0, scope: 'global' }
    },
    game_skin: {
      enabled: false,
      theme: 'academic-clean',
      sound_enabled: true,
      hud_elements: {
        show_score: true,
        show_streak: true,
        show_progress_bar: true
      },
      score_rules: { correct_base_points: 100, streak_bonus_multiplier: 1.25, incorrect_penalty: 0, max_rt_for_bonus_ms: 450 }
    },
    nodes: [
      { id: 'n_start', type: 'flow_start', label: 'Start', config: {}, position: { x: 50, y: 180 } },
      { id: 'n_consent', type: 'presentation_text', label: 'Flanker Consent', config: { title: 'Flanker Task', content_markdown: 'Focus on the CENTRAL arrow only.', continue_button_text: 'Proceed' }, position: { x: 260, y: 180 } },
      { id: 'n_calibration', type: 'timing_calibration', label: 'Calibration', config: { measure_fps_frames: 120, reject_frame_jitter_ms: 8 }, position: { x: 480, y: 180 } },
      { id: 'n_instruction', type: 'presentation_text', label: 'Flanker Briefing', config: { title: 'Target Arrow Rules', content_markdown: 'Arrays of 5 arrows will appear.\n\n* If central arrow points **LEFT** (←), press **Z**\n* If central arrow points **RIGHT** (→), press **M**\n\nIgnore surrounding arrows!', continue_button_text: 'Start Flanker Block' }, position: { x: 700, y: 180 } },
      { id: 'n_generator', type: 'randomization_balanced_block', label: 'Flanker Congruency Matrix', config: {
        factors: [{
          name: 'compatibility',
          levels: [
            { value: 'congruent_left', metadata: { hex: '#38bdf8', text: '< < < < <', expected_key: 'z', type: 'text' } },
            { value: 'incongruent_left', metadata: { hex: '#38bdf8', text: '> > < > >', expected_key: 'z', type: 'text' } },
            { value: 'congruent_right', metadata: { hex: '#818cf8', text: '> > > > >', expected_key: 'm', type: 'text' } },
            { value: 'incongruent_right', metadata: { hex: '#818cf8', text: '< < > < <', expected_key: 'm', type: 'text' } }
          ]
        }],
        total_trials: 32,
        repetitions_per_level: 8,
        max_consecutive_identical: 2,
        prng_algorithm: 'mulberry32'
      }, position: { x: 920, y: 180 } },
      { id: 'n_loop', type: 'logic_loop', label: 'Trial Loop (32)', config: { max_iterations: 32 }, position: { x: 1140, y: 180 } },
      { id: 'n_fixation', type: 'presentation_fixation', label: 'Fixation Cross', config: { duration_ms: 500, jitter_ms: 120 }, position: { x: 1360, y: 120 } },
      { id: 'n_stimulus', type: 'presentation_stimulus', label: 'Arrow Array Stimulus', config: { stimulus_type: 'text', duration_max_ms: 1800 }, position: { x: 1580, y: 120 } },
      { id: 'n_response', type: 'response_keyboard', label: 'Keys (Z/M)', config: { allowed_keys: ['z', 'm'], deadline_ms: 1800, record_rt: true }, position: { x: 1800, y: 120 } },
      { id: 'n_condition', type: 'logic_condition', label: 'Evaluate Response', config: {}, position: { x: 2020, y: 120 } },
      { id: 'n_reward', type: 'game_reward', label: '+100 Hit', config: { points: 100 }, position: { x: 2240, y: 60 } },
      { id: 'n_penalty', type: 'game_reward', label: 'Inhibition Failure', config: { points: 0 }, position: { x: 2240, y: 180 } },
      { id: 'n_iti', type: 'timing_wait', label: 'ITI (350ms)', config: { duration_ms: 350 }, position: { x: 2460, y: 120 } },
      { id: 'n_debrief', type: 'presentation_text', label: 'Debriefing', config: { title: 'Flanker Block Complete', content_markdown: 'Inhibitory control data committed.' }, position: { x: 2680, y: 180 } },
      { id: 'n_end', type: 'flow_end', label: 'End Session', config: {}, position: { x: 2900, y: 180 } }
    ],
    edges: [
      { id: 'e1', from: 'n_start', to: 'n_consent' },
      { id: 'e2', from: 'n_consent', to: 'n_calibration' },
      { id: 'e3', from: 'n_calibration', to: 'n_instruction' },
      { id: 'e4', from: 'n_instruction', to: 'n_generator' },
      { id: 'e5', from: 'n_generator', to: 'n_loop' },
      { id: 'e6', from: 'n_loop', to: 'n_fixation' },
      { id: 'e7', from: 'n_fixation', to: 'n_stimulus' },
      { id: 'e8', from: 'n_stimulus', to: 'n_response' },
      { id: 'e9', from: 'n_response', to: 'n_condition' },
      { id: 'e10', from: 'n_condition', to: 'n_reward' },
      { id: 'e11', from: 'n_condition', to: 'n_penalty' },
      { id: 'e12', from: 'n_reward', to: 'n_iti' },
      { id: 'e13', from: 'n_penalty', to: 'n_iti' },
      { id: 'e14', from: 'n_iti', to: 'n_debrief' },
      { id: 'e15', from: 'n_debrief', to: 'n_end' }
    ]
  }
];

export class ExperimentStore {
  /**
   * Loads all saved experiments (merging canonical library with user-saved experiments)
   */
  public static getAllExperiments(): ExperimentDSL[] {
    try {
      const stored = localStorage.getItem(EXPERIMENTS_STORAGE_KEY);
      const userExperiments: ExperimentDSL[] = stored ? JSON.parse(stored) : [];
      
      const mergedMap = new Map<string, ExperimentDSL>();
      // 1. Load canonical
      canonicalExperiments.forEach(exp => mergedMap.set(exp.experiment.id, exp));
      // 2. User experiments overwrite or append
      userExperiments.forEach(exp => mergedMap.set(exp.experiment.id, exp));

      return Array.from(mergedMap.values());
    } catch {
      return canonicalExperiments;
    }
  }

  /**
   * Gets an experiment by ID
   */
  public static getExperiment(id: string): ExperimentDSL {
    const all = this.getAllExperiments();
    return all.find(e => e.experiment.id === id) || defaultExperimentDSL;
  }

  /**
   * Saves or updates an experiment
   */
  public static saveExperiment(dsl: ExperimentDSL): void {
    try {
      const stored = localStorage.getItem(EXPERIMENTS_STORAGE_KEY);
      const userExperiments: ExperimentDSL[] = stored ? JSON.parse(stored) : [];
      
      const filtered = userExperiments.filter(e => e.experiment.id !== dsl.experiment.id);
      filtered.push(dsl);

      localStorage.setItem(EXPERIMENTS_STORAGE_KEY, JSON.stringify(filtered));
      this.setActiveExperimentId(dsl.experiment.id);

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('cognitivelab_experiments_updated'));
      }
    } catch (e) {
      console.warn('Failed to persist experiment to storage', e);
    }
  }

  /**
   * Deletes an experiment by ID
   */
  public static deleteExperiment(id: string): void {
    try {
      const stored = localStorage.getItem(EXPERIMENTS_STORAGE_KEY);
      const userExperiments: ExperimentDSL[] = stored ? JSON.parse(stored) : [];
      const remaining = userExperiments.filter(e => e.experiment.id !== id);
      localStorage.setItem(EXPERIMENTS_STORAGE_KEY, JSON.stringify(remaining));

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('cognitivelab_experiments_updated'));
      }
    } catch (e) {
      console.warn('Failed to delete experiment', e);
    }
  }

  /**
   * Gets the active experiment ID
   */
  public static getActiveExperimentId(): string {
    return localStorage.getItem(ACTIVE_EXP_ID_KEY) || defaultExperimentDSL.experiment.id;
  }

  /**
   * Sets the active experiment ID
   */
  public static setActiveExperimentId(id: string): void {
    localStorage.setItem(ACTIVE_EXP_ID_KEY, id);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('cognitivelab_active_experiment_changed'));
    }
  }
}
