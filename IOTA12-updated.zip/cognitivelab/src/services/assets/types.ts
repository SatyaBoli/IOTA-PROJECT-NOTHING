export interface Asset {
  id: string;
  name: string;
  category: string;
  unicode?: string;
  url?: string;
  source: string;
  metadata?: Record<string, any>;
}

export interface AssetFilter {
  category?: string;
  tags?: string[];
  [key: string]: any;
}

export interface AssetProvider {
  readonly name: string;
  readonly providerType: 'api' | 'local' | 'database' | 's3' | 'custom';
  readonly priority: number; // Higher priority queried first

  isAvailable(): Promise<boolean>;
  getEmoji(concept: string): Promise<Asset | null>;
  getAsset(id: string, filter?: AssetFilter): Promise<Asset | null>;
  searchAssets(query: string, category?: string): Promise<Asset[]>;
}
