import { Asset, AssetFilter, AssetProvider } from './types';
import { LocalAssetProvider } from './providers/LocalAssetProvider';
import { EmojiHubProvider } from './providers/EmojiHubProvider';
import { ResearcherDatabaseProvider } from './providers/ResearcherDatabaseProvider';

export class AssetService {
  private static instance: AssetService;
  private providers: AssetProvider[] = [];
  private localProvider: LocalAssetProvider;
  private emojiHubProvider: EmojiHubProvider;
  private researcherDbProvider: ResearcherDatabaseProvider;

  private constructor() {
    this.localProvider = new LocalAssetProvider();
    this.emojiHubProvider = new EmojiHubProvider();
    this.researcherDbProvider = new ResearcherDatabaseProvider();

    // Register default providers in priority order
    this.registerProvider(this.researcherDbProvider); // Priority 30 (Custom overrides)
    this.registerProvider(this.emojiHubProvider);      // Priority 20 (Live Online API Option 1)
    this.registerProvider(this.localProvider);         // Priority 10 (Embedded fallback)
  }

  public static getInstance(): AssetService {
    if (!AssetService.instance) {
      AssetService.instance = new AssetService();
    }
    return AssetService.instance;
  }

  public registerProvider(provider: AssetProvider): void {
    this.providers.push(provider);
    this.providers.sort((a, b) => b.priority - a.priority);
  }

  public getProviders(): AssetProvider[] {
    return [...this.providers];
  }

  public getResearcherDbProvider(): ResearcherDatabaseProvider {
    return this.researcherDbProvider;
  }

  /**
   * Resolves an emoji for any concept by querying active providers.
   * If online API takes too long or fails, gracefully falls back to local.
   */
  public async getEmoji(concept: string): Promise<string> {
    for (const provider of this.providers) {
      try {
        const asset = await provider.getEmoji(concept);
        if (asset && asset.unicode) {
          return asset.unicode;
        }
      } catch {
        // Continue to next provider
      }
    }

    // Default aesthetic token if completely novel
    return '✨';
  }

  /**
   * Synchronous fast lookup for immediate UI rendering
   */
  public getEmojiSync(concept: string): string {
    const local = this.localProvider.getEmojiSync(concept);
    if (local && local.unicode) {
      return local.unicode;
    }
    return '✨';
  }

  /**
   * Resolves a structured asset (e.g. tree with size filter: { size: 'small' })
   */
  public async getAsset(id: string, filter?: AssetFilter): Promise<Asset | null> {
    for (const provider of this.providers) {
      try {
        const asset = await provider.getAsset(id, filter);
        if (asset) return asset;
      } catch {
        // Continue to next provider
      }
    }
    return null;
  }

  /**
   * Searches across all providers
   */
  public async searchAssets(query: string, category?: string): Promise<Asset[]> {
    const combined: Asset[] = [];
    const seen = new Set<string>();

    for (const provider of this.providers) {
      try {
        const list = await provider.searchAssets(query, category);
        for (const item of list) {
          if (!seen.has(item.id)) {
            seen.add(item.id);
            combined.push(item);
          }
        }
      } catch {
        // Ignore provider error
      }
    }

    return combined;
  }
}

// Global convenience singleton
export const assetService = AssetService.getInstance();
