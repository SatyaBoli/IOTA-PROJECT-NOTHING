import { Asset, AssetFilter, AssetProvider } from '../types';

export class LocalAssetProvider implements AssetProvider {
  public readonly name = 'local_embedded_provider';
  public readonly providerType = 'local' as const;
  public readonly priority = 10; // High baseline priority

  private static readonly ASSET_MAP: Record<string, { emoji: string; category: string; variants?: Record<string, string> }> = {
    // Nature, Trees & Plants
    tree: { emoji: '🌳', category: 'nature', variants: { small: '🌱', medium: '🌲', large: '🌳', sapling: '🌱', pine: '🌲', oak: '🌳' } },
    small_tree: { emoji: '🌱', category: 'nature' },
    medium_tree: { emoji: '🌲', category: 'nature' },
    large_tree: { emoji: '🌳', category: 'nature' },
    plant: { emoji: '🪴', category: 'nature' },
    flower: { emoji: '🌸', category: 'nature' },
    forest: { emoji: '🌲', category: 'nature' },
    mountain: { emoji: '⛰️', category: 'nature' },
    sun: { emoji: '☀️', category: 'weather' },
    sunny: { emoji: '☀️', category: 'weather' },
    rain: { emoji: '🌧️', category: 'weather' },
    rainy: { emoji: '🌧️', category: 'weather' },
    cloud: { emoji: '☁️', category: 'weather' },
    cloudy: { emoji: '⛅', category: 'weather' },
    storm: { emoji: '⛈️', category: 'weather' },
    snow: { emoji: '❄️', category: 'weather' },
    fire: { emoji: '🔥', category: 'nature' },
    water: { emoji: '💧', category: 'nature' },
    earth: { emoji: '🌍', category: 'nature' },

    // Vehicles
    car: { emoji: '🚗', category: 'vehicle', variants: { sports: '🏎️', sedan: '🚗', truck: '🚚', suv: '🚙' } },
    small_car: { emoji: '🚗', category: 'vehicle' },
    large_car: { emoji: '🚚', category: 'vehicle' },
    truck: { emoji: '🚚', category: 'vehicle' },
    bus: { emoji: '🚌', category: 'vehicle' },
    train: { emoji: '🚆', category: 'vehicle' },
    airplane: { emoji: '✈️', category: 'vehicle' },
    plane: { emoji: '✈️', category: 'vehicle' },
    rocket: { emoji: '🚀', category: 'vehicle' },
    bicycle: { emoji: '🚲', category: 'vehicle' },
    bike: { emoji: '🚲', category: 'vehicle' },
    motorcycle: { emoji: '🏍️', category: 'vehicle' },
    boat: { emoji: '⛵', category: 'vehicle' },
    ship: { emoji: '🚢', category: 'vehicle' },
    helicopter: { emoji: '🚁', category: 'vehicle' },

    // Food & Drinks
    food: { emoji: '🍲', category: 'food' },
    cake: { emoji: '🍰', category: 'food' },
    pizza: { emoji: '🍕', category: 'food' },
    burger: { emoji: '🍔', category: 'food' },
    apple: { emoji: '🍎', category: 'food' },
    banana: { emoji: '🍌', category: 'food' },
    orange: { emoji: '🍊', category: 'food' },
    strawberry: { emoji: '🍓', category: 'food' },
    bread: { emoji: '🍞', category: 'food' },
    cookie: { emoji: '🍪', category: 'food' },
    icecream: { emoji: '🍦', category: 'food' },
    coffee: { emoji: '☕', category: 'food' },
    tea: { emoji: '🍵', category: 'food' },
    salad: { emoji: '🥗', category: 'food' },
    healthy_food: { emoji: '🥗', category: 'food' },
    junk_food: { emoji: '🍔', category: 'food' },

    // Animals
    dog: { emoji: '🐕', category: 'animal' },
    cat: { emoji: '🐈', category: 'animal' },
    lion: { emoji: '🦁', category: 'animal' },
    tiger: { emoji: '🐅', category: 'animal' },
    bear: { emoji: '🐻', category: 'animal' },
    elephant: { emoji: '🐘', category: 'animal' },
    monkey: { emoji: '🐒', category: 'animal' },
    bird: { emoji: '🐦', category: 'animal' },
    fish: { emoji: '🐟', category: 'animal' },
    shark: { emoji: '🦈', category: 'animal' },
    snake: { emoji: '🐍', category: 'animal' },
    horse: { emoji: '🐎', category: 'animal' },

    // Emotions & Psychology
    happy: { emoji: '😊', category: 'emotion' },
    sad: { emoji: '😢', category: 'emotion' },
    angry: { emoji: '😠', category: 'emotion' },
    calm: { emoji: '😌', category: 'emotion' },
    scared: { emoji: '😨', category: 'emotion' },
    neutral: { emoji: '😐', category: 'emotion' },
    safe: { emoji: '🛡️', category: 'emotion' },
    danger: { emoji: '⚠️', category: 'emotion' },
    uncertain: { emoji: '❓', category: 'cognition' },

    // Objects & Tools
    star: { emoji: '⭐', category: 'object' },
    gem: { emoji: '💎', category: 'object' },
    heart: { emoji: '❤️', category: 'object' },
    shield: { emoji: '🛡️', category: 'object' },
    sword: { emoji: '⚔️', category: 'object' },
    key: { emoji: '🔑', category: 'object' },
    lock: { emoji: '🔒', category: 'object' },
    book: { emoji: '📖', category: 'object' },
    clock: { emoji: '⏰', category: 'object' },
    flag: { emoji: '🚩', category: 'object' },
  };

  public async isAvailable(): Promise<boolean> {
    return true;
  }

  public async getEmoji(concept: string): Promise<Asset | null> {
    return this.getEmojiSync(concept);
  }

  public getEmojiSync(concept: string): Asset | null {
    const normalized = concept.toLowerCase().trim().replace(/[\s-]+/g, '_');
    
    // Direct match
    if (LocalAssetProvider.ASSET_MAP[normalized]) {
      const item = LocalAssetProvider.ASSET_MAP[normalized];
      return {
        id: `local_${normalized}`,
        name: concept,
        category: item.category,
        unicode: item.emoji,
        source: 'local_asset_provider',
        metadata: { variants: item.variants }
      };
    }

    // Stemming / partial match
    for (const [key, item] of Object.entries(LocalAssetProvider.ASSET_MAP)) {
      if (normalized.includes(key) || key.includes(normalized)) {
        return {
          id: `local_${key}`,
          name: key,
          category: item.category,
          unicode: item.emoji,
          source: 'local_asset_provider',
          metadata: { variants: item.variants }
        };
      }
    }

    return null;
  }

  public async getAsset(id: string, filter?: AssetFilter): Promise<Asset | null> {
    const normalized = id.toLowerCase().trim().replace(/[\s-]+/g, '_');
    const asset = this.getEmojiSync(normalized);
    if (!asset) return null;

    if (filter && filter.size && asset.metadata?.variants && asset.metadata.variants[filter.size]) {
      return {
        ...asset,
        unicode: asset.metadata.variants[filter.size],
        metadata: { ...asset.metadata, selected_variant: filter.size }
      };
    }

    return asset;
  }

  public async searchAssets(query: string, category?: string): Promise<Asset[]> {
    const q = query.toLowerCase().trim();
    const results: Asset[] = [];

    for (const [key, item] of Object.entries(LocalAssetProvider.ASSET_MAP)) {
      if (category && item.category !== category) continue;
      if (key.includes(q) || item.category.includes(q)) {
        results.push({
          id: `local_${key}`,
          name: key,
          category: item.category,
          unicode: item.emoji,
          source: 'local_asset_provider',
          metadata: { variants: item.variants }
        });
      }
    }

    return results;
  }
}
