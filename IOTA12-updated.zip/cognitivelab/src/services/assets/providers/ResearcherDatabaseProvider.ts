import { Asset, AssetFilter, AssetProvider } from '../types';

export interface DatabaseConnectionConfig {
  endpoint?: string;
  apiKey?: string;
  datasetId?: string;
  organizationId?: string;
}

/**
 * ResearcherDatabaseProvider
 * Extensible provider for future researcher-owned assets:
 * - PostgreSQL databases
 * - AWS S3 / Cloud Storage buckets
 * - Custom REST / GraphQL APIs
 * - Lab-specific image datasets
 */
export class ResearcherDatabaseProvider implements AssetProvider {
  public readonly name = 'researcher_database_provider';
  public readonly providerType = 'database' as const;
  public readonly priority = 30; // Researcher's own assets override defaults when available

  private config: DatabaseConnectionConfig;
  private localOverrides: Map<string, Asset> = new Map();

  constructor(config: DatabaseConnectionConfig = {}) {
    this.config = config;
  }

  public updateConfig(config: DatabaseConnectionConfig): void {
    this.config = { ...this.config, ...config };
  }

  public registerCustomAsset(asset: Asset): void {
    this.localOverrides.set(asset.id, asset);
    this.localOverrides.set(asset.name.toLowerCase(), asset);
  }

  public async isAvailable(): Promise<boolean> {
    return this.localOverrides.size > 0 || Boolean(this.config.endpoint);
  }

  public async getEmoji(concept: string): Promise<Asset | null> {
    const key = concept.toLowerCase().trim();
    if (this.localOverrides.has(key)) {
      return this.localOverrides.get(key)!;
    }
    return null;
  }

  public async getAsset(id: string, filter?: AssetFilter): Promise<Asset | null> {
    if (this.localOverrides.has(id)) {
      const asset = this.localOverrides.get(id)!;
      if (filter && filter.variant && asset.metadata?.variants) {
        return {
          ...asset,
          url: asset.metadata.variants[filter.variant] || asset.url,
          unicode: asset.metadata.variants[filter.variant] || asset.unicode
        };
      }
      return asset;
    }

    // Future remote query stub:
    if (this.config.endpoint) {
      try {
        const res = await fetch(`${this.config.endpoint}/assets/${id}?filter=${encodeURIComponent(JSON.stringify(filter || {}))}`, {
          headers: this.config.apiKey ? { 'Authorization': `Bearer ${this.config.apiKey}` } : {}
        });
        if (res.ok) return await res.json();
      } catch {
        return null;
      }
    }

    return null;
  }

  public async searchAssets(query: string, _category?: string): Promise<Asset[]> {
    const q = query.toLowerCase().trim();
    const results: Asset[] = [];
    for (const [key, asset] of this.localOverrides.entries()) {
      if (key.includes(q)) results.push(asset);
    }
    return results;
  }
}
