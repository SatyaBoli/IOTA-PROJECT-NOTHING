import { Asset, AssetFilter, AssetProvider } from '../types';

export class EmojiHubProvider implements AssetProvider {
  public readonly name = 'emojihub_provider';
  public readonly providerType = 'api' as const;
  public readonly priority = 20; // Queried after local or as primary online provider

  private static cache: Map<string, string> = new Map();
  private static isLoaded = false;
  private static loadPromise: Promise<void> | null = null;

  public async isAvailable(): Promise<boolean> {
    return typeof fetch !== 'undefined';
  }

  private static htmlCodesToUnicode(htmlCodes: string[]): string {
    return htmlCodes.map(code => {
      const match = code.match(/&#(\d+);/);
      if (match) {
        return String.fromCodePoint(parseInt(match[1], 10));
      }
      const hexMatch = code.match(/&#x([0-9a-fA-F]+);/);
      if (hexMatch) {
        return String.fromCodePoint(parseInt(hexMatch[1], 16));
      }
      return '';
    }).join('');
  }

  public async preload(): Promise<void> {
    if (EmojiHubProvider.isLoaded) return;
    if (EmojiHubProvider.loadPromise) return EmojiHubProvider.loadPromise;

    EmojiHubProvider.loadPromise = (async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);
        const res = await fetch('https://emojihub.yurace.pro/api/all', { signal: controller.signal });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) {
            data.forEach((item: any) => {
              if (item.name && item.htmlCode) {
                const char = EmojiHubProvider.htmlCodesToUnicode(item.htmlCode);
                if (char) {
                  const nameKey = String(item.name).toLowerCase().trim().replace(/[\s-]+/g, '_');
                  EmojiHubProvider.cache.set(nameKey, char);
                }
              }
            });
          }
        }
      } catch (err) {
        // Non-critical: network timeout or offline
      } finally {
        EmojiHubProvider.isLoaded = true;
      }
    })();

    return EmojiHubProvider.loadPromise;
  }

  public async getEmoji(concept: string): Promise<Asset | null> {
    const normalized = concept.toLowerCase().trim().replace(/[\s-]+/g, '_');
    
    // Check cache
    if (EmojiHubProvider.cache.has(normalized)) {
      return {
        id: `emojihub_${normalized}`,
        name: concept,
        category: 'emojihub',
        unicode: EmojiHubProvider.cache.get(normalized)!,
        source: 'emojihub_api'
      };
    }

    // Try preloading if not loaded yet
    if (!EmojiHubProvider.isLoaded) {
      await this.preload();
      if (EmojiHubProvider.cache.has(normalized)) {
        return {
          id: `emojihub_${normalized}`,
          name: concept,
          category: 'emojihub',
          unicode: EmojiHubProvider.cache.get(normalized)!,
          source: 'emojihub_api'
        };
      }
    }

    // Fuzzy search within cache
    for (const [key, glyph] of EmojiHubProvider.cache.entries()) {
      if (key.includes(normalized) || normalized.includes(key)) {
        return {
          id: `emojihub_${key}`,
          name: key,
          category: 'emojihub',
          unicode: glyph,
          source: 'emojihub_api'
        };
      }
    }

    return null;
  }

  public async getAsset(id: string, _filter?: AssetFilter): Promise<Asset | null> {
    return this.getEmoji(id);
  }

  public async searchAssets(query: string, _category?: string): Promise<Asset[]> {
    if (!EmojiHubProvider.isLoaded) await this.preload();
    const q = query.toLowerCase().trim();
    const results: Asset[] = [];

    for (const [key, glyph] of EmojiHubProvider.cache.entries()) {
      if (key.includes(q)) {
        results.push({
          id: `emojihub_${key}`,
          name: key,
          category: 'emojihub',
          unicode: glyph,
          source: 'emojihub_api'
        });
        if (results.length >= 20) break;
      }
    }

    return results;
  }
}
