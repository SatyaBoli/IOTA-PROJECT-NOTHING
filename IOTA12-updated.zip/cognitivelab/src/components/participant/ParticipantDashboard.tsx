import React, { useState, useEffect, useMemo } from 'react';
import { 
  Compass, 
  Clock, 
  CheckCircle2, 
  Award, 
  Flame, 
  ShieldCheck, 
  Trash2, 
  Play, 
  Sliders, 
  Monitor, 
  Eye, 
  Sparkles, 
  Lock, 
  AlertCircle,
  ChevronRight,
  ChevronDown,
  BookOpen,
  ArrowRight,
  BarChart3,
  Target,
  Gauge,
  Flame as FlameIcon,
  Brain
} from 'lucide-react';
import { ExperimentDSL } from '../../types/dsl';
import { defaultExperimentDSL } from '../../dsl/defaultExperiment';
import { LocalExperimentStorage } from '../../runtime/storage';
import { TrialRecord } from '../../types/dsl';
import { ExperimentStore } from '../../runtime/experimentStore';
import { summarizeDataset, DatasetSummary } from '../../analytics/datasetAnalysis';
import { StatisticalEngine } from '../../analytics/statisticalEngine';

// Per-session performance analysis derived straight from the raw stored trials.
// This is what powers the "Your Data & Analysis" panel in the User (Participant) tab.
interface SessionAnalysis {
  sessionId: string;
  experimentTitle: string;
  trialCount: number;
  accuracyPercent: number | null;
  meanRtMs: number | null;
  medianRtMs: number | null;
  finalScore: number;
  bestStreak: number;
  uncertaintyCount: number;
  timestamp: string;
  summary: DatasetSummary;
}

function analyzeSession(sessionId: string, trials: TrialRecord[], experiments: ExperimentDSL[]): SessionAnalysis {
  const sessTrials = trials
    .filter(t => t.sessionId === sessionId)
    .sort((a, b) => a.trialIndex - b.trialIndex);

  const scored = sessTrials.filter(t => t.isCorrect !== null && t.isCorrect !== undefined);
  const rts = sessTrials
    .map(t => t.reactionTimeMs)
    .filter((rt): rt is number => rt !== null && Number.isFinite(rt));
  const rtStats = StatisticalEngine.computeDescriptives(rts);

  const lastTrial = sessTrials[sessTrials.length - 1];
  const matchedExperiment = experiments.find(e => e.experiment.id === lastTrial?.experimentId);

  return {
    sessionId,
    experimentTitle: matchedExperiment?.experiment.title || lastTrial?.experimentId || 'Unknown Study',
    trialCount: sessTrials.length,
    accuracyPercent: scored.length ? (scored.filter(t => t.isCorrect === true).length / scored.length) * 100 : null,
    meanRtMs: rts.length ? rtStats.mean : null,
    medianRtMs: rts.length ? rtStats.median : null,
    finalScore: sessTrials.reduce((max, t) => Math.max(max, t.score ?? 0), 0),
    bestStreak: sessTrials.reduce((max, t) => Math.max(max, t.streak ?? 0), 0),
    uncertaintyCount: sessTrials.filter(t => t.isUncertain).length,
    timestamp: lastTrial?.timestamp || '',
    summary: summarizeDataset(sessTrials),
  };
}

interface ParticipantDashboardProps {
  currentDsl: ExperimentDSL;
  onLaunchExperiment: (dsl: ExperimentDSL) => void;
  onSwitchToResearcher: () => void;
}

interface StudyItem {
  id: string;
  title: string;
  description: string;
  irbProtocol: string;
  durationMinutes: number;
  rewardXp: number;
  deviceRequirement: 'Physical Keyboard Required' | 'Touchscreen / Keyboard';
  dsl: ExperimentDSL;
  isPopular?: boolean;
}

export const ParticipantDashboard: React.FC<ParticipantDashboardProps> = ({
  currentDsl,
  onLaunchExperiment,
  onSwitchToResearcher
}) => {
  const [filterDuration, setFilterDuration] = useState<'all' | 'short' | 'medium'>('all');
  const [activeTab, setActiveTab] = useState<'marketplace' | 'history' | 'accessibility'>('marketplace');
  const [contrastPreset, setContrastPreset] = useState<'standard' | 'deuteranopia' | 'protanopia' | 'tritanopia'>('standard');
  const [highContrast, setHighContrast] = useState(false);
  const [storedTrials, setStoredTrials] = useState<TrialRecord[]>([]);
  const [revocationNotice, setRevocationNotice] = useState<string | null>(null);
  const [experiments, setExperiments] = useState<ExperimentDSL[]>(() => ExperimentStore.getAllExperiments());
  const [expandedSessionId, setExpandedSessionId] = useState<string | null>(null);

  useEffect(() => {
    // BUGFIX: this dashboard previously only loaded stored trials once on mount and
    // never re-fetched, so freshly-played sessions (and their analysis) would not
    // show up here without a manual reload. It now reloads whenever new trial data
    // is written (see LocalExperimentStorage.bufferTrial / clearAll) or the
    // experiment library changes.
    const loadTrials = () => {
      LocalExperimentStorage.getAllStoredTrials().then(trials => {
        setStoredTrials(trials);
      });
    };
    loadTrials();

    const handleUpdate = () => {
      setExperiments(ExperimentStore.getAllExperiments());
    };
    window.addEventListener('cognitivelab_data_updated', loadTrials);
    window.addEventListener('cognitivelab_experiments_updated', handleUpdate);
    window.addEventListener('cognitivelab_active_experiment_changed', handleUpdate);
    return () => {
      window.removeEventListener('cognitivelab_data_updated', loadTrials);
      window.removeEventListener('cognitivelab_experiments_updated', handleUpdate);
      window.removeEventListener('cognitivelab_active_experiment_changed', handleUpdate);
    };
  }, []);

  // Built-in curated and user-generated scientific study catalog from ExperimentStore
  const studies: StudyItem[] = experiments.map((exp, idx) => {
    const isCurrent = exp.experiment.id === currentDsl.experiment.id;
    const trialsCount = exp.nodes.find(n => n.type === 'randomization_balanced_block')?.config.total_trials || 30;
    return {
      id: exp.experiment.id,
      title: exp.experiment.title,
      description: exp.experiment.description,
      irbProtocol: exp.consent_settings.ethics_protocol_id || `IRB-2026-${String(idx + 10).padStart(2, '0')}`,
      durationMinutes: Math.max(Math.round(trialsCount * 0.08), 2),
      rewardXp: 150 + (idx * 25),
      deviceRequirement: 'Physical Keyboard Required',
      dsl: exp,
      isPopular: isCurrent || idx === 0
    };
  });

  const handleLaunch = (study: StudyItem) => {
    ExperimentStore.setActiveExperimentId(study.dsl.experiment.id);
    onLaunchExperiment(study.dsl);
  };

  const filteredStudies = studies.filter(s => {
    if (filterDuration === 'short') return s.durationMinutes <= 3;
    if (filterDuration === 'medium') return s.durationMinutes > 3;
    return true;
  });

  const sessionIds = Array.from(new Set(storedTrials.map(t => t.sessionId)));
  const completedStudiesCount = sessionIds.length;
  const earnedXp = 250 + (completedStudiesCount * 150);

  // Per-session data analysis, newest session first, computed straight from
  // the trial records that were stored while the participant played.
  const sessionAnalyses: SessionAnalysis[] = sessionIds
    .map(sessId => analyzeSession(sessId, storedTrials, experiments))
    .sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));

  // Aggregate "Your Data & Analysis" summary across every stored session.
  const overallAnalysis = useMemo(() => {
    const scored = storedTrials.filter(t => t.isCorrect !== null && t.isCorrect !== undefined);
    const rts = storedTrials
      .map(t => t.reactionTimeMs)
      .filter((rt): rt is number => rt !== null && Number.isFinite(rt));
    const rtStats = StatisticalEngine.computeDescriptives(rts);
    return {
      totalTrials: storedTrials.length,
      accuracyPercent: scored.length ? (scored.filter(t => t.isCorrect === true).length / scored.length) * 100 : null,
      meanRtMs: rts.length ? rtStats.mean : null,
      bestStreak: storedTrials.reduce((max, t) => Math.max(max, t.streak ?? 0), 0),
      bestScore: storedTrials.reduce((max, t) => Math.max(max, t.score ?? 0), 0),
    };
  }, [storedTrials]);

  const handleRevokeData = async (sessionId: string) => {
    try {
      const remaining = storedTrials.filter(t => t.sessionId !== sessionId);
      localStorage.setItem('cl_offline_trials_backup', JSON.stringify(remaining));
      setStoredTrials(remaining);
      if (expandedSessionId === sessionId) setExpandedSessionId(null);
      setRevocationNotice(`Data revocation confirmed for session ${sessionId}. Your trial telemetry was permanently wiped.`);
    } catch {
      setRevocationNotice('Failed to revoke session data.');
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 space-y-6">
      {/* Participant Welcome Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] font-mono uppercase bg-emerald-950/80 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full">
              Participant Portal Active
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              Subject Token: sub_anon_{Date.now().toString(36).substring(0, 5)}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Welcome to CognitiveLab Research Hub
          </h1>
          <p className="text-xs text-slate-400 max-w-xl mt-1">
            Participate in certified behavioral experiments, calibrate your display, and advance cognitive science with guaranteed anonymous data privacy.
          </p>
        </div>

        {/* Gamification Milestone & Streaks (Isolated from experimental trials) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 text-center min-w-[90px]">
            <div className="flex items-center justify-center gap-1 text-amber-400 text-xs font-bold">
              <Flame className="h-4 w-4 fill-current" />
              <span>3 Days</span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">Study Streak</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 text-center min-w-[100px]">
            <div className="flex items-center justify-center gap-1 text-purple-400 text-xs font-bold">
              <Award className="h-4 w-4" />
              <span>{earnedXp} XP</span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">Science Level 2</div>
          </div>

          <button
            onClick={onSwitchToResearcher}
            className="hidden sm:flex items-center gap-1.5 px-3 py-3 rounded-2xl bg-sky-950/60 hover:bg-sky-900/60 border border-sky-500/40 text-sky-300 text-xs font-semibold transition-all"
          >
            <span>Researcher View</span>
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      {revocationNotice && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{revocationNotice}</span>
          </div>
          <button onClick={() => setRevocationNotice(null)} className="text-emerald-400 hover:text-white text-xs underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('marketplace')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'marketplace'
                ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Compass className="h-4 w-4" />
            <span>Available Experiments</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'history'
                ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="h-4 w-4" />
            <span>Participation & Ethics Ledger ({completedStudiesCount})</span>
          </button>

          <button
            onClick={() => setActiveTab('accessibility')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'accessibility'
                ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="h-4 w-4" />
            <span>Display & Calibration</span>
          </button>
        </div>

        {activeTab === 'marketplace' && (
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-500 hidden sm:inline">Filter Duration:</span>
            <select
              value={filterDuration}
              onChange={(e) => setFilterDuration(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded-xl px-2.5 py-1.5 outline-none"
            >
              <option value="all">All Durations</option>
              <option value="short">Short (&lt;= 3 mins)</option>
              <option value="medium">Standard (&gt; 3 mins)</option>
            </select>
          </div>
        )}
      </div>

      {/* TAB 1: AVAILABLE EXPERIMENTS MARKETPLACE */}
      {activeTab === 'marketplace' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredStudies.map((study) => (
            <div
              key={study.id}
              className="bg-[#0d1322] border border-slate-800 hover:border-slate-700 rounded-3xl p-5 shadow-xl flex flex-col justify-between transition-all group relative overflow-hidden"
            >
              {study.isPopular && (
                <div className="absolute top-0 right-0 bg-gradient-to-l from-purple-600 to-indigo-600 text-white text-[9px] font-bold px-3 py-1 rounded-bl-xl uppercase tracking-wider">
                  Featured Study
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-mono text-sky-400 bg-sky-950/60 border border-sky-800 px-2 py-0.5 rounded-full">
                    {study.irbProtocol}
                  </span>
                  <span className="text-[10px] font-mono text-purple-300 bg-purple-950/40 px-2 py-0.5 rounded-full">
                    +{study.rewardXp} XP
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-sky-300 transition-colors">
                  {study.title}
                </h3>
                <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                  {study.description}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-1.5 text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-slate-500" />
                    <span>Estimated time: <strong>~{study.durationMinutes} minutes</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Monitor className="h-3.5 w-3.5 text-slate-500" />
                    <span>Hardware: <strong>{study.deviceRequirement}</strong></span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3">
                <button
                  onClick={() => handleLaunch(study)}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-semibold text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>Start Experiment Now</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: PARTICIPATION & ETHICS LEDGER */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          {/* YOUR DATA & ANALYSIS — aggregate summary computed from every stored session */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2">
              <Brain className="h-4 w-4 text-purple-400" />
              <h3 className="text-sm font-bold text-white">Your Data & Analysis</h3>
              <span className="text-[10px] font-mono text-slate-500">Auto-updates after every completed game</span>
            </div>

            {overallAnalysis.totalTrials > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-mono uppercase">
                    <BarChart3 className="h-3.5 w-3.5" /> Trials Logged
                  </div>
                  <div className="text-lg font-bold text-white mt-1">{overallAnalysis.totalTrials}</div>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-mono uppercase">
                    <Target className="h-3.5 w-3.5" /> Accuracy
                  </div>
                  <div className="text-lg font-bold text-emerald-400 mt-1">
                    {overallAnalysis.accuracyPercent !== null ? `${overallAnalysis.accuracyPercent.toFixed(1)}%` : 'N/A'}
                  </div>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-mono uppercase">
                    <Gauge className="h-3.5 w-3.5" /> Mean Reaction Time
                  </div>
                  <div className="text-lg font-bold text-sky-400 mt-1">
                    {overallAnalysis.meanRtMs !== null ? `${Math.round(overallAnalysis.meanRtMs)} ms` : 'N/A'}
                  </div>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-mono uppercase">
                    <FlameIcon className="h-3.5 w-3.5" /> Best Streak / Score
                  </div>
                  <div className="text-lg font-bold text-amber-400 mt-1">
                    {overallAnalysis.bestStreak} <span className="text-xs text-slate-500 font-normal">/ {overallAnalysis.bestScore} pts</span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500">Play an AI-generated game to see your accuracy, reaction time, and streaks analyzed here.</p>
            )}
          </div>

          <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Your Participation Ledger</h3>
                <p className="text-xs text-slate-400">
                  Certified records of past completed studies with cryptographic consent receipts and GDPR data deletion autonomy.
                </p>
              </div>
              <div className="text-xs text-slate-400 font-mono">
                Total Studies: {completedStudiesCount}
              </div>
            </div>

            {sessionAnalyses.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="text-[10px] uppercase font-mono text-slate-500 bg-slate-900/60 border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3"></th>
                      <th className="py-2.5 px-3">Session Hash</th>
                      <th className="py-2.5 px-3">Study</th>
                      <th className="py-2.5 px-3">Trials</th>
                      <th className="py-2.5 px-3">Accuracy</th>
                      <th className="py-2.5 px-3">Mean RT</th>
                      <th className="py-2.5 px-3">Consent Status</th>
                      <th className="py-2.5 px-3 text-right">Data Rights</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-mono">
                    {sessionAnalyses.map((sess) => (
                      <React.Fragment key={sess.sessionId}>
                        <tr className="hover:bg-slate-900/40">
                          <td className="py-2.5 px-3">
                            <button
                              onClick={() => setExpandedSessionId(expandedSessionId === sess.sessionId ? null : sess.sessionId)}
                              className="text-slate-400 hover:text-sky-300"
                              title="Show data analysis for this session"
                            >
                              <ChevronDown className={`h-3.5 w-3.5 transition-transform ${expandedSessionId === sess.sessionId ? 'rotate-180' : ''}`} />
                            </button>
                          </td>
                          <td className="py-2.5 px-3 text-slate-300 font-semibold">{sess.sessionId}</td>
                          <td className="py-2.5 px-3 text-slate-400 max-w-[160px] truncate" title={sess.experimentTitle}>{sess.experimentTitle}</td>
                          <td className="py-2.5 px-3 text-emerald-400">{sess.trialCount}</td>
                          <td className="py-2.5 px-3 text-sky-300">{sess.accuracyPercent !== null ? `${sess.accuracyPercent.toFixed(0)}%` : '—'}</td>
                          <td className="py-2.5 px-3 text-purple-300">{sess.meanRtMs !== null ? `${Math.round(sess.meanRtMs)} ms` : '—'}</td>
                          <td className="py-2.5 px-3 text-sky-300">
                            <span className="flex items-center gap-1">
                              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                              <span>Signed & Sealed</span>
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={() => handleRevokeData(sess.sessionId)}
                              className="text-rose-400 hover:text-rose-300 flex items-center gap-1 ml-auto text-xs"
                              title="Exercise participant autonomy and wipe session data"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                              <span>Revoke Data</span>
                            </button>
                          </td>
                        </tr>
                        {expandedSessionId === sess.sessionId && (
                          <tr>
                            <td colSpan={8} className="bg-slate-950/60 px-4 py-4">
                              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-3">
                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase">Final Score</div>
                                  <div className="text-sm font-bold text-white">{sess.finalScore}</div>
                                </div>
                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase">Best Streak</div>
                                  <div className="text-sm font-bold text-amber-400">{sess.bestStreak}</div>
                                </div>
                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase">Median RT</div>
                                  <div className="text-sm font-bold text-purple-300">{sess.medianRtMs !== null ? `${Math.round(sess.medianRtMs)} ms` : '—'}</div>
                                </div>
                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase">Uncertain Responses</div>
                                  <div className="text-sm font-bold text-slate-300">{sess.uncertaintyCount}</div>
                                </div>
                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase">Conditions</div>
                                  <div className="text-sm font-bold text-slate-300">{sess.summary.conditions.length}</div>
                                </div>
                              </div>

                              {sess.summary.conditions.length > 0 && (
                                <div className="space-y-1.5">
                                  <div className="text-[10px] text-slate-500 uppercase font-mono">Per-Condition Breakdown</div>
                                  {sess.summary.conditions.map(c => (
                                    <div key={c.condition} className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-300 bg-slate-900/60 border border-slate-800 rounded-lg px-3 py-1.5">
                                      <span className="font-semibold text-sky-300">{c.condition}</span>
                                      <span className="text-slate-500">n={c.trials}</span>
                                      {c.accuracyPercent !== null && <span>accuracy {c.accuracyPercent.toFixed(0)}%</span>}
                                      {c.meanRtMs !== null && <span>mean RT {Math.round(c.meanRtMs)} ms</span>}
                                      {c.uncertaintyCount > 0 && <span className="text-amber-300">{c.uncertaintyCount} uncertain</span>}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-slate-500 space-y-2">
                <ShieldCheck className="h-8 w-8 text-slate-600 mx-auto" />
                <div>No study records found yet. Launch an experiment from the marketplace to start contributing.</div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: DISPLAY & ACCESSIBILITY CALIBRATION */}
      {activeTab === 'accessibility' && (
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Eye className="h-4 w-4 text-sky-400" />
              <span>Accessibility & Chromatic Calibration Suite</span>
            </h3>
            <p className="text-xs text-slate-400">
              Calibrate color palettes and contrast levels to match your visual comfort without altering experimental timing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Color Blindness Presets */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
              <label className="text-xs font-semibold text-slate-300 block">
                Color-Vision Optimization Presets
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'standard', label: 'Standard RGB', desc: 'Default high-gamut' },
                  { id: 'deuteranopia', label: 'Deuteranopia', desc: 'Green-weak safe' },
                  { id: 'protanopia', label: 'Protanopia', desc: 'Red-weak safe' },
                  { id: 'tritanopia', label: 'Tritanopia', desc: 'Blue-yellow safe' }
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => setContrastPreset(p.id as any)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      contrastPreset === p.id
                        ? 'bg-sky-950/80 border-sky-500 text-sky-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
                    }`}
                  >
                    <div className="text-xs font-bold">{p.label}</div>
                    <div className="text-[10px] text-slate-500">{p.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Hardware Refresh Calibration Diagnostic */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 space-y-3">
              <label className="text-xs font-semibold text-slate-300 block">
                Hardware Display Synchronization
              </label>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Target V-Sync:</span>
                  <span className="font-mono text-emerald-400 font-bold">60 Hz / 120 Hz Calibrated</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Timing Subsystem:</span>
                  <span className="font-mono text-sky-400">requestAnimationFrame</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Precision:</span>
                  <span className="font-mono text-purple-400">~0.1ms performance.now()</span>
                </div>
              </div>
              <div className="text-[11px] text-slate-500">
                Your browser supports sub-millisecond precision hardware timestamping.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
