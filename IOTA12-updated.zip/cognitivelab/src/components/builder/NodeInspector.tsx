import React from 'react';
import { X, Settings, Trash2, AlertCircle } from 'lucide-react';
import { DSLNode, ValidationIssue } from '../../types/dsl';

interface NodeInspectorProps {
  node: DSLNode | null;
  onClose: () => void;
  onUpdateConfig: (nodeId: string, newConfig: Record<string, any>) => void;
  onUpdateLabel: (nodeId: string, newLabel: string) => void;
  onDeleteNode: (nodeId: string) => void;
  validationIssues: ValidationIssue[];
}

export const NodeInspector: React.FC<NodeInspectorProps> = ({
  node,
  onClose,
  onUpdateConfig,
  onUpdateLabel,
  onDeleteNode,
  validationIssues
}) => {
  if (!node) return null;

  const nodeIssues = validationIssues.filter(i => i.nodeId === node.id);

  const handleFieldChange = (key: string, value: any) => {
    onUpdateConfig(node.id, {
      ...node.config,
      [key]: value,
    });
  };

  const handleDelete = () => {
    if (confirm(`Delete node "${node.label}"? All connecting wires will be removed.`)) {
      onDeleteNode(node.id);
      onClose();
    }
  };

  return (
    <aside className="w-80 border-l border-slate-800 bg-[#0a0f1d] p-4 flex flex-col h-[calc(100vh-4rem)] overflow-y-auto z-30">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Settings className="h-4 w-4 text-sky-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Node Inspector
          </h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Validation Warnings for this node */}
      {nodeIssues.length > 0 && (
        <div className="mb-4 space-y-2">
          {nodeIssues.map((issue) => (
            <div
              key={issue.id}
              className={`p-2.5 rounded-lg border text-xs flex gap-2 ${
                issue.severity === 'critical'
                  ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  : 'bg-amber-950/40 border-amber-500/40 text-amber-300'
              }`}
            >
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold">{issue.message}</div>
                {issue.suggestion && (
                  <div className="text-[11px] opacity-80 mt-1">
                    💡 {issue.suggestion}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Basic Metadata */}
      <div className="space-y-4 text-xs">
        <div>
          <label className="text-[11px] font-mono text-slate-400 block mb-1">
            Node ID
          </label>
          <input
            type="text"
            readOnly
            value={node.id}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-400 font-mono text-xs cursor-not-allowed"
          />
        </div>

        <div>
          <label className="text-[11px] font-mono text-slate-400 block mb-1">
            Node Type
          </label>
          <div className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-sky-400 font-mono text-xs">
            {node.type}
          </div>
        </div>

        <div>
          <label className="text-[11px] font-mono text-slate-400 block mb-1">
            Label / Display Name
          </label>
          <input
            type="text"
            value={node.label}
            onChange={(e) => onUpdateLabel(node.id, e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-sky-500 text-xs"
          />
        </div>

        <div className="border-t border-slate-800 pt-3">
          <h3 className="text-[11px] font-mono uppercase text-slate-400 mb-3">
            Configuration Parameters
          </h3>

          {/* Config fields depending on node type */}
          {node.type === 'presentation_text' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Title</label>
                <input
                  type="text"
                  value={node.config.title || ''}
                  onChange={(e) => handleFieldChange('title', e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Markdown Content</label>
                <textarea
                  rows={4}
                  value={node.config.content_markdown || ''}
                  onChange={(e) => handleFieldChange('content_markdown', e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Continue Button Text</label>
                <input
                  type="text"
                  value={node.config.continue_button_text || 'Continue'}
                  onChange={(e) => handleFieldChange('continue_button_text', e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
            </div>
          )}

          {node.type === 'presentation_fixation' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Duration (ms)</label>
                <input
                  type="number"
                  value={node.config.duration_ms || 500}
                  onChange={(e) => handleFieldChange('duration_ms', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Random Jitter (ms)</label>
                <input
                  type="number"
                  value={node.config.jitter_ms || 150}
                  onChange={(e) => handleFieldChange('jitter_ms', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
            </div>
          )}

          {node.type === 'response_keyboard' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Allowed Keys (comma separated)</label>
                <input
                  type="text"
                  value={(node.config.allowed_keys || []).join(', ')}
                  onChange={(e) =>
                    handleFieldChange(
                      'allowed_keys',
                      e.target.value.split(',').map((k) => k.trim().toLowerCase()).filter(Boolean)
                    )
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Deadline (ms)</label>
                <input
                  type="number"
                  value={node.config.deadline_ms || 1500}
                  onChange={(e) => handleFieldChange('deadline_ms', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
            </div>
          )}

          {node.type === 'randomization_balanced_block' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Total Trials</label>
                <input
                  type="number"
                  value={node.config.total_trials || 30}
                  onChange={(e) => handleFieldChange('total_trials', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Max Consecutive Identical</label>
                <input
                  type="number"
                  value={node.config.max_consecutive_identical || 3}
                  onChange={(e) => handleFieldChange('max_consecutive_identical', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
            </div>
          )}

          {node.type === 'timing_wait' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Wait Duration (ms)</label>
                <input
                  type="number"
                  value={node.config.duration_ms || 350}
                  onChange={(e) => handleFieldChange('duration_ms', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
            </div>
          )}

          {node.type === 'game_reward' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Points Awarded</label>
                <input
                  type="number"
                  value={node.config.points || 100}
                  onChange={(e) => handleFieldChange('points', Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">HUD Feedback Text</label>
                <input
                  type="text"
                  value={node.config.feedback_text || '+100!'}
                  onChange={(e) => handleFieldChange('feedback_text', e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>
            </div>
          )}

          {/* Delete Action Button */}
          <div className="mt-8 pt-4 border-t border-slate-800">
            <button
              onClick={handleDelete}
              className="w-full py-2 px-3 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800 text-rose-300 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <Trash2 className="h-4 w-4" />
              <span>Delete Node</span>
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
