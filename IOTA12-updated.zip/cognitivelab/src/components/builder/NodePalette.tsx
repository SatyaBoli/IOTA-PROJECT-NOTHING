import React, { useState } from 'react';
import { 
  Plus, 
  Play, 
  Flag, 
  Type, 
  Crosshair, 
  Eye, 
  Keyboard, 
  GitFork, 
  Repeat, 
  Shuffle, 
  Trophy, 
  Clock, 
  Gauge, 
  Database,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { NodeType, DSLNode } from '../../types/dsl';

interface NodePaletteProps {
  onAddNode: (node: DSLNode) => void;
}

export const NodePalette: React.FC<NodePaletteProps> = ({ onAddNode }) => {
  const [isOpen, setIsOpen] = useState(false);

  const categories: {
    category: string;
    items: { type: NodeType; label: string; icon: React.ReactNode; defaultProps: Record<string, any> }[];
  }[] = [
    {
      category: 'Flow Control',
      items: [
        { type: 'flow_start', label: 'Start Entry', icon: <Play className="h-3.5 w-3.5 text-emerald-400" />, defaultProps: {} },
        { type: 'flow_end', label: 'End Terminate', icon: <Flag className="h-3.5 w-3.5 text-rose-400" />, defaultProps: {} },
      ]
    },
    {
      category: 'Presentation',
      items: [
        { 
          type: 'presentation_text', 
          label: 'Instructions / Debrief', 
          icon: <Type className="h-3.5 w-3.5 text-sky-400" />, 
          defaultProps: { title: 'Instruction Screen', content_markdown: '### Experiment Briefing\n\nFollow screen cues.', continue_button_text: 'Continue' } 
        },
        { 
          type: 'presentation_fixation', 
          label: 'Fixation Cross', 
          icon: <Crosshair className="h-3.5 w-3.5 text-indigo-400" />, 
          defaultProps: { shape: 'cross', color: '#94a3b8', duration_ms: 500, jitter_ms: 150 } 
        },
        { 
          type: 'presentation_stimulus', 
          label: 'Target Stimulus', 
          icon: <Eye className="h-3.5 w-3.5 text-amber-400" />, 
          defaultProps: { stimulus_type: 'dynamic_color_circle', diameter_px: 120, duration_max_ms: 1500 } 
        },
      ]
    },
    {
      category: 'Response Acquisition',
      items: [
        { 
          type: 'response_keyboard', 
          label: 'Keyboard Capture', 
          icon: <Keyboard className="h-3.5 w-3.5 text-purple-400" />, 
          defaultProps: { allowed_keys: ['a', 'l'], deadline_ms: 1500, record_rt: true } 
        },
      ]
    },
    {
      category: 'Timing & Hardware',
      items: [
        { 
          type: 'timing_wait', 
          label: 'Inter-Trial (ITI)', 
          icon: <Clock className="h-3.5 w-3.5 text-orange-400" />, 
          defaultProps: { duration_ms: 400 } 
        },
        { 
          type: 'timing_calibration', 
          label: 'Display Benchmark', 
          icon: <Gauge className="h-3.5 w-3.5 text-teal-400" />, 
          defaultProps: { measure_fps_frames: 120, reject_frame_jitter_ms: 8 } 
        },
      ]
    },
    {
      category: 'Logic & Randomization',
      items: [
        { 
          type: 'logic_condition', 
          label: 'Accuracy Branch', 
          icon: <GitFork className="h-3.5 w-3.5 text-cyan-400" />, 
          defaultProps: { condition_expression: 'response.key === variables.expected_key' } 
        },
        { 
          type: 'logic_loop', 
          label: 'Trial Loop', 
          icon: <Repeat className="h-3.5 w-3.5 text-blue-400" />, 
          defaultProps: { max_iterations: 30 } 
        },
        { 
          type: 'randomization_balanced_block', 
          label: 'Balanced Factorial Block', 
          icon: <Shuffle className="h-3.5 w-3.5 text-pink-400" />, 
          defaultProps: { total_trials: 30, repetitions_per_level: 15 } 
        },
      ]
    },
    {
      category: 'Game & Data',
      items: [
        { 
          type: 'game_reward', 
          label: 'Score & Streak', 
          icon: <Trophy className="h-3.5 w-3.5 text-yellow-400" />, 
          defaultProps: { points: 100, feedback_text: '+100 HIT!' } 
        },
        { 
          type: 'data_record_trial', 
          label: 'Record Trial Microdata', 
          icon: <Database className="h-3.5 w-3.5 text-emerald-400" />, 
          defaultProps: { persist_to_indexeddb: true } 
        },
      ]
    }
  ];

  const handleCreate = (item: typeof categories[0]['items'][0]) => {
    const id = `node_${item.type}_${Math.random().toString(36).substring(2, 6)}`;
    const newNode: DSLNode = {
      id,
      type: item.type,
      label: item.label,
      config: { ...item.defaultProps },
      position: { x: 300 + Math.floor(Math.random() * 200), y: 150 + Math.floor(Math.random() * 200) }
    };
    onAddNode(newNode);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs transition-all shadow-md shadow-sky-500/20"
      >
        <Plus className="h-4 w-4" />
        <span>Add Node</span>
        {isOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
      </button>

      {isOpen && (
        <div className="absolute top-10 left-0 w-72 bg-[#0d1322] border border-slate-800 rounded-2xl shadow-2xl p-3 z-50 max-h-[75vh] overflow-y-auto">
          <div className="text-[10px] font-mono uppercase text-slate-400 font-bold mb-2 pb-1 border-b border-slate-800">
            Node Blueprint Palette
          </div>

          <div className="space-y-3">
            {categories.map((cat) => (
              <div key={cat.category}>
                <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  {cat.category}
                </div>
                <div className="space-y-1">
                  {cat.items.map((item) => (
                    <button
                      key={item.type + item.label}
                      onClick={() => handleCreate(item)}
                      className="w-full flex items-center gap-2 p-1.5 rounded-lg bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 hover:border-sky-500/40 text-left text-xs text-slate-200 transition-colors group"
                    >
                      <div className="p-1 rounded bg-slate-800/90 border border-slate-700/50">
                        {item.icon}
                      </div>
                      <span className="group-hover:text-sky-300 font-medium">{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
