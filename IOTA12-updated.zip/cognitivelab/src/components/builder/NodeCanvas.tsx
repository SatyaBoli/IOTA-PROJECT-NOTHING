import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Flag, 
  Type, 
  Crosshair, 
  Eye, 
  Keyboard, 
  GitFork, 
  Repeat, 
  Shuffle, 
  Trophy, 
  Clock, 
  Gauge, 
  Database,
  ZoomIn,
  ZoomOut,
  Maximize2,
  AlertTriangle,
  LayoutGrid,
  Trash2,
  Link2
} from 'lucide-react';
import { DSLNode, DSLEdge, NodeType, ValidationIssue } from '../../types/dsl';
import { NodePalette } from './NodePalette';

interface NodeCanvasProps {
  nodes: DSLNode[];
  edges: DSLEdge[];
  selectedNodeId: string | null;
  onSelectNode: (id: string | null) => void;
  onUpdateNodePosition: (id: string, x: number, y: number) => void;
  onAddNode: (node: DSLNode) => void;
  onAddEdge: (from: string, to: string) => void;
  onDeleteEdge: (edgeId: string) => void;
  onDeleteNode: (nodeId: string) => void;
  onUpdateNodeLabel: (nodeId: string, newLabel: string) => void;
  onAutoLayout: () => void;
  validationIssues: ValidationIssue[];
}

const ZOOM_MIN = 0.4;
const ZOOM_MAX = 1.6;

export const NodeCanvas: React.FC<NodeCanvasProps> = ({
  nodes,
  edges,
  selectedNodeId,
  onSelectNode,
  onUpdateNodePosition,
  onAddNode,
  onAddEdge,
  onDeleteEdge,
  onDeleteNode,
  onUpdateNodeLabel,
  onAutoLayout,
  validationIssues
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.85);
  const [pan, setPan] = useState({ x: 30, y: 30 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  // Mirrors zoom/pan for use inside the native (non-React) wheel listener,
  // updated synchronously so rapid wheel ticks never read stale values.
  const viewRef = useRef({ zoom, pan });

  // Dragging state
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // Connecting wire state
  const [connectingSourceId, setConnectingSourceId] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  // Selected edge state
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);

  // Inline rename state
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null);
  const [editingDraft, setEditingDraft] = useState('');

  const getNodeIcon = (type: NodeType) => {
    switch (type) {
      case 'flow_start': return <Play className="h-4 w-4 text-emerald-400" />;
      case 'flow_end': return <Flag className="h-4 w-4 text-rose-400" />;
      case 'presentation_text': return <Type className="h-4 w-4 text-sky-400" />;
      case 'presentation_fixation': return <Crosshair className="h-4 w-4 text-indigo-400" />;
      case 'presentation_stimulus': return <Eye className="h-4 w-4 text-amber-400" />;
      case 'response_keyboard': return <Keyboard className="h-4 w-4 text-purple-400" />;
      case 'logic_condition': return <GitFork className="h-4 w-4 text-cyan-400" />;
      case 'logic_loop': return <Repeat className="h-4 w-4 text-blue-400" />;
      case 'randomization_balanced_block': return <Shuffle className="h-4 w-4 text-pink-400" />;
      case 'game_reward': return <Trophy className="h-4 w-4 text-yellow-400" />;
      case 'timing_wait': return <Clock className="h-4 w-4 text-orange-400" />;
      case 'timing_calibration': return <Gauge className="h-4 w-4 text-teal-400" />;
      case 'data_record_trial': return <Database className="h-4 w-4 text-emerald-400" />;
      default: return <Clock className="h-4 w-4 text-slate-400" />;
    }
  };

  const getNodeColor = (type: NodeType, isSelected: boolean, hasError: boolean) => {
    if (hasError) return 'border-rose-500 shadow-rose-500/30';
    if (isSelected) return 'border-sky-400 shadow-sky-400/40 ring-2 ring-sky-400/20';

    switch (type) {
      case 'flow_start':
      case 'flow_end':
        return 'border-emerald-600/60 bg-emerald-950/20';
      case 'logic_condition':
      case 'logic_loop':
        return 'border-blue-600/60 bg-blue-950/20';
      case 'randomization_balanced_block':
        return 'border-pink-600/60 bg-pink-950/20';
      case 'game_reward':
        return 'border-yellow-600/60 bg-yellow-950/20';
      case 'response_keyboard':
        return 'border-purple-600/60 bg-purple-950/20';
      default:
        return 'border-slate-700/80 bg-slate-900/60';
    }
  };

  const getNodePos = (nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId);
    return node?.position || { x: 100, y: 100 };
  };

  // Keep the ref in sync so the native wheel listener always sees current values.
  useEffect(() => {
    viewRef.current = { zoom, pan };
  }, [zoom, pan]);

  // Auto-center and fit nodes into viewport
  const fitToView = () => {
    if (!nodes.length || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const xs = nodes.map(n => n.position?.x ?? 100);
    const ys = nodes.map(n => n.position?.y ?? 100);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs) + 190;
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys) + 100;
    const graphWidth = maxX - minX;
    const graphHeight = maxY - minY;

    if (graphWidth <= 0 || graphHeight <= 0) return;

    const padding = 70;
    const scaleX = (rect.width - padding * 2) / graphWidth;
    const scaleY = (rect.height - padding * 2) / graphHeight;
    const nextZoom = Math.min(Math.max(Math.min(scaleX, scaleY), ZOOM_MIN), 1.0);

    const nextPan = {
      x: Math.round((rect.width - graphWidth * nextZoom) / 2 - minX * nextZoom),
      y: Math.round((rect.height - graphHeight * nextZoom) / 2 - minY * nextZoom)
    };

    setZoom(nextZoom);
    setPan(nextPan);
    viewRef.current = { zoom: nextZoom, pan: nextPan };
  };

  // Auto-fit on initial mount or when node structure changes (e.g. newly loaded or committed DSL)
  const lastNodeIdsRef = useRef<string>('');
  useEffect(() => {
    const currentSignature = nodes.map(n => n.id).sort().join(',');
    if (currentSignature && currentSignature !== lastNodeIdsRef.current) {
      lastNodeIdsRef.current = currentSignature;
      const t = setTimeout(() => {
        fitToView();
      }, 50);
      return () => clearTimeout(t);
    }
  }, [nodes]);

  // Window-level mouse move & mouse up to guarantee smooth drag
  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (isPanning) {
        setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
      } else if (draggingNodeId) {
        const newX = Math.round((e.clientX - pan.x) / zoom - dragOffset.x);
        const newY = Math.round((e.clientY - pan.y) / zoom - dragOffset.y);
        onUpdateNodePosition(draggingNodeId, newX, newY);
      } else if (connectingSourceId) {
        setMousePos({
          x: (e.clientX - pan.x) / zoom,
          y: (e.clientY - pan.y) / zoom
        });
      }
    };

    const handleGlobalMouseUp = () => {
      setIsPanning(false);
      setDraggingNodeId(null);
    };

    window.addEventListener('mousemove', handleGlobalMouseMove);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [isPanning, draggingNodeId, connectingSourceId, panStart, dragOffset, pan, zoom, onUpdateNodePosition]);

  // Scroll to pan, Ctrl/Cmd+scroll (or pinch) to zoom toward the cursor.
  // Bound once via a native listener (not React's onWheel) with
  // { passive: false } so preventDefault reliably stops page scroll.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const { zoom: curZoom, pan: curPan } = viewRef.current;
      const rect = container.getBoundingClientRect();

      if (e.ctrlKey || e.metaKey) {
        const cursorX = e.clientX - rect.left;
        const cursorY = e.clientY - rect.top;
        const worldX = (cursorX - curPan.x) / curZoom;
        const worldY = (cursorY - curPan.y) / curZoom;
        const nextZoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, curZoom * (1 - e.deltaY * 0.0015)));
        const nextPan = {
          x: cursorX - worldX * nextZoom,
          y: cursorY - worldY * nextZoom,
        };
        viewRef.current = { zoom: nextZoom, pan: nextPan };
        setZoom(nextZoom);
        setPan(nextPan);
      } else {
        const nextPan = { x: curPan.x - e.deltaX, y: curPan.y - e.deltaY };
        viewRef.current = { ...viewRef.current, pan: nextPan };
        setPan(nextPan);
      }
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, []);

  // Keyboard shortcuts: Escape to cancel/deselect, Delete/Backspace to remove
  // the selected node or wire. Skipped entirely while typing in any text
  // field elsewhere in the app (e.g. the Node Inspector or DSL editor).
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const active = document.activeElement as HTMLElement | null;
      const isTyping = !!active && (
        active.tagName === 'INPUT' ||
        active.tagName === 'TEXTAREA' ||
        active.isContentEditable
      );
      if (isTyping) return;

      if (e.key === 'Escape') {
        setConnectingSourceId(null);
        setSelectedEdgeId(null);
        onSelectNode(null);
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedEdgeId) {
          e.preventDefault();
          onDeleteEdge(selectedEdgeId);
          setSelectedEdgeId(null);
        } else if (selectedNodeId) {
          e.preventDefault();
          onDeleteNode(selectedNodeId);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedEdgeId, selectedNodeId, onDeleteEdge, onDeleteNode, onSelectNode]);

  // Handle canvas pan start
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.target === containerRef.current || (e.target as HTMLElement).tagName === 'svg') {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      onSelectNode(null);
      setSelectedEdgeId(null);
      if (connectingSourceId) setConnectingSourceId(null);
    }
  };

  const handleNodeDragStart = (e: React.MouseEvent, node: DSLNode) => {
    if (editingNodeId === node.id) return;
    e.stopPropagation();
    onSelectNode(node.id);
    setSelectedEdgeId(null);
    setDraggingNodeId(node.id);
    const pos = node.position || { x: 100, y: 100 };
    setDragOffset({
      x: (e.clientX - pan.x) / zoom - pos.x,
      y: (e.clientY - pan.y) / zoom - pos.y
    });
  };

  // Output pin: mousedown arms the wire so it can be either click-then-click
  // or click-and-drag straight to the target's input pin.
  const handleOutputPinDown = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation();
    setConnectingSourceId(nodeId);
    const pos = getNodePos(nodeId);
    setMousePos({ x: pos.x + 180, y: pos.y + 45 });
  };

  // Input pin: completes the wire whether the source pin was clicked
  // separately (onClick) or dragged and released here (onMouseUp).
  const handleInputPinComplete = (e: React.MouseEvent, targetNodeId: string) => {
    e.stopPropagation();
    if (connectingSourceId && connectingSourceId !== targetNodeId) {
      onAddEdge(connectingSourceId, targetNodeId);
      setConnectingSourceId(null);
    }
  };

  const startEditingLabel = (e: React.MouseEvent, node: DSLNode) => {
    e.stopPropagation();
    setEditingNodeId(node.id);
    setEditingDraft(node.label);
  };

  const commitEditingLabel = () => {
    if (editingNodeId && editingDraft.trim()) {
      onUpdateNodeLabel(editingNodeId, editingDraft.trim());
    }
    setEditingNodeId(null);
  };

  // Place a newly-added node in the center of the current viewport (not a
  // fixed world coordinate) so it's always visible where you're looking,
  // with a small cascade so repeated adds don't stack exactly on top of
  // each other.
  const handlePaletteAdd = (node: DSLNode) => {
    const rect = containerRef.current?.getBoundingClientRect();
    const center = rect
      ? {
          x: (rect.width / 2 - pan.x) / zoom,
          y: (rect.height / 2 - pan.y) / zoom,
        }
      : { x: 400, y: 250 };
    const cascade = (nodes.length % 5) * 28;

    onAddNode({
      ...node,
      position: {
        x: Math.round(center.x - 90 + cascade),
        y: Math.round(center.y - 40 + cascade),
      },
    });
  };

  return (
    <div 
      ref={containerRef}
      onMouseDown={handleMouseDown}
      className="relative w-full h-[calc(100vh-4rem)] overflow-hidden bg-[#070a13] bg-grid-pattern cursor-grab active:cursor-grabbing select-none"
    >
      {/* HUD Canvas Controls */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-800 shadow-xl">
        <NodePalette onAddNode={handlePaletteAdd} />

        <div className="w-[1px] h-5 bg-slate-800 mx-1" />

        <button
          onClick={onAutoLayout}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#070a13]"
          title="Auto-arrange nodes hierarchically"
        >
          <LayoutGrid className="h-3.5 w-3.5" />
          <span>Auto Layout</span>
        </button>

        <div className="w-[1px] h-5 bg-slate-800 mx-1" />

        <button
          onClick={() => setZoom(z => Math.min(z + 0.15, ZOOM_MAX))}
          className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/70"
          title="Zoom In"
          aria-label="Zoom in"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <span className="text-[11px] font-mono px-2 text-slate-400 tabular-nums">
          {Math.round(zoom * 100)}%
        </span>
        <button
          onClick={() => setZoom(z => Math.max(z - 0.15, ZOOM_MIN))}
          className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/70"
          title="Zoom Out"
          aria-label="Zoom out"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
        <button
          onClick={fitToView}
          className="p-1.5 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/70"
          title="Fit Graph to View"
          aria-label="Fit graph to view"
        >
          <Maximize2 className="h-4 w-4" />
        </button>

        {selectedEdgeId && (
          <button
            onClick={() => {
              onDeleteEdge(selectedEdgeId);
              setSelectedEdgeId(null);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs font-semibold hover:bg-rose-900 transition-colors ml-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400/70"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Delete Selected Wire</span>
          </button>
        )}
      </div>

      {/* Connecting-mode hint */}
      {connectingSourceId && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-sky-950/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-sky-500/40 text-[11px] font-mono text-sky-300 shadow-lg shadow-sky-500/10 pointer-events-none">
          <Link2 className="h-3.5 w-3.5 animate-pulse" />
          <span>
            Drag to a node's input pin to connect
            <kbd className="ml-2 px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">Esc</kbd>
            <span className="ml-1 text-slate-400">to cancel</span>
          </span>
        </div>
      )}

      {/* Empty-state guidance */}
      {nodes.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
          <div className="text-center max-w-xs px-4">
            <div className="text-sm font-semibold text-slate-300 mb-1">No nodes yet</div>
            <div className="text-xs text-slate-500">
              Use "Add Node" in the top-left to start building your experiment flow.
            </div>
          </div>
        </div>
      )}

      {/* Blueprint Subtitle */}
      <div className="absolute bottom-4 left-4 z-20 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-1 max-w-[calc(100vw-2rem)]">
        <span><strong className="text-slate-200">Blueprint Visual Scripting</strong> • Drag nodes to reposition</span>
        <span>• <span className="text-indigo-400">Drag right pin → left pin</span> to wire nodes</span>
        <span>• Double-click a title to rename</span>
        <span>• Scroll to pan, <kbd className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700">Ctrl</kbd>+Scroll to zoom</span>
      </div>

      {/* Main Pan/Zoom World Container */}
      <div
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: '0 0',
          width: '4500px',
          height: '2500px',
        }}
        className="relative"
      >
        {/* SVG Bezier Wire Connections */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <defs>
            <linearGradient id="wire-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#818cf8" stopOpacity="0.8" />
            </linearGradient>
            <linearGradient id="wire-true" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#22c55e" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#4ade80" stopOpacity="0.8" />
            </linearGradient>
            <linearGradient id="wire-false" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#f87171" stopOpacity="0.8" />
            </linearGradient>
            <linearGradient id="wire-selected" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="1" />
              <stop offset="100%" stopColor="#fbbf24" stopOpacity="1" />
            </linearGradient>
          </defs>

          {edges.map((edge) => {
            const fromPos = getNodePos(edge.from);
            const toPos = getNodePos(edge.to);

            const startX = fromPos.x + 180;
            const startY = fromPos.y + 45;
            const endX = toPos.x;
            const endY = toPos.y + 45;

            const controlDist = Math.max(Math.abs(endX - startX) * 0.5, 40);
            const pathData = `M ${startX} ${startY} C ${startX + controlDist} ${startY}, ${endX - controlDist} ${endY}, ${endX} ${endY}`;

            const isSelected = selectedEdgeId === edge.id;
            let strokeColor = "url(#wire-gradient)";
            if (isSelected) strokeColor = "url(#wire-selected)";
            else if (edge.port === 'true' || edge.label?.toLowerCase().includes('correct')) strokeColor = "url(#wire-true)";
            else if (edge.port === 'false' || edge.label?.toLowerCase().includes('incorrect')) strokeColor = "url(#wire-false)";

            return (
              <g 
                key={edge.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedEdgeId(edge.id);
                  onSelectNode(null);
                }}
              >
                {/* Thick invisible hit-target for easy wire clicking */}
                <path
                  d={pathData}
                  fill="none"
                  stroke="transparent"
                  strokeWidth="16"
                />
                {/* Outer shadow line */}
                <path
                  d={pathData}
                  fill="none"
                  stroke={isSelected ? '#f59e0b' : '#0284c7'}
                  strokeOpacity={isSelected ? 0.6 : 0.2}
                  strokeWidth={isSelected ? 8 : 6}
                />
                {/* Main animated wire */}
                <path
                  d={pathData}
                  fill="none"
                  stroke={strokeColor}
                  strokeWidth={isSelected ? 3.5 : 2.5}
                  className="wire-animated"
                />
                {/* Optional Port / Condition Label */}
                {edge.label && (
                  <text
                    x={(startX + endX) / 2}
                    y={(startY + endY) / 2 - 8}
                    fill={isSelected ? '#fbbf24' : '#94a3b8'}
                    fontSize="11"
                    fontFamily="JetBrains Mono"
                    textAnchor="middle"
                    className="select-none pointer-events-none"
                  >
                    {edge.label}
                  </text>
                )}
              </g>
            );
          })}

          {/* Currently dragging wire in creation mode */}
          {connectingSourceId && (
            <path
              d={`M ${getNodePos(connectingSourceId).x + 180} ${getNodePos(connectingSourceId).y + 45} C ${getNodePos(connectingSourceId).x + 240} ${getNodePos(connectingSourceId).y + 45}, ${mousePos.x - 60} ${mousePos.y}, ${mousePos.x} ${mousePos.y}`}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2.5"
              strokeDasharray="4 4"
            />
          )}
        </svg>

        {/* Nodes Layer */}
        {nodes.map((node) => {
          const isSelected = selectedNodeId === node.id;
          const pos = node.position || { x: 100, y: 100 };
          const hasError = validationIssues.some(i => i.nodeId === node.id && i.severity === 'critical');
          const isEditing = editingNodeId === node.id;

          return (
            <div
              key={node.id}
              onMouseDown={(e) => handleNodeDragStart(e, node)}
              style={{
                transform: `translate(${pos.x}px, ${pos.y}px)`,
                width: '180px',
              }}
              className={`absolute z-10 rounded-xl border p-3 cursor-move transition-all duration-150 hover:-translate-y-0.5 backdrop-blur-md shadow-lg hover:shadow-xl ${getNodeColor(
                node.type,
                isSelected,
                hasError
              )}`}
            >
              {/* Header */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-md bg-slate-800/80 border border-slate-700/50">
                    {getNodeIcon(node.type)}
                  </div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                    {node.type.replace(/_/g, ' ')}
                  </span>
                </div>
                {hasError && (
                  <AlertTriangle className="h-4 w-4 text-rose-400 animate-bounce" />
                )}
              </div>

              {/* Title / Label */}
              {isEditing ? (
                <input
                  autoFocus
                  value={editingDraft}
                  onChange={(e) => setEditingDraft(e.target.value)}
                  onBlur={commitEditingLabel}
                  onMouseDown={(e) => e.stopPropagation()}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') commitEditingLabel();
                    if (e.key === 'Escape') setEditingNodeId(null);
                  }}
                  className="w-full bg-slate-950 border border-sky-500 rounded-md px-1.5 py-0.5 text-xs font-semibold text-white focus:outline-none"
                />
              ) : (
                <div
                  onDoubleClick={(e) => startEditingLabel(e, node)}
                  title={`${node.label} — double-click to rename`}
                  className="text-xs font-semibold text-slate-100 truncate cursor-text"
                >
                  {node.label}
                </div>
              )}

              {/* Small details / params preview */}
              <div className="mt-2 text-[10px] font-mono text-slate-400 border-t border-slate-800/60 pt-1.5 flex justify-between">
                <span>id: {node.id.replace('node_', '')}</span>
                {node.config.duration_ms && (
                  <span>{node.config.duration_ms}ms</span>
                )}
                {node.config.total_trials && (
                  <span>{node.config.total_trials} trials</span>
                )}
              </div>

              {/* Input Pin (Target) - click, or drop a dragged wire, to connect */}
              <div 
                onClick={(e) => handleInputPinComplete(e, node.id)}
                onMouseUp={(e) => handleInputPinComplete(e, node.id)}
                title="Input pin — click or drop a wire here"
                role="button"
                aria-label={`${node.label} input pin`}
                className={`absolute -left-2.5 top-[34px] w-5 h-5 rounded-full bg-slate-900 border-2 cursor-pointer transition-transform hover:scale-125 z-20 ${
                  connectingSourceId && connectingSourceId !== node.id
                    ? 'border-emerald-400 ring-2 ring-emerald-400/40 animate-ping'
                    : 'border-sky-400'
                }`}
              />

              {/* Output Pin (Source) - press and drag to wire, or click then click the target's input */}
              <div 
                onMouseDown={(e) => handleOutputPinDown(e, node.id)}
                title="Output pin — drag to another node's input"
                role="button"
                aria-label={`${node.label} output pin`}
                className={`absolute -right-2.5 top-[34px] w-5 h-5 rounded-full bg-slate-900 border-2 cursor-pointer transition-transform hover:scale-125 z-20 ${
                  connectingSourceId === node.id 
                    ? 'border-amber-400 ring-2 ring-amber-400/40' 
                    : 'border-indigo-400'
                }`}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
