import React, { useState, useEffect } from 'react';
import { 
  Radio, 
  Activity, 
  Monitor, 
  ShieldAlert, 
  CheckCircle2, 
  Pause, 
  Play, 
  RefreshCw, 
  Wifi, 
  Cpu, 
  Clock,
  Layers,
  ArrowRight
} from 'lucide-react';
import { ExperimentDSL } from '../../types/dsl';

interface LiveMonitoringProps {
  dsl: ExperimentDSL;
  onNavigateToAnalytics?: () => void;
}

interface ActiveSessionTelemetry {
  sessionId: string;
  device: string;
  os: string;
  browser: string;
  currentTrial: number;
  totalTrials: number;
  rollingAccuracy: number;
  frameJitterMs: number;
  pingMs: number;
  status: 'streaming' | 'completed' | 'paused';
  lastEventTime: string;
}

export const LiveMonitoring: React.FC<LiveMonitoringProps> = ({
  dsl,
  onNavigateToAnalytics
}) => {
  const [isLiveStreaming, setIsLiveStreaming] = useState(true);
  const [sessions, setSessions] = useState<ActiveSessionTelemetry[]>([
    {
      sessionId: 'sess_8829a',
      device: 'Desktop',
      os: 'Windows 11',
      browser: 'Chrome 128',
      currentTrial: 24,
      totalTrials: 32,
      rollingAccuracy: 95.8,
      frameJitterMs: 0.24,
      pingMs: 28,
      status: 'streaming',
      lastEventTime: '2s ago'
    },
    {
      sessionId: 'sess_9912b',
      device: 'Desktop',
      os: 'macOS Sonoma',
      browser: 'Safari 17.5',
      currentTrial: 18,
      totalTrials: 32,
      rollingAccuracy: 100.0,
      frameJitterMs: 0.38,
      pingMs: 42,
      status: 'streaming',
      lastEventTime: '1s ago'
    },
    {
      sessionId: 'sess_7741c',
      device: 'Mobile',
      os: 'Android 14',
      browser: 'Chrome Mobile',
      currentTrial: 8,
      totalTrials: 32,
      rollingAccuracy: 62.5,
      frameJitterMs: 4.82,
      pingMs: 118,
      status: 'streaming',
      lastEventTime: '5s ago'
    },
    {
      sessionId: 'sess_6623d',
      device: 'Desktop',
      os: 'Ubuntu 24.04',
      browser: 'Firefox 129',
      currentTrial: 32,
      totalTrials: 32,
      rollingAccuracy: 93.8,
      frameJitterMs: 0.65,
      pingMs: 34,
      status: 'completed',
      lastEventTime: '12s ago'
    }
  ]);

  // Periodic heartbeat tick to simulate active real-time socket ingestion
  useEffect(() => {
    if (!isLiveStreaming) return;

    const interval = setInterval(() => {
      setSessions(prev => prev.map(s => {
        if (s.status !== 'streaming' || s.currentTrial >= s.totalTrials) {
          return { ...s, status: 'completed' };
        }
        const nextTrial = Math.min(s.currentTrial + 1, s.totalTrials);
        const correctBump = Math.random() > 0.1 ? 1 : 0;
        const newAcc = Math.round(((s.rollingAccuracy * s.currentTrial + correctBump * 100) / nextTrial) * 10) / 10;
        return {
          ...s,
          currentTrial: nextTrial,
          rollingAccuracy: newAcc,
          pingMs: Math.max(20, Math.round(s.pingMs + (Math.random() - 0.5) * 8)),
          lastEventTime: 'just now',
          status: nextTrial >= s.totalTrials ? 'completed' : 'streaming'
        };
      }));
    }, 2800);

    return () => clearInterval(interval);
  }, [isLiveStreaming]);

  const activeCount = sessions.filter(s => s.status === 'streaming').length;
  const completedCount = sessions.filter(s => s.status === 'completed').length;

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase bg-sky-950/80 text-sky-400 border border-sky-800 px-2 py-0.5 rounded-full flex items-center gap-1.5">
              <span className={`h-2 w-2 rounded-full ${isLiveStreaming ? 'bg-sky-400 animate-ping' : 'bg-slate-500'}`} />
              <span>WebSocket Ingestion Bus</span>
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Protocol: {dsl.experiment.title}</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Live Participant Telemetry & Session Monitoring
          </h1>
          <p className="text-xs text-slate-400">
            Real-time stream of connected participants, active trial progression, and hardware V-Sync frame quality diagnostics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsLiveStreaming(!isLiveStreaming)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              isLiveStreaming
                ? 'bg-amber-950/40 border-amber-500/50 text-amber-300'
                : 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
            }`}
          >
            {isLiveStreaming ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            <span>{isLiveStreaming ? 'Pause Stream' : 'Resume Stream'}</span>
          </button>

          {onNavigateToAnalytics && (
            <button
              onClick={onNavigateToAnalytics}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition-all"
            >
              <span>View Analytics</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Top Telemetry KPI Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Active Sockets</div>
          <div className="text-xl font-bold text-sky-400 font-mono flex items-center gap-2">
            <span>{activeCount} Connected</span>
            <Radio className="h-4 w-4 animate-pulse" />
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Streaming events</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Completed Today</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            {completedCount} <span className="text-xs text-slate-500 font-normal">Sessions</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Zero data loss</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Mean V-Sync Jitter</div>
          <div className="text-xl font-bold text-purple-300 font-mono">
            0.42 <span className="text-xs text-slate-500 font-normal">ms</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-mono mt-0.5">Hardware stable</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Average Latency</div>
          <div className="text-xl font-bold text-white font-mono">
            35 <span className="text-xs text-slate-500 font-normal">ms</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Low packet delay</div>
        </div>
      </div>

      {/* Real-time Session Table */}
      <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-sky-400" />
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Connected Participants Ingestion Stream
            </h3>
          </div>
          <span className="text-[10px] font-mono text-slate-500">Live Socket Feed</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="text-[10px] uppercase font-mono text-slate-500 bg-slate-900/60 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Session Hash</th>
                <th className="py-2.5 px-3">Device / Browser</th>
                <th className="py-2.5 px-3">Trial Progress</th>
                <th className="py-2.5 px-3">Rolling Accuracy</th>
                <th className="py-2.5 px-3">V-Sync Jitter</th>
                <th className="py-2.5 px-3">Network Ping</th>
                <th className="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              {sessions.map(s => {
                const isJitterProblem = s.frameJitterMs > 3.0;
                return (
                  <tr key={s.sessionId} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-3 font-semibold text-slate-300">{s.sessionId}</td>
                    <td className="py-3 px-3 text-slate-400 font-sans">
                      <div className="font-semibold text-white text-[11px]">{s.device} • {s.browser}</div>
                      <div className="text-[10px] text-slate-500">{s.os}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-bold">{s.currentTrial}</span>
                        <span className="text-slate-500 text-[10px]">/ {s.totalTrials}</span>
                      </div>
                      <div className="w-24 bg-slate-800 h-1.5 rounded-full mt-1 overflow-hidden">
                        <div 
                          className="bg-sky-500 h-full transition-all duration-300" 
                          style={{ width: `${(s.currentTrial / s.totalTrials) * 100}%` }}
                        />
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`font-bold ${s.rollingAccuracy >= 80 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {s.rollingAccuracy}%
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center gap-1 ${isJitterProblem ? 'text-rose-400 font-bold' : 'text-emerald-400'}`}>
                        {isJitterProblem && <ShieldAlert className="h-3.5 w-3.5" />}
                        <span>{s.frameJitterMs} ms</span>
                      </span>
                      {isJitterProblem && (
                        <div className="text-[9px] text-rose-400 font-sans">Mobile throttle flag</div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-slate-400">
                      <span className="flex items-center gap-1">
                        <Wifi className="h-3 w-3 text-slate-500" />
                        <span>{s.pingMs} ms</span>
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full ${
                        s.status === 'streaming'
                          ? 'bg-sky-950/60 text-sky-400 border border-sky-800'
                          : 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                      }`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${s.status === 'streaming' ? 'bg-sky-400 animate-ping' : 'bg-emerald-400'}`} />
                        <span className="capitalize">{s.status}</span>
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
