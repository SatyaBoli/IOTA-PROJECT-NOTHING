import React, { useState, useEffect } from 'react';
import { 
  Download, 
  FileCode, 
  Database, 
  Copy, 
  Check, 
  Table, 
  Filter, 
  Search, 
  Code,
  FileSpreadsheet
} from 'lucide-react';
import { ExperimentDSL, TrialRecord } from '../../types/dsl';
import { LocalExperimentStorage } from '../../runtime/storage';
import { Exporter } from '../../export/Exporter';

interface ExportHubProps {
  dsl: ExperimentDSL;
}

export const ExportHub: React.FC<ExportHubProps> = ({ dsl }) => {
  const [trials, setTrials] = useState<TrialRecord[]>([]);
  const [copiedScript, setCopiedScript] = useState<'r' | 'py' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'explorer' | 'scripts'>('explorer');

  useEffect(() => {
    LocalExperimentStorage.getAllStoredTrials().then(data => {
      setTrials(data);
    });
  }, []);

  const filteredTrials = trials.filter(t => {
    return t.condition.toLowerCase().includes(searchQuery.toLowerCase()) ||
           t.sessionId.toLowerCase().includes(searchQuery.toLowerCase()) ||
           (t.stimulus && t.stimulus.toLowerCase().includes(searchQuery.toLowerCase()));
  });

  // Generates canonical executable R replication script
  const generateRScript = () => {
    return `# ==============================================================================
# CognitiveLab Reproducible R Replication Script
# Experiment: ${dsl.experiment.title}
# Generated: ${new Date().toISOString()}
# ==============================================================================

# 1. Load Required Scientific Packages
if (!require("tidyverse")) install.packages("tidyverse")
if (!require("lme4")) install.packages("lme4")
library(tidyverse)
library(lme4)

# 2. Ingest Tidy Long CSV Dataset
data <- read_csv("trials_long.csv", col_types = cols())

cat("=== DATASET SUMMARY ===\\n")
cat("Total Rows: ", nrow(data), "\\n")
cat("Subjects (N): ", n_distinct(data$session_id), "\\n")

# 3. Apply Quality Hygiene Filters (Exclude fast guesses & timeouts)
clean_data <- data %>%
  filter(!is.na(reaction_time_ms)) %>%
  filter(reaction_time_ms >= 150 & reaction_time_ms <= 2000) %>%
  filter(is_correct == TRUE)

# Response distribution works for both timed and non-timed study templates.
response_summary <- data %>%
  filter(!is.na(response_value)) %>%
  count(condition, response_value, name = "response_count")
cat("\\n=== RESPONSE DISTRIBUTIONS ===\\n")
print(response_summary)

# 4. Condition Aggregations
condition_summary <- clean_data %>%
  group_by(condition) %>%
  summarize(
    N = n(),
    Mean_RT = mean(reaction_time_ms),
    SD_RT = sd(reaction_time_ms),
    Median_RT = median(reaction_time_ms),
    IQR_RT = IQR(reaction_time_ms),
    SEM_RT = sd(reaction_time_ms) / sqrt(n())
  )

print(condition_summary)

# 5. Inferential Testing: Linear Mixed-Effects Model (LMM)
# Random intercepts for subject variance: reactionTimeMs ~ condition + (1 | sessionId)
if (nrow(clean_data) > 0) {
  lmm_model <- lmer(reaction_time_ms ~ condition + (1 | session_id), data = clean_data)
  cat("\\n=== LINEAR MIXED-EFFECTS MODEL SUMMARY ===\\n")
  print(summary(lmm_model))

# 6. Generate Publication-Quality Visual Plot (ggplot2)
ggplot(clean_data, aes(x = condition, y = reaction_time_ms, fill = condition)) +
  geom_violin(alpha = 0.5, trim = FALSE) +
  geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.8) +
  theme_minimal(base_size = 14) +
  labs(
    title = "${dsl.experiment.title}",
    subtitle = "Reaction Time Distributions Across Experimental Conditions",
    x = "Condition",
    y = "Reaction Time (ms)"
  ) +
  theme(legend.position = "none")

ggsave("reaction_time_distributions.png", width = 8, height = 6, dpi = 300)
cat("\\nPlot saved to reaction_time_distributions.png\\n")
} else {
  cat("No usable reaction-time observations are present; response distributions above still apply.\\n")
}
`;
  };

  // Generates canonical executable Python replication script
  const generatePythonScript = () => {
    return `# ==============================================================================
# CognitiveLab Reproducible Python Replication Script
# Experiment: ${dsl.experiment.title}
# Generated: ${new Date().toISOString()}
# ==============================================================================

import pandas as pd
import numpy as np
from scipy import stats
import seaborn as sns
import matplotlib.pyplot as plt

# 1. Ingest Dataset
df = pd.read_csv("trials_long.csv")
print(f"Total Rows: {len(df)}, Unique Subjects: {df['session_id'].nunique()}")

# 2. Apply Non-Destructive Quality Filters
clean = df[
    (df['reaction_time_ms'].notnull()) &
    (df['reaction_time_ms'] >= 150) &
    (df['reaction_time_ms'] <= 2000) &
    (df['is_correct'] == True)
].copy()

response_summary = df.dropna(subset=['response_value']).groupby(['condition', 'response_value']).size().reset_index(name='response_count')
print("\\n=== RESPONSE DISTRIBUTIONS ===")
print(response_summary)

# 3. Descriptive Statistics
summary = clean.groupby('condition')['reaction_time_ms'].agg(
    n='count',
    mean='mean',
    std='std',
    median='median'
).reset_index()
print("\\n=== CONDITION DESCRIPTIVES ===")
print(summary)

# 4. Inferential Welch's t-test between first two conditions
conditions = clean['condition'].unique()
if len(conditions) >= 2:
    grp_a = clean[clean['condition'] == conditions[0]]['reaction_time_ms']
    grp_b = clean[clean['condition'] == conditions[1]]['reaction_time_ms']
    t_stat, p_val = stats.ttest_ind(grp_a, grp_b, equal_var=False)
    
    # Cohen's d
    pooled_sd = np.sqrt(((len(grp_a) - 1)*grp_a.var() + (len(grp_b) - 1)*grp_b.var()) / (len(grp_a) + len(grp_b) - 2))
    cohens_d = (grp_b.mean() - grp_a.mean()) / pooled_sd
    
    print(f"\\n=== WELCH'S T-TEST: {conditions[0]} vs {conditions[1]} ===")
    print(f"t-statistic: {t_stat:.3f}, p-value: {p_val:.4e}, Cohen's d: {cohens_d:.3f}")

# 5. Publication Plot
plt.figure(figsize=(8, 6))
if not clean.empty:
    sns.violinplot(data=clean, x='condition', y='reaction_time_ms', inner='quartile', palette='Set2')
    plt.title("${dsl.experiment.title}\\nReaction Time Distributions")
    plt.ylabel("Reaction Time (ms)")
    plt.savefig("reaction_time_plot_python.png", dpi=300)
    print("\\nPlot exported to reaction_time_plot_python.png")
else:
    print("No usable reaction-time observations; response distributions are still available above.")
`;
  };

  const handleCopy = (codeText: string, type: 'r' | 'py') => {
    navigator.clipboard.writeText(codeText);
    setCopiedScript(type);
    setTimeout(() => setCopiedScript(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase bg-emerald-950/80 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded-full">
              RFC 4180 & Open Science Compliant
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Dataset: {trials.length} Total Records</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Dataset Explorer & Replication Export Hub
          </h1>
          <p className="text-xs text-slate-400">
            Inspect raw trial events or export publication-ready datasets and executable R/Python replication scripts.
          </p>
        </div>

        {/* Global CSV Download Triggers */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => Exporter.downloadLongCSV(trials, dsl)}
            disabled={trials.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-xs font-semibold shadow-sm transition-all"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download Long CSV</span>
          </button>

          <button
            onClick={() => Exporter.downloadWideCSV(trials, dsl)}
            disabled={trials.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold transition-all"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-purple-400" />
            <span>Download Wide CSV</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('explorer')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'explorer'
              ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Table className="h-4 w-4" />
          <span>Raw Trial Explorer ({trials.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('scripts')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'scripts'
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="h-4 w-4" />
          <span>Replication Scripts (R & Python)</span>
        </button>
      </div>

      {/* VIEW 1: RAW TRIAL-LEVEL TABLE EXPLORER */}
      {activeTab === 'explorer' && (
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white">
              <Search className="h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="Filter by condition, session, stimulus..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent outline-none text-xs w-48 sm:w-64"
              />
            </div>
            <span className="text-[10px] font-mono text-slate-500">
              Showing {filteredTrials.length} of {trials.length} records
            </span>
          </div>

          {filteredTrials.length > 0 ? (
            <div className="overflow-x-auto max-h-[500px]">
              <table className="w-full text-xs text-left">
                <thead className="text-[10px] uppercase font-mono text-slate-500 bg-slate-900/80 sticky top-0 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Row ID</th>
                    <th className="py-2.5 px-3">Session</th>
                    <th className="py-2.5 px-3">Trial #</th>
                    <th className="py-2.5 px-3">Condition</th>
                    <th className="py-2.5 px-3">Stimulus</th>
                    <th className="py-2.5 px-3">Key Pressed</th>
                    <th className="py-2.5 px-3">Expected</th>
                    <th className="py-2.5 px-3">RT (ms)</th>
                    <th className="py-2.5 px-3">Outcome</th>
                    <th className="py-2.5 px-3 text-right">Flags</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 font-mono">
                  {filteredTrials.map((t, idx) => (
                    <tr key={t.id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-2.5 px-3 text-slate-500 text-[10px]">{t.id.substring(0, 10)}</td>
                      <td className="py-2.5 px-3 text-slate-400 font-semibold">{t.sessionId}</td>
                      <td className="py-2.5 px-3 text-white font-bold">{t.trialIndex}</td>
                      <td className="py-2.5 px-3 text-sky-300 font-sans">{t.condition}</td>
                      <td className="py-2.5 px-3 text-slate-300 font-sans">{t.stimulus}</td>
                      <td className="py-2.5 px-3 font-bold uppercase">{t.responseKey || '-'}</td>
                      <td className="py-2.5 px-3 text-slate-400 uppercase">{t.expectedKey}</td>
                      <td className="py-2.5 px-3 text-purple-300">{t.reactionTimeMs ? `${t.reactionTimeMs} ms` : 'timeout'}</td>
                      <td className="py-2.5 px-3 font-sans">
                        {t.isCorrect ? (
                          <span className="text-emerald-400 font-bold">✓ Hit</span>
                        ) : (
                          <span className="text-rose-400 font-bold">✗ Error</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {t.qualityFlags && t.qualityFlags.length > 0 ? (
                          <span className="text-amber-400 text-[10px] bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800">
                            {t.qualityFlags.join(', ')}
                          </span>
                        ) : (
                          <span className="text-slate-600 text-[10px]">clean</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-slate-500 font-mono">
              No trial records match your query.
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: REPRODUCIBLE SCIENTIFIC CODE GENERATION */}
      {activeTab === 'scripts' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* R Replication Script */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider">
                  <Code className="h-4 w-4" />
                  <span>R Script (tidyverse + lme4 + ggplot2)</span>
                </div>
                <button
                  onClick={() => handleCopy(generateRScript(), 'r')}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 hover:text-white"
                >
                  {copiedScript === 'r' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedScript === 'r' ? 'Copied!' : 'Copy Code'}</span>
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-300 max-h-96 overflow-y-auto leading-relaxed">
                {generateRScript()}
              </pre>
            </div>
            <div className="text-[11px] text-slate-500">
              Ready-to-run script for Linear Mixed-Effects Modeling and publication-grade violin plots.
            </div>
          </div>

          {/* Python Replication Script */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase tracking-wider">
                  <Code className="h-4 w-4" />
                  <span>Python Script (pandas + scipy + seaborn)</span>
                </div>
                <button
                  onClick={() => handleCopy(generatePythonScript(), 'py')}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 hover:text-white"
                >
                  {copiedScript === 'py' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedScript === 'py' ? 'Copied!' : 'Copy Code'}</span>
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-300 max-h-96 overflow-y-auto leading-relaxed">
                {generatePythonScript()}
              </pre>
            </div>
            <div className="text-[11px] text-slate-500">
              Executable Jupyter / Python script for Welch's t-test, Cohen's d, and distribution plotting.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
