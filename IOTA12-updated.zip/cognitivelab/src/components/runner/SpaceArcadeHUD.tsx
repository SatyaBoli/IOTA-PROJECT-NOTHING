import React from 'react';
import { Shield, Zap, Flame, Trophy } from 'lucide-react';

interface SpaceArcadeHUDProps {
  score: number;
  streak: number;
  trialCurrent: number;
  trialTotal: number;
  feedbackText: string | null;
  feedbackColor: string | null;
}

export const SpaceArcadeHUD: React.FC<SpaceArcadeHUDProps> = ({
  score,
  streak,
  trialCurrent,
  trialTotal,
  feedbackText,
  feedbackColor
}) => {
  const progressPercent = Math.round((trialCurrent / trialTotal) * 100);

  return (
    <div className="absolute inset-x-0 top-0 pointer-events-none p-4 select-none z-20">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-4 bg-slate-950/70 backdrop-blur-md px-5 py-3 rounded-2xl border border-sky-500/30 shadow-xl shadow-sky-950/40">
        {/* Mission Sector / Progress */}
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-sky-500/20 border border-sky-400/40 flex items-center justify-center">
            <Zap className="h-4 w-4 text-sky-400" />
          </div>
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
              Sector Orbit
            </div>
            <div className="text-xs font-bold font-mono text-white">
              {trialCurrent} / {trialTotal} <span className="text-[10px] text-slate-400">({progressPercent}%)</span>
            </div>
          </div>
        </div>

        {/* Central Feedback Pop-up */}
        <div className="h-8 flex items-center justify-center">
          {feedbackText && (
            <div 
              style={{ color: feedbackColor || '#22c55e' }}
              className="text-sm font-black font-mono tracking-widest uppercase animate-bounce"
            >
              {feedbackText}
            </div>
          )}
        </div>

        {/* Right Stats: Combo Streak & Score */}
        <div className="flex items-center gap-6">
          {/* Streak Combo */}
          <div className="flex items-center gap-2">
            <Flame className={`h-5 w-5 ${streak >= 3 ? 'text-amber-400 animate-pulse' : 'text-slate-500'}`} />
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                Combo Streak
              </div>
              <div className="text-xs font-extrabold font-mono text-amber-400">
                {streak}x {streak >= 5 ? '🔥 WARP' : ''}
              </div>
            </div>
          </div>

          {/* Credits / Points */}
          <div className="flex items-center gap-2 border-l border-slate-800 pl-4">
            <Trophy className="h-5 w-5 text-yellow-400" />
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                Bounty Points
              </div>
              <div className="text-sm font-black font-mono text-yellow-300">
                {score.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Line */}
      <div className="max-w-4xl mx-auto mt-2 h-1 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
        <div 
          className="h-full bg-gradient-to-r from-sky-500 to-indigo-500 transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </div>
  );
};
