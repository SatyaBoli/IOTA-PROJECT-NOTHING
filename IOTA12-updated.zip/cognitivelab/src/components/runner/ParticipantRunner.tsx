import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ShieldCheck, 
  Gauge, 
  HelpCircle, 
  CheckCircle, 
  ArrowRight, 
  RotateCcw, 
  Check, 
  Clock, 
  Sparkles,
  BookOpen,
  Volume2,
  Trees,
  Compass,
  HelpCircle as QuestionIcon,
  Send,
  Layers,
  Award
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExperimentDSL, TrialRecord, ResponseType } from '../../types/dsl';
import { HighPrecisionTimer } from '../../runtime/timing';
import { soundEffects } from '../../runtime/audio';
import { LocalExperimentStorage } from '../../runtime/storage';
import { ExperimentCompiler, CompiledExperiment, CompiledTrialItem } from '../../runtime/compiler';
import { SpaceArcadeHUD } from './SpaceArcadeHUD';

type RunnerStage = 
  | 'CONSENT'
  | 'CALIBRATION'
  | 'INSTRUCTIONS'
  | 'PRACTICE'
  | 'RUNNING'
  | 'DEBRIEF';

interface ParticipantRunnerProps {
  dsl: ExperimentDSL;
  onSessionComplete: () => void;
}

export const ParticipantRunner: React.FC<ParticipantRunnerProps> = ({
  dsl,
  onSessionComplete
}) => {
  const [stage, setStage] = useState<RunnerStage>('CONSENT');
  const [consentChecked, setConsentChecked] = useState(false);
  const [sessionId] = useState<string>(() => `sess_${Math.random().toString(36).substring(2, 10)}`);
  const [sessionSeed] = useState<number>(() => Math.floor(Math.random() * 1000000));
  const [pseudonymToken] = useState<string>(() => `ANON-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
  
  // Compile the experiment DSL into executable plan
  const compiled: CompiledExperiment = useMemo(() => {
    return ExperimentCompiler.compile(dsl, sessionSeed);
  }, [dsl, sessionSeed]);

  // Calibration State
  const [calibrationData, setCalibrationData] = useState<{
    refreshHz: number;
    jitterStdMs: number;
    isStable: boolean;
  } | null>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);

  // Practice State
  const [practiceIdx, setPracticeIdx] = useState(0);
  const [practiceFeedback, setPracticeFeedback] = useState<string | null>(null);

  // Main Trial Progression
  const [trialQueue, setTrialQueue] = useState<CompiledTrialItem[]>([]);
  const [currentTrialIdx, setCurrentTrialIdx] = useState(0);
  const [trialPhase, setTrialPhase] = useState<'fixation' | 'stimulus' | 'feedback' | 'iti'>('fixation');

  // Interactive Form Inputs (for slider & open text)
  const [sliderValue, setSliderValue] = useState<number>(50);
  const [openTextAnswer, setOpenTextAnswer] = useState<string>('');
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);

  // Gamification & Scoring State
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [hudFeedback, setHudFeedback] = useState<{ text: string; color: string } | null>(null);

  // Timing references
  const stimulusOnsetRef = useRef<number>(0);
  const awaitingResponseRef = useRef<boolean>(false);
  const recordedTrialsRef = useRef<TrialRecord[]>([]);

  // Initialize trial queue from compiled specification
  useEffect(() => {
    setTrialQueue(compiled.trials);
  }, [compiled]);

  // Run hardware display benchmark
  const runCalibration = async () => {
    setIsCalibrating(true);
    const result = await HighPrecisionTimer.benchmarkDisplay(120);
    setCalibrationData(result);
    setIsCalibrating(false);

    LocalExperimentStorage.saveCalibration({
      sessionId,
      measuredRefreshHz: result.refreshHz,
      frameJitterStdMs: result.jitterStdMs,
      userAgent: navigator.userAgent,
      viewportDimensions: `${window.innerWidth}x${window.innerHeight}`,
      isStable: result.isStable
    });
  };

  const currentItem: CompiledTrialItem | undefined = trialQueue[currentTrialIdx];

  // Main trial runner loop
  useEffect(() => {
    if (stage !== 'RUNNING' || trialQueue.length === 0) return;

    if (currentTrialIdx >= trialQueue.length) {
      setStage('DEBRIEF');
      if (compiled.gameSkinEnabled) {
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
        if (compiled.soundEnabled) soundEffects.playWarpFanfare();
      }
      return;
    }

    let isCancelled = false;
    let deadlineTimer: ReturnType<typeof setTimeout> | null = null;

    // Reset interactive states for current trial
    const sliderMin = currentItem?.scaleMin ?? 0;
    const sliderMax = currentItem?.scaleMax ?? 100;
    setSliderValue(currentItem?.responseType === 'slider' ? Math.round((sliderMin + sliderMax) / 2) : 50);
    setOpenTextAnswer('');
    setSelectedOptions([]);

    // Phase 1: Fixation Crosshair
    setTrialPhase('fixation');
    awaitingResponseRef.current = false;
    const jitter = Math.floor((Math.random() * 2 - 1) * compiled.fixationJitterMs);
    const fixationDuration = Math.max(compiled.fixationDurationMs + jitter, 200);

    const fixationTimer = setTimeout(async () => {
      if (isCancelled) return;

      // Synchronize stimulus onset with display refresh
      await HighPrecisionTimer.waitForVSync();
      if (isCancelled) return;
      stimulusOnsetRef.current = HighPrecisionTimer.now();
      awaitingResponseRef.current = true;
      setTrialPhase('stimulus');

      // For speeded reaction trials only, enforce deadline timeout
      if (currentItem?.responseType === 'keyboard_reaction') {
        deadlineTimer = setTimeout(() => {
          if (awaitingResponseRef.current && !isCancelled) {
            handleChoiceResponse('TIMEOUT', null, compiled.responseDeadlineMs, true);
          }
        }, compiled.responseDeadlineMs);
      }
    }, fixationDuration);

    return () => {
      isCancelled = true;
      clearTimeout(fixationTimer);
      if (deadlineTimer) clearTimeout(deadlineTimer);
    };
  }, [stage, currentTrialIdx, trialQueue, compiled]);

  // Unified Response Handler (Multimodal: Choice, Rating, Key, Uncertainty)
  const handleChoiceResponse = (
    value: string | number | string[], 
    responseKey: string | null, 
    rawRT: number, 
    isTimeout = false
  ) => {
    if (!awaitingResponseRef.current && !isTimeout) return;
    awaitingResponseRef.current = false;

    if (!currentItem) return;

    const recordsReactionTime = currentItem.responseType === 'keyboard_reaction';
    const rt = isTimeout || !recordsReactionTime ? null : Math.round(rawRT);
    const valueStr = Array.isArray(value) ? value.join('; ') : String(value);

    // Identify uncertainty ("I don't know", "Uncertain", "Not sure", "Prefer not to say")
    const isUncertain = /unknown|don't know|uncertain|not sure|can't tell|prefer not to say/i.test(valueStr);

    // Evaluate correctness if applicable
    let isCorrect: boolean | null = null;
    if (currentItem.responseType === 'keyboard_reaction') {
      const isNoGo = currentItem.expectedKey === 'none';
      isCorrect = isNoGo 
        ? (responseKey === null && isTimeout) 
        : (responseKey !== null && responseKey.toLowerCase() === currentItem.expectedKey.toLowerCase());
    } else if (currentItem.expectedValue !== undefined && currentItem.expectedValue !== null) {
      if (currentItem.responseType === 'multiple_choice') {
        const expected = String(currentItem.expectedValue).split(/[;,]/).map(item => item.trim().toLowerCase()).sort();
        const actual = (Array.isArray(value) ? value : [value]).map(item => String(item).trim().toLowerCase()).sort();
        isCorrect = expected.length === actual.length && expected.every((item, index) => item === actual[index]);
      } else {
        isCorrect = String(currentItem.expectedValue).toLowerCase() === valueStr.toLowerCase();
      }
    } else if (currentItem.factorState?.correct_answer) {
      isCorrect = String(currentItem.factorState.correct_answer).toLowerCase() === valueStr.toLowerCase();
    }
    if (isUncertain) isCorrect = null;

    // Quality flags check
    const qualityFlags: string[] = [];
    if (rt !== null && rt < 120) qualityFlags.push('ANTICIPATORY_RT');
    if (isTimeout) qualityFlags.push('DEADLINE_TIMEOUT');
    if (isUncertain) qualityFlags.push('UNCERTAINTY_RECORDED');

    // Gamification & HUD feedback
    let newScore = score;
    let newStreak = streak;

    if (compiled.gameSkinEnabled) {
      if (isUncertain) {
        // Transparent science: admitting uncertainty is rewarded and does not punish streak
        newScore += 50;
        setHudFeedback({ text: 'UNCERTAINTY LOGGED +50', color: '#f59e0b' });
        if (compiled.soundEnabled) soundEffects.playLaserHit();
      } else if (isCorrect === true || isCorrect === null) {
        // Correct or valid subjective rating
        newStreak = streak + 1;
        const multiplier = newStreak >= 5 ? compiled.scoreRules.streakMultiplier * 1.2 : newStreak >= 3 ? compiled.scoreRules.streakMultiplier : 1.0;
        const points = Math.round(compiled.scoreRules.basePoints * multiplier);
        newScore = score + points;
        setHudFeedback({ text: `+${points} RECORDED!`, color: '#22c55e' });
        if (compiled.soundEnabled) soundEffects.playLaserHit();
      } else {
        newStreak = 0;
        setHudFeedback({ text: isTimeout ? 'TIMEOUT' : 'MISMATCH', color: '#ef4444' });
        if (compiled.soundEnabled) soundEffects.playDeflect();
      }
      setScore(newScore);
      setStreak(newStreak);
    }

    // Provenance Data Record
    const record: TrialRecord = {
      id: `trial_${sessionId}_${currentTrialIdx + 1}`,
      sessionId,
      experimentId: dsl.experiment.id,
      experimentVersion: dsl.experiment.version,
      trialIndex: currentTrialIdx + 1,
      nodeId: 'node_trial_block',
      templateId: currentItem.templateId,
      stimulusId: currentItem.stimulusValue || currentItem.condition,
      condition: currentItem.condition,
      conditionVariables: currentItem.conditionVariables || currentItem.factorState,
      stimulus: currentItem.stimulusText || currentItem.stimulusValue,
      questionText: currentItem.questionText,
      responseType: currentItem.responseType,
      responseValue: isTimeout ? 'TIMEOUT' : value,
      responseKey,
      expectedKey: currentItem.expectedKey,
      expectedValue: currentItem.expectedValue,
      isCorrect,
      isUncertain,
      reactionTimeMs: rt,
      frameOnsetTs: stimulusOnsetRef.current,
      displayLagMs: 0.85,
      score: newScore,
      streak: newStreak,
      qualityFlags,
      generationSource: 'ai_planner',
      assetSource: currentItem.assetSource || 'asset_service',
      timestamp: new Date().toISOString()
    };

    recordedTrialsRef.current.push(record);
    LocalExperimentStorage.bufferTrial(record);

    // ITI (Inter-trial interval)
    setTrialPhase('iti');
    setTimeout(() => {
      setHudFeedback(null);
      setCurrentTrialIdx(idx => idx + 1);
    }, compiled.itiDurationMs);
  };

  // Keyboard shortcut listener for trials
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (stage !== 'RUNNING' || trialPhase !== 'stimulus' || !awaitingResponseRef.current) return;
      if (!currentItem) return;

      const pressed = e.key.toLowerCase();
      const eventTs = e.timeStamp || performance.now();
      const calculatedRT = Math.max(eventTs - stimulusOnsetRef.current, 10);

      // Handle keyboard reaction trials
      if (currentItem.responseType === 'keyboard_reaction') {
        const isAllowed = compiled.allowedKeys.some(k => k.toLowerCase() === pressed);
        if (isAllowed) {
          e.preventDefault();
          handleChoiceResponse(pressed, pressed, calculatedRT);
        }
        return;
      }

      // Handle True / False / Unknown shortcuts (1, 2, 3 or T, F, U)
      if (currentItem.responseType === 'true_false_unknown') {
        if (pressed === '1' || pressed === 't') {
          e.preventDefault();
          handleChoiceResponse('True', pressed, calculatedRT);
        } else if (pressed === '2' || pressed === 'f') {
          e.preventDefault();
          handleChoiceResponse('False', pressed, calculatedRT);
        } else if (pressed === '3' || pressed === 'u') {
          e.preventDefault();
          handleChoiceResponse("I don't know", pressed, calculatedRT);
        }
        return;
      }

      // Handle Rating Scale (1..5)
      if (currentItem.responseType === 'rating_scale') {
        const num = parseInt(pressed, 10);
        const min = currentItem.scaleMin || 1;
        const max = currentItem.scaleMax || 5;
        if (!isNaN(num) && num >= min && num <= max) {
          e.preventDefault();
          handleChoiceResponse(num, pressed, calculatedRT);
        }
        return;
      }

      // Handle Single / Multiple Choice number shortcuts (1..N)
      if (currentItem.responseType === 'single_choice' && currentItem.responseOptions) {
        const num = parseInt(pressed, 10);
        if (!isNaN(num) && num >= 1 && num <= currentItem.responseOptions.length) {
          e.preventDefault();
          const option = currentItem.responseOptions[num - 1];
          handleChoiceResponse(option, pressed, calculatedRT);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [stage, trialPhase, currentItem, compiled.allowedKeys]);

  // STAGE 1: Informed Consent
  if (stage === 'CONSENT') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Informed Consent & Ethics Protocol</h1>
              <span className="text-[11px] font-mono text-slate-400">
                Protocol: {compiled.ethicsProtocolId} • Min Age: {compiled.minAge}+
              </span>
            </div>
          </div>

          <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-3 mb-6">
            <p className="font-semibold text-slate-200">
              {compiled.title}
            </p>
            <p>{compiled.consentStatement}</p>
            <div className="border-t border-slate-800 pt-3 text-[11px] text-slate-400">
              🔒 <strong className="text-slate-300">Privacy Safeguard:</strong> This study does not ask for your name. A temporary study code is used for your session: <code className="text-sky-400 font-mono">{pseudonymToken}</code>.
            </div>
          </div>

          {compiled.requireCheckbox && (
            <label className="flex items-center gap-3 cursor-pointer p-3 rounded-xl bg-slate-900/50 border border-slate-800 mb-6 hover:bg-slate-900 transition-colors">
              <input
                type="checkbox"
                checked={consentChecked}
                onChange={(e) => setConsentChecked(e.target.checked)}
                className="w-4 h-4 rounded text-sky-500 bg-slate-800 border-slate-700 focus:ring-sky-500"
              />
              <span className="text-xs text-slate-300 select-none">
                I confirm I am {compiled.minAge} years or older, understand that participation is voluntary, and consent to participate.
              </span>
            </label>
          )}

          <button
            onClick={() => setStage(compiled.trials.some(trial => trial.responseType === 'keyboard_reaction') ? 'CALIBRATION' : 'INSTRUCTIONS')}
            disabled={compiled.requireCheckbox && !consentChecked}
            className="w-full py-3 px-6 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20"
          >
            <span>I Agree & Proceed</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // STAGE 2: Display & Refresh Calibration
  if (stage === 'CALIBRATION') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
              <Gauge className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Hardware & Refresh Rate Calibration</h1>
              <span className="text-[11px] font-mono text-slate-400">
                Display V-Sync & Jitter Benchmark (120-frame probe)
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 mb-6 leading-relaxed">
            Cognitive psychology requires millisecond-accurate stimulus onset synchronization. We benchmark your display refresh rate to calibrate trial onset timestamps.
          </p>

          <div className="bg-slate-900/90 rounded-2xl p-5 border border-slate-800 mb-6">
            {calibrationData ? (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] font-mono uppercase text-slate-400">Detected Refresh</div>
                  <div className="text-2xl font-black font-mono text-teal-400 mt-1">
                    {calibrationData.refreshHz} Hz
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Frame duration: {(1000 / calibrationData.refreshHz).toFixed(2)} ms
                  </div>
                </div>

                <div>
                  <div className="text-[10px] font-mono uppercase text-slate-400">Jitter Variance</div>
                  <div className="text-2xl font-black font-mono text-emerald-400 mt-1">
                    ±{calibrationData.jitterStdMs} ms
                  </div>
                  <div className="text-[11px] text-emerald-500 mt-0.5">
                    {calibrationData.isStable ? '✓ Timing Environment Stable' : '⚠️ Jitter Detected'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                <button
                  onClick={runCalibration}
                  disabled={isCalibrating}
                  className="py-2.5 px-6 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-xs transition-colors shadow-lg shadow-teal-600/20"
                >
                  {isCalibrating ? 'Benchmarking 120 V-Sync Frames...' : 'Start Hardware Benchmark'}
                </button>
              </div>
            )}
          </div>

          <button
            onClick={() => setStage('INSTRUCTIONS')}
            disabled={!calibrationData}
            className="w-full py-3 px-6 rounded-2xl bg-teal-500 hover:bg-teal-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20"
          >
            <span>Continue to Task Instructions</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // STAGE 3: Task Briefing & Instructions
  if (stage === 'INSTRUCTIONS') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <BookOpen className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">{compiled.instructionTitle}</h1>
              <span className="text-[11px] font-mono text-slate-400">
                Scientific Briefing & Condition Mapping
              </span>
            </div>
          </div>

          <div className="space-y-4 mb-6">
            <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 text-xs text-slate-300 leading-relaxed whitespace-pre-line">
              {compiled.instructionContent}
            </div>

            {/* Scientific Trial Overview */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-center">
                <div className="text-[10px] text-slate-400 uppercase font-mono">Total Trials</div>
                <div className="text-lg font-bold text-white mt-1">{trialQueue.length}</div>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-center">
                <div className="text-[10px] text-slate-400 uppercase font-mono">Theme / Mode</div>
                <div className="text-xs font-bold text-emerald-400 mt-2 capitalize">{compiled.theme.replace('-', ' ')}</div>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-center">
                <div className="text-[10px] text-slate-400 uppercase font-mono">Uncertainty</div>
                <div className="text-xs font-bold text-amber-400 mt-2">Explicitly Allowed</div>
              </div>
            </div>
          </div>

          <button
            onClick={() => setStage('RUNNING')}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/25"
          >
            <span>{compiled.continueButtonText} ({trialQueue.length} Empirical Trials)</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // STAGE 4: Debriefing Screen
  if (stage === 'DEBRIEF') {
    const trials = recordedTrialsRef.current;
    const uncertainCount = trials.filter(t => t.isUncertain).length;
    const uncertainPct = trials.length ? Math.round((uncertainCount / trials.length) * 100) : 0;
    const validRTs = trials.filter(t => t.reactionTimeMs !== null).map(t => t.reactionTimeMs!);
    const meanRT = validRTs.length ? Math.round(validRTs.reduce((a, b) => a + b, 0) / validRTs.length) : 0;

    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-center">
          <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-8 w-8" />
          </div>

          <h1 className="text-xl font-bold text-white mb-1">{compiled.debriefTitle}</h1>
          <p className="text-xs text-slate-400 mb-6">{compiled.debriefContent}</p>

          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
              <div className="text-[10px] uppercase font-mono text-slate-400">Total Completed</div>
              <div className="text-2xl font-black font-mono text-white mt-1">{trials.length}</div>
            </div>

            <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
              <div className="text-[10px] uppercase font-mono text-slate-400">Mean Latency</div>
              <div className="text-2xl font-black font-mono text-teal-400 mt-1">{meanRT} ms</div>
            </div>

            <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
              <div className="text-[10px] uppercase font-mono text-slate-400">Uncertainty Rate</div>
              <div className="text-2xl font-black font-mono text-amber-400 mt-1">{uncertainPct}%</div>
              <div className="text-[10px] text-slate-500 mt-0.5">{uncertainCount} "I don't know"</div>
            </div>
          </div>

          <div className="bg-slate-900/50 p-4 rounded-2xl border border-slate-800 mb-6 text-left">
            <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
              <Layers className="h-4 w-4 text-emerald-400" />
              <span>Data Provenance Guarantee</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Every trial response has been indexed with experimental condition, stimulus properties, response value, timestamp, and latency. The complete empirical dataset is available in the Researcher Analytics Hub.
            </p>
          </div>

          <button
            onClick={onSessionComplete}
            className="w-full py-3.5 px-6 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25"
          >
            <span>Return to Dashboard</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // STAGE 5: RUNNING TRIAL ARENA
  const isForest = compiled.theme === 'forest-adventure';
  const isSpace = compiled.theme === 'deep-space-arcade';
  const isAcademic = compiled.theme === 'academic-clean';

  return (
    <div className={`relative min-h-[620px] w-full flex flex-col justify-between overflow-hidden rounded-3xl border border-slate-800 select-none ${
      isForest ? 'bg-[#061811]' : isSpace ? 'bg-[#030712]' : 'bg-[#0f172a]'
    }`}>
      {/* 1. Theme HUD Header */}
      {isForest && (
        <div className="relative z-20 flex items-center justify-between px-6 py-4 bg-emerald-950/60 backdrop-blur-md border-b border-emerald-800/40">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Trees className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white tracking-wide uppercase flex items-center gap-1.5">
                <span>Forest Exploration Study</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
                  Trial {currentTrialIdx + 1}/{trialQueue.length}
                </span>
              </div>
              <div className="text-[10px] font-mono text-emerald-300/70">
                Condition: {currentItem?.condition || 'Analyzing Stimulus...'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 font-mono text-xs">
            <div className="text-emerald-300 font-bold bg-emerald-900/50 px-3 py-1.5 rounded-xl border border-emerald-700/50">
              🌲 {score} EXP
            </div>
            <div className="text-amber-400 font-bold bg-amber-950/50 px-3 py-1.5 rounded-xl border border-amber-700/50">
              🔥 {streak} Streak
            </div>
          </div>
        </div>
      )}

      {isSpace && (
        <SpaceArcadeHUD
          score={score}
          streak={streak}
          trialCurrent={currentTrialIdx + 1}
          trialTotal={trialQueue.length}
          feedbackText={hudFeedback?.text || null}
          feedbackColor={hudFeedback?.color || null}
        />
      )}

      {isAcademic && (
        <div className="flex items-center justify-between px-6 py-3 bg-slate-900/80 border-b border-slate-800 text-xs text-slate-400">
          <span className="font-medium text-slate-300">
            {compiled.title}
          </span>
          <span className="font-mono">
            Trial {currentTrialIdx + 1} of {trialQueue.length}
          </span>
        </div>
      )}

      {/* 2. Central Scientific Arena */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-6 text-center">
        {/* Phase: Fixation */}
        {trialPhase === 'fixation' && (
          <div className="flex items-center justify-center w-24 h-24">
            <div className="w-8 h-1 bg-slate-400 rounded-full absolute" />
            <div className="w-1 h-8 bg-slate-400 rounded-full absolute" />
          </div>
        )}

        {/* Phase: Stimulus & Multimodal Question */}
        {trialPhase === 'stimulus' && currentItem && (
          <div className="max-w-xl w-full flex flex-col items-center">
            {/* Question Text */}
            {currentItem.questionText && (
              <div className="mb-6 px-4 py-2 rounded-2xl bg-slate-900/90 border border-slate-700/80 text-base font-bold text-white shadow-xl">
                {currentItem.questionText}
              </div>
            )}

            {/* Stimulus Presentation */}
            <div className="flex items-center justify-center gap-4 mb-8">
              {currentItem.primaryEmoji ? (
                <div 
                  className="transition-transform duration-300 select-none flex items-center justify-center drop-shadow-2xl"
                  style={{
                    fontSize: `${Math.round(80 * (currentItem.visualScale || 1.0))}px`,
                    filter: isForest ? 'drop-shadow(0 0 25px rgba(16, 185, 129, 0.4))' : 'none'
                  }}
                >
                  {currentItem.primaryEmoji}
                  {currentItem.secondaryEmoji && (
                    <span className="ml-3 text-5xl">{currentItem.secondaryEmoji}</span>
                  )}
                </div>
              ) : currentItem.stimulusType === 'text' ? (
                <div className="text-4xl font-black font-mono tracking-wider text-white">
                  {currentItem.stimulusText || currentItem.stimulusValue}
                </div>
              ) : (
                <div 
                  style={{ backgroundColor: currentItem.hexColor || '#38bdf8' }}
                  className="w-28 h-28 rounded-full shadow-2xl"
                />
              )}
            </div>

            {/* Multimodal Response Interfaces */}

            {/* 1. True / False / Unknown Interface */}
            {currentItem.responseType === 'true_false_unknown' && (
              <div className="w-full grid grid-cols-3 gap-3">
                <button
                  onClick={() => handleChoiceResponse('True', '1', performance.now() - stimulusOnsetRef.current)}
                  className="py-3.5 px-4 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-200 font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg flex flex-col items-center gap-1"
                >
                  <span>True</span>
                  <span className="text-[10px] font-mono text-emerald-400/80">[Press 1 or T]</span>
                </button>

                <button
                  onClick={() => handleChoiceResponse('False', '2', performance.now() - stimulusOnsetRef.current)}
                  className="py-3.5 px-4 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-200 font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg flex flex-col items-center gap-1"
                >
                  <span>False</span>
                  <span className="text-[10px] font-mono text-rose-400/80">[Press 2 or F]</span>
                </button>

                <button
                  onClick={() => handleChoiceResponse("I don't know", '3', performance.now() - stimulusOnsetRef.current)}
                  className="py-3.5 px-4 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg flex flex-col items-center gap-1"
                >
                  <span>I Don't Know</span>
                  <span className="text-[10px] font-mono text-amber-400/80">[Press 3 or U]</span>
                </button>
              </div>
            )}

            {/* 2. Rating Scale (1..5 or 1..7 Likert) */}
            {currentItem.responseType === 'rating_scale' && (
              <div className="w-full space-y-3">
                <div className="flex justify-center gap-2 sm:gap-3">
                  {[1, 2, 3, 4, 5].map((val) => (
                    <button
                      key={val}
                      onClick={() => handleChoiceResponse(val, String(val), performance.now() - stimulusOnsetRef.current)}
                      className="w-14 h-14 rounded-2xl bg-slate-800/90 hover:bg-emerald-600 border border-slate-700 text-white font-bold font-mono text-lg transition-all hover:scale-110 active:scale-95 shadow-lg flex flex-col items-center justify-center"
                    >
                      <span>{val}</span>
                      <span className="text-[9px] text-slate-400 font-normal">[{val}]</span>
                    </button>
                  ))}
                </div>
                {currentItem.scaleLabels && (
                  <div className="flex justify-between text-[11px] text-slate-400 px-2 font-mono">
                    <span>{currentItem.scaleLabels.min}</span>
                    {currentItem.scaleLabels.mid && <span>{currentItem.scaleLabels.mid}</span>}
                    <span>{currentItem.scaleLabels.max}</span>
                  </div>
                )}
              </div>
            )}

            {/* 3. Single / Multiple Choice Options */}
            {currentItem.responseType === 'single_choice' && currentItem.responseOptions && (
              <div className="w-full grid grid-cols-2 gap-3">
                {currentItem.responseOptions.map((opt, idx) => {
                  const isUncertainOption = /unknown|don't know|uncertain|can't tell/i.test(opt);
                  return (
                    <button
                      key={opt}
                      onClick={() => handleChoiceResponse(opt, String(idx + 1), performance.now() - stimulusOnsetRef.current)}
                      className={`py-3 px-4 rounded-2xl border font-bold text-xs transition-all hover:scale-[1.02] active:scale-[0.98] shadow-md flex items-center justify-between ${
                        isUncertainOption
                          ? 'bg-amber-950/40 hover:bg-amber-900/60 border-amber-700/60 text-amber-200'
                          : 'bg-slate-800/80 hover:bg-slate-700/90 border-slate-700 text-white'
                      }`}
                    >
                      <span>{opt}</span>
                      <span className="text-[10px] font-mono opacity-60">[{idx + 1}]</span>
                    </button>
                  );
                })}
              </div>
            )}

            {currentItem.responseType === 'multiple_choice' && currentItem.responseOptions && (
              <div className="w-full space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {currentItem.responseOptions.map(option => {
                    const checked = selectedOptions.includes(option);
                    return (
                      <label key={option} className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm cursor-pointer ${checked ? 'bg-sky-900/40 border-sky-500 text-white' : 'bg-slate-900 border-slate-700 text-slate-300'}`}>
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => setSelectedOptions(prev => checked ? prev.filter(value => value !== option) : [...prev, option])}
                          className="accent-sky-500"
                        />
                        <span>{option}</span>
                      </label>
                    );
                  })}
                </div>
                <button
                  disabled={selectedOptions.length === 0}
                  onClick={() => handleChoiceResponse(selectedOptions, null, performance.now() - stimulusOnsetRef.current)}
                  className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-bold"
                >
                  Submit selections
                </button>
              </div>
            )}

            {currentItem.responseType === 'slider' && (
              <div className="w-full space-y-4 rounded-2xl bg-slate-900/80 border border-slate-700 p-5">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>{currentItem.scaleLabels?.min || String(currentItem.scaleMin ?? 0)}</span>
                  <span className="text-lg font-bold text-white">{sliderValue}</span>
                  <span>{currentItem.scaleLabels?.max || String(currentItem.scaleMax ?? 100)}</span>
                </div>
                <input
                  type="range"
                  min={currentItem.scaleMin ?? 0}
                  max={currentItem.scaleMax ?? 100}
                  value={sliderValue}
                  onChange={event => setSliderValue(Number(event.target.value))}
                  className="w-full accent-sky-500"
                />
                <button
                  onClick={() => handleChoiceResponse(sliderValue, null, performance.now() - stimulusOnsetRef.current)}
                  className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold"
                >
                  Submit rating
                </button>
              </div>
            )}

            {currentItem.responseType === 'open_text' && (
              <div className="w-full space-y-3">
                <textarea
                  value={openTextAnswer}
                  onChange={event => setOpenTextAnswer(event.target.value)}
                  rows={4}
                  maxLength={2000}
                  aria-label="Your response"
                  placeholder="Type your response here"
                  className="w-full rounded-xl bg-slate-900 border border-slate-700 p-4 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-500"
                />
                <button
                  disabled={!openTextAnswer.trim()}
                  onClick={() => handleChoiceResponse(openTextAnswer.trim(), null, performance.now() - stimulusOnsetRef.current)}
                  className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-bold"
                >
                  Submit response
                </button>
              </div>
            )}

            {/* 4. Keyboard Reaction Prompt */}
            {currentItem.responseType === 'keyboard_reaction' && (
              <div className="text-xs font-mono text-slate-400 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
                Press designated key on your keyboard to respond
              </div>
            )}
          </div>
        )}

        {/* Phase: ITI */}
        {trialPhase === 'iti' && (
          <div className="w-24 h-24" />
        )}
      </div>

      {/* 3. Bottom Status Bar */}
      <div className="relative z-10 px-6 py-3 bg-slate-950/80 backdrop-blur-md border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Condition: <strong className="text-slate-200">{currentItem?.condition || 'Idle'}</strong></span>
        </div>

        <div>
          <span>Mode: <strong className="text-sky-400">{currentItem?.responseType || 'Ready'}</strong></span>
        </div>
      </div>
    </div>
  );
};
