import React, { useState, useEffect, useMemo } from 'react';
import { 
  Download, 
  BarChart3, 
  CheckCircle2, 
  Clock, 
  Users, 
  Layers, 
  Trash2, 
  Sparkles, 
  AlertTriangle,
  RefreshCw,
  Filter,
  Sliders,
  ShieldCheck,
  TrendingUp,
  Cpu,
  ArrowRight
} from 'lucide-react';
import { ExperimentDSL, TrialRecord } from '../../types/dsl';
import { LocalExperimentStorage } from '../../runtime/storage';
import { Exporter } from '../../export/Exporter';
import { StatisticalEngine, DescriptiveStats, WelchTTestResult, CohensDResult, HistogramBin } from '../../analytics/statisticalEngine';
import { QualityEngine, QualityFilterOptions, defaultQualityOptions } from '../../analytics/qualityEngine';
import { ExperimentStore } from '../../runtime/experimentStore';
import { summarizeDataset } from '../../analytics/datasetAnalysis';

interface AnalyticsDashboardProps {
  dsl: ExperimentDSL;
  onNavigateToAiAnalyst?: () => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ 
  dsl,
  onNavigateToAiAnalyst
}) => {
  const [rawTrials, setRawTrials] = useState<TrialRecord[]>([]);
  const [selectedExperimentId, setSelectedExperimentId] = useState<string>(() => dsl.experiment.id);
  const [selectedVersion, setSelectedVersion] = useState<string>('all');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('all');
  const [selectedCondition, setSelectedCondition] = useState<string>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [qualityOptions, setQualityOptions] = useState<QualityFilterOptions>(defaultQualityOptions);
  const [showQualityPanel, setShowQualityPanel] = useState(false);
  const [experiments, setExperiments] = useState<ExperimentDSL[]>(() => ExperimentStore.getAllExperiments());

  // Keep selected experiment aligned if prop changes
  useEffect(() => {
    setSelectedExperimentId(dsl.experiment.id);
  }, [dsl.experiment.id]);

  const loadTrials = async () => {
    setIsRefreshing(true);
    const data = await LocalExperimentStorage.getAllStoredTrials();
    setRawTrials(data);
    setExperiments(ExperimentStore.getAllExperiments());
    setIsRefreshing(false);
  };

  useEffect(() => {
    loadTrials();
    const handleDataUpdate = () => loadTrials();
    window.addEventListener('cognitivelab_data_updated', handleDataUpdate);
    window.addEventListener('cognitivelab_experiments_updated', handleDataUpdate);
    return () => {
      window.removeEventListener('cognitivelab_data_updated', handleDataUpdate);
      window.removeEventListener('cognitivelab_experiments_updated', handleDataUpdate);
    };
  }, []);

  const activeExp = useMemo(() => {
    return experiments.find(e => e.experiment.id === selectedExperimentId) || dsl;
  }, [experiments, selectedExperimentId, dsl]);

  // Scope raw trials strictly to selected Experiment & Version context
  const scopedTrials = useMemo(() => {
    return rawTrials.filter(t => {
      // If trial has experimentId, check match. If trial is legacy (no experimentId), match default experiment
      const matchesExp = t.experimentId ? t.experimentId === selectedExperimentId : (selectedExperimentId === dsl.experiment.id);
      const matchesVer = selectedVersion === 'all' || (t.experimentVersion ? String(t.experimentVersion) === selectedVersion : true);
      const matchesSess = selectedSessionId === 'all' || t.sessionId === selectedSessionId;
      return matchesExp && matchesVer && matchesSess;
    });
  }, [rawTrials, selectedExperimentId, selectedVersion, selectedSessionId, dsl.experiment.id]);

  // Extract distinct sessions within scoped experiment
  const availableSessions = useMemo(() => {
    const matchingExpTrials = rawTrials.filter(t => t.experimentId ? t.experimentId === selectedExperimentId : (selectedExperimentId === dsl.experiment.id));
    return Array.from(new Set(matchingExpTrials.map(t => t.sessionId)));
  }, [rawTrials, selectedExperimentId, dsl.experiment.id]);

  // Filter scoped trials through non-destructive Smart Quality Engine
  const { cleanTrials, excludedTrials, exclusionReasons } = useMemo(() => {
    return QualityEngine.filterTrials(scopedTrials, qualityOptions);
  }, [scopedTrials, qualityOptions]);

  // Extract distinct conditions
  const allConditions = useMemo(() => {
    const set = new Set(cleanTrials.map(t => t.condition));
    return Array.from(set).filter(Boolean).sort();
  }, [cleanTrials]);

  // Filter by selected condition dropdown if applicable
  const activeTrials = useMemo(() => {
    return selectedCondition === 'all' 
      ? cleanTrials 
      : cleanTrials.filter(t => t.condition === selectedCondition);
  }, [cleanTrials, selectedCondition]);

  // Compute descriptive statistics via StatisticalEngine
  const validRTs = useMemo(() => {
    return activeTrials.filter(t => t.reactionTimeMs !== null).map(t => t.reactionTimeMs as number);
  }, [activeTrials]);

  const descriptives: DescriptiveStats = useMemo(() => {
    return StatisticalEngine.computeDescriptives(validRTs);
  }, [validRTs]);

  const scoredTrials = activeTrials.filter(t => t.isCorrect !== null && t.isCorrect !== undefined);
  const correctCount = scoredTrials.filter(t => t.isCorrect === true).length;
  const accuracyPercent = scoredTrials.length
    ? Math.round((correctCount / scoredTrials.length) * 100)
    : null;
  const responseSummary = useMemo(() => summarizeDataset(activeTrials), [activeTrials]);

  const totalSessions = new Set(rawTrials.map(t => t.sessionId)).size;

  // Condition contrast calculation (Welch's t-test + Cohen's d between top 2 conditions)
  const conditionContrasts = useMemo(() => {
    if (allConditions.length < 2) return null;
    const condA = allConditions[0];
    const condB = allConditions[1];
    const rtsA = cleanTrials.filter(t => t.condition === condA && t.reactionTimeMs !== null).map(t => t.reactionTimeMs as number);
    const rtsB = cleanTrials.filter(t => t.condition === condB && t.reactionTimeMs !== null).map(t => t.reactionTimeMs as number);

    if (rtsA.length < 2 || rtsB.length < 2) return null;

    const tTest: WelchTTestResult = StatisticalEngine.welchTTest(rtsA, rtsB);
    const cohen: CohensDResult = StatisticalEngine.cohensD(rtsA, rtsB);
    const descA = StatisticalEngine.computeDescriptives(rtsA);
    const descB = StatisticalEngine.computeDescriptives(rtsB);

    return { condA, condB, tTest, cohen, descA, descB };
  }, [allConditions, cleanTrials]);

  // RT Distribution Histogram Bins
  const histogramBins: HistogramBin[] = useMemo(() => {
    return StatisticalEngine.histogram(validRTs, 16);
  }, [validRTs]);

  // Speed-Accuracy Trade-off (SAT) points per session
  const satScatterPoints = useMemo(() => {
    const sessionMap = new Map<string, { rts: number[]; correct: number; scored: number; total: number }>();
    for (const t of cleanTrials) {
      const entry = sessionMap.get(t.sessionId) || { rts: [], correct: 0, scored: 0, total: 0 };
      entry.total++;
      if (t.isCorrect !== null && t.isCorrect !== undefined) {
        entry.scored++;
        if (t.isCorrect) entry.correct++;
      }
      if (t.reactionTimeMs !== null) entry.rts.push(t.reactionTimeMs);
      sessionMap.set(t.sessionId, entry);
    }

    return Array.from(sessionMap.entries()).filter(([, data]) => data.rts.length > 0 && data.scored > 0).map(([sessId, data]) => {
      const meanRt = Math.round(StatisticalEngine.mean(data.rts));
      const acc = Math.round((data.correct / data.scored) * 100);
      return { sessId, meanRt, acc, trialsCount: data.total };
    });
  }, [cleanTrials]);

  // Synthetic cohort generation targeted strictly to active selected experiment
  const handleGenerateSyntheticCohort = async () => {
    const randNode = activeExp.nodes.find(n => n.type === 'randomization_balanced_block');
    const factorLevels = randNode?.config.factors?.[0]?.levels || [
      { value: 'condition_alpha', metadata: { hex: '#38bdf8', expected_key: 'a' } },
      { value: 'condition_beta', metadata: { hex: '#ef4444', expected_key: 'l' } }
    ];

    const fakeSessions = 6;
    const trialsPerSession = Math.min(randNode?.config.total_trials || 32, 40);

    for (let s = 1; s <= fakeSessions; s++) {
      const sessId = `cohort_${activeExp.experiment.slug}_s${s}_${Date.now().toString(36).substring(3, 7)}`;
      const baseLatency = 370 + Math.floor(Math.random() * 90);

      for (let i = 1; i <= trialsPerSession; i++) {
        const factor = factorLevels[i % factorLevels.length];
        const isHard = factor.value.includes('incongruent') || factor.value.includes('nogo') || factor.value.includes('wrong');
        const conditionCost = isHard ? 65 : 0;
        const rt = Math.max(160, Math.floor(baseLatency + conditionCost + (Math.random() - 0.5) * 80));
        const isCorrect = Math.random() > (isHard ? 0.12 : 0.03);

        const record: TrialRecord = {
          id: `tr_${sessId}_${i}`,
          sessionId: sessId,
          experimentId: activeExp.experiment.id,
          experimentVersion: activeExp.experiment.version,
          trialIndex: i,
          nodeId: 'node_stimulus_display',
          condition: factor.value,
          stimulus: factor.metadata?.text || factor.value,
          responseKey: factor.metadata?.expected_key || 'a',
          expectedKey: factor.metadata?.expected_key || 'a',
          isCorrect,
          reactionTimeMs: rt,
          frameOnsetTs: performance.now(),
          displayLagMs: 0.65,
          score: isCorrect ? 100 : 0,
          streak: isCorrect ? 1 : 0,
          qualityFlags: rt < 150 ? ['fast_guess'] : [],
          timestamp: new Date().toISOString()
        };

        await LocalExperimentStorage.bufferTrial(record);
      }
    }
    await loadTrials();
  };

  const handleClearData = async () => {
    if (window.confirm("Are you sure you want to clear all locally buffered trial data?")) {
      localStorage.removeItem('cl_offline_trials_backup');
      await loadTrials();
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase bg-sky-950/80 text-sky-400 border border-sky-800 px-2 py-0.5 rounded-full">
              Computational Analytics Engine
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              Dataset: {scopedTrials.length} Scoped Records (of {rawTrials.length} Total)
            </span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Behavioral Science Analytics Dashboard
          </h1>
          <p className="text-xs text-slate-400">
            Psychometric and chronometric metrics, outlier trimming controls, and inferential condition contrasts.
          </p>
        </div>

        {/* Global Toolbar */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowQualityPanel(!showQualityPanel)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-white transition-all"
          >
            <Sliders className="h-3.5 w-3.5 text-purple-400" />
            <span>Outlier & Hygiene QC ({excludedTrials.length} Trimmed)</span>
          </button>

          <button
            onClick={handleGenerateSyntheticCohort}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 border border-purple-500/40 text-purple-300 text-xs font-semibold transition-all"
            title="Populate with simulated participant cohort for active experiment"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Generate Cohort (N=6)</span>
          </button>

          <button
            onClick={() => Exporter.downloadLongCSV(cleanTrials, activeExp)}
            disabled={cleanTrials.length === 0}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-xs font-semibold shadow-sm transition-all"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export Long CSV</span>
          </button>

          {rawTrials.length > 0 && (
            <button
              onClick={handleClearData}
              className="p-2 rounded-xl bg-slate-900 hover:bg-rose-950/50 border border-slate-800 hover:border-rose-800 text-slate-400 hover:text-rose-400 transition-all"
              title="Clear all stored trial records"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Dataset Context Scope Selector Bar */}
      <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase text-slate-400">Experiment:</span>
            <select
              value={selectedExperimentId}
              onChange={(e) => {
                setSelectedExperimentId(e.target.value);
                setSelectedCondition('all');
                setSelectedSessionId('all');
              }}
              className="bg-slate-900 border border-slate-700 text-white text-xs rounded-xl px-3 py-1.5 outline-none font-semibold focus:border-sky-500"
            >
              {experiments.map(exp => (
                <option key={exp.experiment.id} value={exp.experiment.id}>
                  {exp.experiment.title} (v{exp.experiment.version})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase text-slate-400">Version:</span>
            <select
              value={selectedVersion}
              onChange={(e) => setSelectedVersion(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white text-xs rounded-xl px-2.5 py-1.5 outline-none"
            >
              <option value="all">All Versions</option>
              <option value={String(activeExp.experiment.version)}>v{activeExp.experiment.version}.0 (Current)</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase text-slate-400">Cohort / Session:</span>
            <select
              value={selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white text-xs rounded-xl px-2.5 py-1.5 outline-none max-w-xs truncate"
            >
              <option value="all">All Sessions ({availableSessions.length} total)</option>
              {availableSessions.map(sess => (
                <option key={sess} value={sess}>{sess}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-sky-400">
            Active Scope: {activeExp.experiment.slug}
          </span>
          <span>•</span>
          <span>N={availableSessions.length} Sessions</span>
        </div>
      </div>

      {/* Outlier Trimming & Quality Control Panel */}
      {showQualityPanel && (
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 text-xs text-slate-300 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-purple-400" />
              Non-Destructive Sample Hygiene & Trimming Rules
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Raw data is never deleted; soft filters applied dynamically
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-1">
            <label className="flex items-center gap-2 cursor-pointer bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <input
                type="checkbox"
                checked={qualityOptions.excludeFastGuesses}
                onChange={(e) => setQualityOptions(prev => ({ ...prev, excludeFastGuesses: e.target.checked }))}
                className="accent-purple-500"
              />
              <span>Exclude Fast Guesses (&lt;{qualityOptions.minRtMs}ms)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <input
                type="checkbox"
                checked={qualityOptions.excludeTimeouts}
                onChange={(e) => setQualityOptions(prev => ({ ...prev, excludeTimeouts: e.target.checked }))}
                className="accent-purple-500"
              />
              <span>Exclude Timeouts (&gt;{qualityOptions.maxRtMs}ms)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <input
                type="checkbox"
                checked={qualityOptions.onlyCorrectTrialsForRt}
                onChange={(e) => setQualityOptions(prev => ({ ...prev, onlyCorrectTrialsForRt: e.target.checked }))}
                className="accent-purple-500"
              />
              <span>Only Correct Trials for RT</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <input
                type="checkbox"
                checked={qualityOptions.excludeFrameJitter}
                onChange={(e) => setQualityOptions(prev => ({ ...prev, excludeFrameJitter: e.target.checked }))}
                className="accent-purple-500"
              />
              <span>Exclude Frame Jitter (&gt;3ms)</span>
            </label>
          </div>

          <div className="text-[11px] text-purple-300 font-mono pt-1">
            Trimmed: {exclusionReasons.fast_guess} fast guesses • {exclusionReasons.timeout} timeouts • {exclusionReasons.incorrect_rt} errors • Retained: {cleanTrials.length} clean trials
          </div>
        </div>
      )}

      {cleanTrials.length === 0 ? (
        <div className="p-12 rounded-3xl bg-[#0d1322] border border-slate-800 text-center space-y-4 shadow-xl">
          <div className="w-16 h-16 rounded-full bg-purple-500/10 border border-purple-500/30 flex items-center justify-center mx-auto text-purple-400">
            <BarChart3 className="h-8 w-8" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">No Empirical Data for {activeExp.experiment.title}</h2>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 leading-relaxed">
              All computational analytics are partitioned strictly by experiment ID. No participant sessions exist in the <code className="text-sky-400 font-mono">{activeExp.experiment.id}</code> partition yet.
            </p>
          </div>
          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={handleGenerateSyntheticCohort}
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-all flex items-center gap-2 shadow-lg shadow-purple-600/20"
            >
              <Sparkles className="h-4 w-4" />
              <span>Generate Calibrated Cohort (N=6)</span>
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3 shadow-xl">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Total Subjects</div>
          <div className="text-xl font-bold text-white font-mono flex items-center gap-1.5">
            <Users className="h-4 w-4 text-sky-400" />
            <span>N = {totalSessions}</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{cleanTrials.length} clean trials</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3 shadow-xl">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Mean RT (±SEM)</div>
          <div className="text-xl font-bold text-sky-400 font-mono">
            {validRTs.length ? <>{Math.round(descriptives.mean)} <span className="text-xs text-slate-500 font-normal">± {Math.round(descriptives.sem)} ms</span></> : 'Not collected'}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{validRTs.length ? `95% CI: [${Math.round(descriptives.ci95[0])}, ${Math.round(descriptives.ci95[1])}]` : 'This study does not record reaction time'}</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3 shadow-xl">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Median RT (IQR)</div>
          <div className="text-xl font-bold text-purple-300 font-mono">
            {validRTs.length ? <>{Math.round(descriptives.median)} <span className="text-xs text-slate-500 font-normal">ms</span></> : 'Not collected'}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{validRTs.length ? `IQR: ${Math.round(descriptives.iqr)} ms` : 'No timed responses in this study'}</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3 shadow-xl">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Accuracy</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            {accuracyPercent === null ? 'N/A' : `${accuracyPercent}%`}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{scoredTrials.length ? `${correctCount} / ${scoredTrials.length} scored responses` : 'No correct-answer key for this study'}</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3 shadow-xl">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Quality Retention</div>
          <div className="text-xl font-bold text-emerald-400 font-mono flex items-center gap-1.5">
            <Cpu className="h-4 w-4" />
            <span>{scopedTrials.length ? `${Math.round((cleanTrials.length / scopedTrials.length) * 100)}%` : 'N/A'}</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{cleanTrials.length} of {scopedTrials.length} records retained by current filters</div>
        </div>
      </div>

      <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Recorded Responses by Condition</h3>
        {responseSummary.conditions.length ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {responseSummary.conditions.map(condition => (
              <div key={condition.condition} className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
                <div className="font-semibold text-white mb-1">{condition.condition}</div>
                <div className="text-slate-400">{condition.trials} trials · {condition.sessions} sessions</div>
                {condition.meanNumericResponse !== null && <div className="text-emerald-300 mt-1">Mean numeric response: {condition.meanNumericResponse.toFixed(2)}</div>}
                {condition.responseCounts.length > 0 && <div className="text-slate-300 mt-1">{condition.responseCounts.slice(0, 5).map(item => `${item.response}: ${item.count}`).join(' · ')}</div>}
                {condition.uncertaintyCount > 0 && <div className="text-amber-300 mt-1">Uncertain: {condition.uncertaintyCount}</div>}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500">No participant response records are available for this selection.</p>
        )}
      </div>

      {/* CONDITION CONTRAST INFERENTIAL SECTION */}
      {conditionContrasts && (
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-sky-400" />
              <span>Primary Experimental Condition Contrast (Welch's t-test & Cohen's d)</span>
            </h3>
            {onNavigateToAiAnalyst && (
              <button
                onClick={onNavigateToAiAnalyst}
                className="text-purple-400 hover:text-purple-300 text-xs font-semibold flex items-center gap-1"
              >
                <span>Ask AI Analyst</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
              <div className="text-slate-400 font-mono text-[10px] uppercase">{conditionContrasts.condA}</div>
              <div className="text-lg font-bold text-white font-mono mt-0.5">
                {conditionContrasts.descA.mean} ms <span className="text-xs text-slate-500 font-normal">± {Math.round(conditionContrasts.descA.sd)}</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1 font-mono">Median: {conditionContrasts.descA.median} ms • n={conditionContrasts.descA.n}</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
              <div className="text-slate-400 font-mono text-[10px] uppercase">{conditionContrasts.condB}</div>
              <div className="text-lg font-bold text-white font-mono mt-0.5">
                {conditionContrasts.descB.mean} ms <span className="text-xs text-slate-500 font-normal">± {Math.round(conditionContrasts.descB.sd)}</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-1 font-mono">Median: {conditionContrasts.descB.median} ms • n={conditionContrasts.descB.n}</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/40 text-xs">
              <div className="text-purple-300 font-mono text-[10px] uppercase">Condition Contrast Delta</div>
              <div className="text-lg font-bold text-purple-200 font-mono mt-0.5">
                {conditionContrasts.tTest.delta > 0 ? `+${conditionContrasts.tTest.delta}` : conditionContrasts.tTest.delta} ms
              </div>
              <div className="text-[10px] text-purple-300 mt-1 font-mono">
                t({conditionContrasts.tTest.df}) = {conditionContrasts.tTest.t} • p = {conditionContrasts.tTest.pValue < 0.001 ? '< .001' : conditionContrasts.tTest.pValue} • d = {conditionContrasts.cohen.d} ({conditionContrasts.cohen.interpretation})
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DUAL VISUALIZATION: RT DISTRIBUTION HISTOGRAM & SPEED-ACCURACY SCATTER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: RT Distribution Histogram */}
        <div className="lg:col-span-7 bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-sky-400" />
              <span>Reaction Time Distribution (Ex-Gaussian Skew)</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500">16 Bins</span>
          </div>

          {histogramBins.length > 0 ? (
            <div className="space-y-2">
              <div className="h-44 flex items-end gap-1.5 pt-4 pb-2 border-b border-slate-800 px-2">
                {histogramBins.map((bin, i) => {
                  const maxCount = Math.max(...histogramBins.map(b => b.count), 1);
                  const heightPercent = Math.max(Math.round((bin.count / maxCount) * 100), 4);
                  return (
                    <div 
                      key={i} 
                      className="flex-1 flex flex-col items-center group relative h-full justify-end"
                    >
                      <div
                        className="w-full rounded-t bg-gradient-to-t from-sky-600 to-indigo-500 hover:from-sky-400 hover:to-indigo-400 transition-all cursor-pointer"
                        style={{ height: `${heightPercent}%` }}
                      />
                      <div className="opacity-0 group-hover:opacity-100 absolute -top-8 bg-slate-900 border border-slate-700 text-white text-[9px] font-mono px-1.5 py-0.5 rounded shadow pointer-events-none z-10 whitespace-nowrap">
                        {bin.binCenter}ms: {bin.count} trials
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between text-[10px] font-mono text-slate-500 px-2">
                <span>{histogramBins[0]?.binStart || 0} ms</span>
                <span>Median: {Math.round(descriptives.median)} ms</span>
                <span>{histogramBins[histogramBins.length - 1]?.binEnd || 0} ms</span>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-slate-500 font-mono">
              No trial response times available. Click "Generate Cohort" or run a study to populate.
            </div>
          )}
        </div>

        {/* Right: Speed-Accuracy Trade-off (SAT) Scatter */}
        <div className="lg:col-span-5 bg-[#0d1322] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              <span>Speed-Accuracy Trade-off (SAT)</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500">Per-Session Variance</span>
          </div>

          {satScatterPoints.length > 0 ? (
            <div className="space-y-3">
              <div className="h-44 bg-slate-950/60 border border-slate-800 rounded-2xl relative p-3 overflow-hidden">
                {satScatterPoints.map((pt, i) => {
                  const minRt = Math.min(...satScatterPoints.map(p => p.meanRt), 200);
                  const maxRt = Math.max(...satScatterPoints.map(p => p.meanRt), 600);
                  const xPct = Math.max(5, Math.min(95, ((pt.meanRt - minRt) / Math.max(maxRt - minRt, 1)) * 90 + 5));
                  const yPct = Math.max(5, Math.min(95, (100 - pt.acc)));

                  return (
                    <div
                      key={i}
                      className="absolute h-3 w-3 rounded-full bg-emerald-400 border border-white/40 cursor-pointer group shadow"
                      style={{ left: `${xPct}%`, top: `${yPct}%` }}
                      title={`${pt.sessId}: RT=${pt.meanRt}ms, Acc=${pt.acc}%`}
                    >
                      <div className="opacity-0 group-hover:opacity-100 absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 text-white text-[9px] font-mono px-1.5 py-0.5 rounded shadow pointer-events-none z-10 whitespace-nowrap">
                        {pt.sessId}: {pt.meanRt}ms, {pt.acc}%
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between text-[10px] font-mono text-slate-500">
                <span>Fast Responders</span>
                <span>Accuracy 100% (Top)</span>
                <span>Slow Responders</span>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-slate-500 font-mono">
              Waiting for completed participant sessions...
            </div>
          )}
        </div>
      </div>
        </>
      )}
    </div>
  );
};
