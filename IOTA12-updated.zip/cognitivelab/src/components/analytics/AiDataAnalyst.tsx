import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Send, 
  Sparkles, 
  RefreshCw, 
  FileText, 
  Lightbulb
} from 'lucide-react';
import { ExperimentDSL, TrialRecord } from '../../types/dsl';
import { LocalExperimentStorage } from '../../runtime/storage';
import { ExperimentStore } from '../../runtime/experimentStore';
import { answerDatasetQuestion, buildExploratoryReport } from '../../analytics/datasetAnalysis';

interface AiDataAnalystProps {
  dsl: ExperimentDSL;
  onNavigateToBuilder?: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  auditRecord?: {
    calculationEngine: string;
    formulaExecuted: string;
    sampleSizes: string;
  };
}

export const AiDataAnalyst: React.FC<AiDataAnalystProps> = ({ dsl }) => {
  const [experiments] = useState<ExperimentDSL[]>(() => ExperimentStore.getAllExperiments());
  const [selectedExpId, setSelectedExpId] = useState<string>(() => dsl.experiment.id);
  const [query, setQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [trials, setTrials] = useState<TrialRecord[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [exploratoryReport, setExploratoryReport] = useState<string | null>(null);

  const activeExp = experiments.find(e => e.experiment.id === selectedExpId) || dsl;

  useEffect(() => {
    LocalExperimentStorage.getAllStoredTrials().then(stored => {
      const scoped = stored.filter(t => t.experimentId ? t.experimentId === selectedExpId : (selectedExpId === dsl.experiment.id));
      setTrials(scoped);
    });
  }, [selectedExpId, activeExp, dsl.experiment.id]);

  // Initial welcome message
  useEffect(() => {
    setMessages([
      {
        id: `msg_welcome_${selectedExpId}`,
        sender: 'ai',
        text: `I can summarize recorded responses for **${activeExp.experiment.title}** (v${activeExp.experiment.version}). This local assistant calculates descriptive summaries from the selected dataset. It does not invent missing participant data or provide inferential or clinical conclusions. Ask about response distributions, accuracy, uncertainty, ratings, or reaction time.`,
        timestamp: 'Just now'
      }
    ]);
  }, [selectedExpId, activeExp.experiment.title, activeExp.experiment.version]);

  const handleRunQuery = (promptText?: string) => {
    const textToProcess = promptText || query;
    if (!textToProcess.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      sender: 'user',
      text: textToProcess.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setIsProcessing(true);

    window.setTimeout(() => {
      const result = answerDatasetQuestion(textToProcess, trials);
      setMessages(prev => [...prev, {
        id: `msg_ai_${Date.now()}`,
        sender: 'ai',
        text: result.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        auditRecord: {
          calculationEngine: 'Local descriptive analysis',
          formulaExecuted: result.formula,
          sampleSizes: result.sample,
        },
      }]);
      setIsProcessing(false);
    }, 120);
  };

  const handleGenerateExploratoryReport = () => {
    setIsProcessing(true);
    window.setTimeout(() => {
      setExploratoryReport(buildExploratoryReport(activeExp.experiment.title, trials));
      setIsProcessing(false);
    }, 120);
  };
  return (
    <div className="max-w-6xl mx-auto py-8 px-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-600 text-white shadow-lg shadow-purple-500/20">
            <Brain className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              Study Data Analyst
              <span className="text-[10px] font-mono font-normal bg-purple-950/60 text-purple-300 border border-purple-800 px-2 py-0.5 rounded-full">
                Local Descriptive Analysis
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Summaries use recorded responses only. No synthetic participant data or inferential claims.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateExploratoryReport}
            disabled={isProcessing}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-all shadow-lg shadow-purple-500/20"
          >
            <Sparkles className="h-4 w-4" />
            <span>1-Click Exploratory Analysis</span>
          </button>
        </div>
      </div>

      {/* Dataset Context Scope Selector Bar */}
      <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase text-slate-400">Dataset Scope:</span>
            <select
              value={selectedExpId}
              onChange={(e) => setSelectedExpId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white text-xs rounded-xl px-3 py-1.5 outline-none font-semibold focus:border-purple-500"
            >
              {experiments.map(exp => (
                <option key={exp.experiment.id} value={exp.experiment.id}>
                  {exp.experiment.title} (v{exp.experiment.version})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-purple-400">
            Partition: {activeExp.experiment.id}
          </span>
          <span>•</span>
          <span>Sample: N={Array.from(new Set(trials.map(t => t.sessionId))).length} ({trials.length} trials)</span>
        </div>
      </div>

      {/* Exploratory Report Modal / Box */}
      {exploratoryReport && (
        <div className="bg-[#0d1322] border border-purple-500/40 rounded-3xl p-6 shadow-2xl space-y-3 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase tracking-wider">
              <FileText className="h-4 w-4" />
              <span>Exploratory Descriptive Report</span>
            </div>
            <button
              onClick={() => setExploratoryReport(null)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Close Report
            </button>
          </div>
          <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto whitespace-pre leading-relaxed">
            {exploratoryReport}
          </pre>
        </div>
      )}

      {/* Main Conversation & Output Panel */}
      <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
        {/* Chat message feed */}
        <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-mono text-slate-500">
                  {msg.sender === 'user' ? 'Researcher' : 'Study Data Analyst'}
                </span>
                <span className="text-[10px] text-slate-600">{msg.timestamp}</span>
              </div>

              <div
                className={`max-w-2xl p-4 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-sky-600 text-white rounded-tr-none'
                    : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-none shadow-md space-y-3'
                }`}
              >
                <div className="whitespace-pre-line">{msg.text}</div>

                {/* Audit Record ("How did you calculate this?") */}
                {msg.auditRecord && (
                  <div className="text-[10px] font-mono text-slate-400 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/80 space-y-0.5">
                    <div className="text-slate-500 font-semibold uppercase text-[9px]">Mathematical Audit Trail:</div>
                    <div>Engine: <span className="text-sky-300">{msg.auditRecord.calculationEngine}</span></div>
                    <div>Formula: <span className="text-purple-300">{msg.auditRecord.formulaExecuted}</span></div>
                    <div>Cohort: <span className="text-slate-300">{msg.auditRecord.sampleSizes}</span></div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isProcessing && (
            <div className="flex items-center gap-2 text-xs text-purple-400 font-mono p-3 bg-slate-900/60 rounded-xl w-fit">
              <RefreshCw className="h-4 w-4 animate-spin" />
              <span>Summarizing recorded responses...</span>
            </div>
          )}
        </div>

        {/* Query Suggestions Pills */}
        <div className="pt-2 border-t border-slate-800">
          <div className="text-[10px] font-mono text-slate-500 uppercase mb-2 flex items-center gap-1">
            <Lightbulb className="h-3 w-3 text-amber-400" />
            <span>Suggested Research Questions (1-Click Run):</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              "Show response distributions by condition",
              "What were the mean safety ratings?",
              "How many responses were uncertain?",
              "Compare reaction times by condition",
              "Which condition had the highest accuracy?"
            ].map((s, idx) => (
              <button
                key={idx}
                onClick={() => handleRunQuery(s)}
                className="text-[11px] px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-purple-500/40 text-slate-300 transition-all"
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleRunQuery();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask about responses, ratings, uncertainty, accuracy, or reaction time..."
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-purple-500 transition-colors"
          />
          <button
            type="submit"
            disabled={!query.trim() || isProcessing}
            className="p-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-40 text-white rounded-xl transition-all shadow-lg shadow-purple-500/20"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
