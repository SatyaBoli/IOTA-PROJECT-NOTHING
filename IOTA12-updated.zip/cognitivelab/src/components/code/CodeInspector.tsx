import React, { useState, useEffect } from 'react';
import { Copy, Check, AlertCircle, CheckCircle2, FileJson, AlignLeft } from 'lucide-react';
import { ExperimentDSL, ValidationIssue } from '../../types/dsl';
import { ExperimentValidator } from '../../dsl/validator';

interface CodeInspectorProps {
  dsl: ExperimentDSL;
  onUpdateDsl: (newDsl: ExperimentDSL) => void;
  validationIssues: ValidationIssue[];
  isValid: boolean;
}

export const CodeInspector: React.FC<CodeInspectorProps> = ({
  dsl,
  onUpdateDsl,
  validationIssues,
  isValid
}) => {
  const [jsonText, setJsonText] = useState(() => JSON.stringify(dsl, null, 2));
  const [copied, setCopied] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [applySuccess, setApplySuccess] = useState(false);

  // Sync state whenever the external DSL updates (e.g. from Canvas edits or AI Designer)
  useEffect(() => {
    setJsonText(JSON.stringify(dsl, null, 2));
  }, [dsl]);

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFormat = () => {
    try {
      const parsed = JSON.parse(jsonText);
      setJsonText(JSON.stringify(parsed, null, 2));
      setParseError(null);
    } catch (e: any) {
      setParseError(`JSON Format Error: ${e.message}`);
    }
  };

  const handleApplyJson = () => {
    try {
      const parsed = JSON.parse(jsonText);
      const val = ExperimentValidator.validate(parsed);
      if (!val.isValid) {
        setParseError(`Validation Error: ${val.issues.map(i => i.message).join(' | ')}`);
        return;
      }
      setParseError(null);
      onUpdateDsl(parsed);
      setApplySuccess(true);
      setTimeout(() => setApplySuccess(false), 2000);
    } catch (e: any) {
      setParseError(`JSON Syntax Error: ${e.message}`);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <FileJson className="h-6 w-6 text-sky-400" />
            Canonical Experiment DSL (Single Source of Truth)
          </h1>
          <p className="text-xs text-slate-400">
            Strict JSON Schema representation decoupled from UI view models.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleFormat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
            title="Auto-format JSON indent"
          >
            <AlignLeft className="h-4 w-4" />
            <span>Format</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
          >
            {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
            <span>{copied ? 'Copied!' : 'Copy DSL'}</span>
          </button>

          <button
            onClick={handleApplyJson}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold transition-all shadow-md shadow-sky-500/20"
          >
            {applySuccess ? <Check className="h-4 w-4 text-white" /> : null}
            <span>{applySuccess ? 'Applied!' : 'Apply & Re-validate'}</span>
          </button>
        </div>
      </div>

      {parseError && (
        <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex gap-2">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          <div>{parseError}</div>
        </div>
      )}

      {/* Validation status badge */}
      <div className="mb-4 flex items-center gap-2">
        {isValid ? (
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/30 border border-emerald-500/30 px-3 py-1 rounded-lg font-mono">
            <CheckCircle2 className="h-4 w-4" />
            <span>Schema & Logic Validated (Ready for Runtime Execution)</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-xs text-rose-400 bg-rose-950/30 border border-rose-500/30 px-3 py-1 rounded-lg font-mono">
            <AlertCircle className="h-4 w-4" />
            <span>{validationIssues.length} Validation Warnings / Errors Detected</span>
          </div>
        )}
      </div>

      {/* Code Editor Area */}
      <div className="bg-[#0a0f1d] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <textarea
          rows={28}
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
          className="w-full bg-transparent p-4 font-mono text-xs text-slate-300 focus:outline-none resize-none leading-relaxed selection:bg-sky-500/30"
          spellCheck={false}
        />
      </div>
    </div>
  );
};
