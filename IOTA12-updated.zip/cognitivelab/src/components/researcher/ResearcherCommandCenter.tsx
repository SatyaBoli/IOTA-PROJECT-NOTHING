import React, { useState } from 'react';
import { 
  Network, 
  Sparkles, 
  Play, 
  BarChart3, 
  Code2, 
  Layers, 
  Users, 
  ShieldAlert, 
  CheckCircle2, 
  Plus, 
  ArrowRight, 
  Search, 
  Filter, 
  Activity, 
  Radio, 
  Cpu, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { ExperimentDSL } from '../../types/dsl';
import { defaultExperimentDSL } from '../../dsl/defaultExperiment';
import { ExperimentStore } from '../../runtime/experimentStore';

interface ResearcherCommandCenterProps {
  currentDsl: ExperimentDSL;
  onSelectExperiment: (dsl: ExperimentDSL, tab?: string) => void;
  onNewExperiment: () => void;
  onSwitchToParticipant: () => void;
}

interface PortfolioItem {
  id: string;
  title: string;
  version: string;
  status: 'LIVE' | 'PILOT' | 'ARCHIVED';
  sampleN: number;
  targetN: number;
  dataQualityPercent: number;
  paradigm: string;
  lastUpdated: string;
  dsl: ExperimentDSL;
}

export const ResearcherCommandCenter: React.FC<ResearcherCommandCenterProps> = ({
  currentDsl,
  onSelectExperiment,
  onNewExperiment,
  onSwitchToParticipant
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'LIVE' | 'PILOT'>('ALL');
  const [experiments, setExperiments] = useState<ExperimentDSL[]>(() => ExperimentStore.getAllExperiments());

  React.useEffect(() => {
    const handleUpdate = () => {
      setExperiments(ExperimentStore.getAllExperiments());
    };
    window.addEventListener('cognitivelab_experiments_updated', handleUpdate);
    window.addEventListener('cognitivelab_active_experiment_changed', handleUpdate);
    return () => {
      window.removeEventListener('cognitivelab_experiments_updated', handleUpdate);
      window.removeEventListener('cognitivelab_active_experiment_changed', handleUpdate);
    };
  }, []);

  const portfolio: PortfolioItem[] = experiments.map((exp, idx) => {
    const isCurrent = exp.experiment.id === currentDsl.experiment.id;
    const stimNode = exp.nodes.find(n => n.type === 'presentation_stimulus');
    const stimType = stimNode?.config.stimulus_type || 'color_circle';
    
    let paradigmDesc = 'Cognitive 2AFC Discrimination';
    if (stimType === 'spatial_grid') paradigmDesc = 'Visuospatial Working Memory (3x3)';
    else if (stimType === 'word_ink') paradigmDesc = 'Stroop Color-Word Interference';
    else if (exp.experiment.slug.includes('flanker')) paradigmDesc = 'Eriksen Attentional Inhibition';
    else if (exp.experiment.slug.includes('food')) paradigmDesc = 'Appetitive Choice Latency';
    else if (exp.game_skin.enabled) paradigmDesc = 'Gamified Reaction 2AFC/3AFC';

    return {
      id: exp.experiment.id,
      title: exp.experiment.title,
      version: `v${exp.experiment.version}.0`,
      status: isCurrent ? 'LIVE' : (idx % 2 === 0 ? 'LIVE' : 'PILOT'),
      sampleN: isCurrent ? 142 : 24 + (idx * 28),
      targetN: 150,
      dataQualityPercent: isCurrent ? 98.4 : Math.min(99.2, 94.5 + (idx * 1.3)),
      paradigm: paradigmDesc,
      lastUpdated: isCurrent ? 'Active Now' : `${idx + 1} day${idx > 0 ? 's' : ''} ago`,
      dsl: exp
    };
  });

  const handleSelectExp = (item: PortfolioItem, tab: string = 'builder') => {
    ExperimentStore.setActiveExperimentId(item.dsl.experiment.id);
    onSelectExperiment(item.dsl, tab);
  };

  const filteredPortfolio = portfolio.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.paradigm.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || item.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase bg-purple-950/80 text-purple-300 border border-purple-800 px-2 py-0.5 rounded-full">
              Principal Investigator Workspace
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Organization: Department of Cognitive Science</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Researcher Command Center
          </h1>
          <p className="text-xs text-slate-400">
            Monitor active recruitment pipelines, review hardware timing quality, and explore data analytics.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onSwitchToParticipant}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-all"
          >
            Switch to Participant View
          </button>

          <button
            onClick={onNewExperiment}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs transition-all shadow-lg shadow-purple-500/25"
          >
            <Plus className="h-4 w-4" />
            <span>New Experiment (AI Designer)</span>
          </button>
        </div>
      </div>

      {/* ACTIVE RECRUITMENT PULSE */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-mono uppercase">Active Studies</span>
            <Layers className="h-4 w-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">4 <span className="text-xs font-normal text-slate-500">Paradigms</span></div>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1 font-mono">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            <span>3 Live Recruitment • 1 Pilot</span>
          </div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-mono uppercase">Connected Sockets</span>
            <Radio className="h-4 w-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold text-sky-400 font-mono">18 <span className="text-xs font-normal text-slate-500">Live</span></div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">Active trial event streaming</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-mono uppercase">Data Quality Score</span>
            <Cpu className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">97.8% <span className="text-xs font-normal text-slate-500">Clean</span></div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">&lt;2.2% timing/guess flags</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] font-mono uppercase">Total Cohort Sample</span>
            <Users className="h-4 w-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">394 <span className="text-xs font-normal text-slate-500">/ 470 N</span></div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">83.8% target goal achieved</div>
        </div>
      </div>

      {/* ACTIONABLE SCIENTIFIC ALERTS */}
      <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldAlert className="h-4 w-4 text-amber-400" />
            <span>Actionable Scientific Alerts & Hardware Audits</span>
          </h3>
          <span className="text-[10px] font-mono text-slate-500">Real-Time Sensor Bus</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-300">
            <div className="font-semibold flex items-center gap-1.5">
              <span>High Dropout Alert: Stroop Conflict</span>
            </div>
            <p className="text-[11px] text-amber-400/80 mt-1">
              Block 3 attrition reached 12%. Consider shortening practice blocks or increasing inter-trial intervals.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-sky-950/30 border border-sky-500/30 text-sky-300">
            <div className="font-semibold flex items-center gap-1.5">
              <span>Display Timing Stability: Verified</span>
            </div>
            <p className="text-[11px] text-sky-400/80 mt-1">
              99.2% of trials maintained &lt;0.8ms V-Sync frame jitter across desktop Chrome and Safari.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300">
            <div className="font-semibold flex items-center gap-1.5">
              <span>Recruitment Complete: Food Choice</span>
            </div>
            <p className="text-[11px] text-emerald-400/80 mt-1">
              Target sample size N=150 reached with 97.8% clean trials. Ready for export and publication reporting.
            </p>
          </div>
        </div>
      </div>

      {/* EXPERIMENT PORTFOLIO TABLE */}
      <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-white">Experiment Portfolio</h3>
            <p className="text-xs text-slate-400">Click any experiment to open its dedicated research workspace.</p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white">
              <Search className="h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search experiments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent outline-none text-xs w-36 sm:w-44"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded-xl px-2.5 py-1.5 outline-none"
            >
              <option value="ALL">All Status</option>
              <option value="LIVE">Live</option>
              <option value="PILOT">Pilot</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="text-[10px] uppercase font-mono text-slate-500 bg-slate-900/60 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Experiment Title</th>
                <th className="py-2.5 px-3">Version</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Sample (N)</th>
                <th className="py-2.5 px-3">Data Quality</th>
                <th className="py-2.5 px-3">Last Activity</th>
                <th className="py-2.5 px-3 text-right">Workspace Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              {filteredPortfolio.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900/50 transition-colors">
                  <td className="py-3 px-3">
                    <button
                      onClick={() => handleSelectExp(item, 'builder')}
                      className="font-bold text-white hover:text-sky-300 font-sans text-xs text-left"
                    >
                      {item.title}
                    </button>
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">{item.paradigm}</div>
                  </td>
                  <td className="py-3 px-3 text-purple-300 font-semibold">{item.version}</td>
                  <td className="py-3 px-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] ${
                      item.status === 'LIVE'
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950/60 text-amber-400 border border-amber-800'
                    }`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${item.status === 'LIVE' ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                      <span>{item.status}</span>
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    <span className="font-bold">{item.sampleN}</span> / {item.targetN}
                    <div className="w-16 bg-slate-800 h-1 rounded-full mt-1 overflow-hidden">
                      <div className="bg-sky-500 h-full" style={{ width: `${(item.sampleN / item.targetN) * 100}%` }} />
                    </div>
                  </td>
                  <td className="py-3 px-3 text-emerald-400">{item.dataQualityPercent}% Clean</td>
                  <td className="py-3 px-3 text-slate-500 font-sans">{item.lastUpdated}</td>
                  <td className="py-3 px-3 text-right">
                    <div className="flex items-center justify-end gap-1.5 font-sans">
                      <button
                        onClick={() => handleSelectExp(item, 'builder')}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-semibold transition-all"
                        title="Open Visual Builder"
                      >
                        Builder
                      </button>
                      <button
                        onClick={() => handleSelectExp(item, 'analytics')}
                        className="px-2.5 py-1 rounded-lg bg-sky-950/80 hover:bg-sky-900/80 border border-sky-500/40 text-sky-300 text-[11px] font-semibold transition-all"
                        title="Open Analytics"
                      >
                        Analytics
                      </button>
                      <button
                        onClick={() => handleSelectExp(item, 'ai-analyst')}
                        className="px-2.5 py-1 rounded-lg bg-purple-950/80 hover:bg-purple-900/80 border border-purple-500/40 text-purple-300 text-[11px] font-semibold transition-all"
                        title="Query AI Analyst"
                      >
                        AI Analyst
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
