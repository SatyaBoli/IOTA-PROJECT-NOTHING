import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  Wand2, 
  ArrowRight, 
  Brain, 
  ShieldCheck, 
  RefreshCw,
  Info,
  Lightbulb,
  MessageSquare,
  Key,
  Sliders,
  RotateCcw,
  Zap,
  Trees,
  HelpCircle,
  Layers,
  FileCheck
} from 'lucide-react';
import { ExperimentDSL, ExperimentPlan } from '../../types/dsl';
import { ExperimentValidator } from '../../dsl/validator';
import { ExperimentStore } from '../../runtime/experimentStore';
import { ExperimentPlanner } from '../../dsl/experimentPlanner';
import { SemanticParser } from '../../dsl/semanticParser';

interface AiDesignerModalProps {
  dsl: ExperimentDSL;
  onApplyDsl: (newDsl: ExperimentDSL) => void;
  onNavigateToBuilder: () => void;
  onLaunchParticipant?: (newDsl: ExperimentDSL) => void;
}

export const AiDesignerModal: React.FC<AiDesignerModalProps> = ({
  dsl,
  onApplyDsl,
  onNavigateToBuilder,
  onLaunchParticipant
}) => {
  const [prompt, setPrompt] = useState(
    "Make a tree perception experiment where participants see small, medium, and large trees and answer questions about size and safety. Include true, false and I don't know responses. Make it feel like a forest exploration game."
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDraft, setGeneratedDraft] = useState<ExperimentDSL | null>(null);
  const [generatedPlan, setGeneratedPlan] = useState<ExperimentPlan | null>(null);
  const [assumptions, setAssumptions] = useState<string[]>([]);

  // Conversational Iterative Patching State
  const [chatInput, setChatInput] = useState('');
  const [patchHistory, setPatchHistory] = useState<Array<{ instruction: string; resultText: string; time: string }>>([]);

  // Provider & API Key Settings
  const [apiKey, setApiKey] = useState('');
  const [provider, setProvider] = useState<'gemini' | 'openai'>('gemini');
  const [showSettings, setShowSettings] = useState(false);

  const presets = [
    {
      title: "Tree Perception & Safety Game (Multi-Condition + Unknown)",
      prompt: "Make a tree perception experiment where participants see small, medium, and large trees and answer questions about size and safety. Include true, false and I don't know responses. Make it feel like a forest exploration game."
    },
    {
      title: "Factorial Environment Study (3 Sizes × 2 Weathers = 6 Cells)",
      prompt: "Show small, medium and large trees with sunny and rainy backgrounds. 30 balanced trials."
    },
    {
      title: "Psychometric Sentence Rating (Depressive Symptoms Likert 1-5)",
      prompt: "Create a study to assess depressive symptoms through 18 sentence agreement ratings on a 1-5 Likert scale with academic clean presentation."
    },
    {
      title: "Car vs Cake Choice Task (Emoji 🚗 vs 🍰)",
      prompt: "Press F for Car and D for Cake. 32 balanced trials with reaction time."
    },
    {
      title: "Space Orbit Reaction Task (2AFC)",
      prompt: "Create a 3-minute space reaction experiment. Display red or blue objects. Press A for red and L for blue. Randomize trials. Keep the conditions balanced. Record reaction time and accuracy."
    }
  ];

  // Synthesizes experiment architecture using ExperimentPlanner (or live API if key is entered)
  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      if (apiKey && apiKey.trim().length > 10) {
        const result = await SemanticParser.parsePrompt(prompt, apiKey, provider);
        setGeneratedDraft(result.dsl);
        setAssumptions(result.assumptions);
        setPatchHistory([]);
        ExperimentStore.saveExperiment(result.dsl);
        ExperimentStore.setActiveExperimentId(result.dsl.experiment.id);
        onApplyDsl(result.dsl);
      } else {
        const result = ExperimentPlanner.planExperiment(prompt);
        setGeneratedDraft(result.dsl);
        setGeneratedPlan(result.plan);
        setAssumptions(result.assumptions);
        setPatchHistory([]);
        ExperimentStore.saveExperiment(result.dsl);
        ExperimentStore.setActiveExperimentId(result.dsl.experiment.id);
        onApplyDsl(result.dsl);
      }
    } catch (err) {
      console.error('Planner error, falling back:', err);
      const fallbackResult = ExperimentPlanner.planExperiment(prompt);
      setGeneratedDraft(fallbackResult.dsl);
      setGeneratedPlan(fallbackResult.plan);
      setAssumptions(fallbackResult.assumptions);
      ExperimentStore.saveExperiment(fallbackResult.dsl);
      ExperimentStore.setActiveExperimentId(fallbackResult.dsl.experiment.id);
      onApplyDsl(fallbackResult.dsl);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handles conversational iterative patching (Section 17)
  const handleApplyChatPatch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;

    const baseDsl = generatedDraft || dsl;
    const { dsl: updatedDsl, description } = ExperimentPlanner.applyStructuredPatch(baseDsl, chatInput.trim());

    setGeneratedDraft(updatedDsl);
    if (updatedDsl.plan) setGeneratedPlan(updatedDsl.plan);
    ExperimentStore.saveExperiment(updatedDsl);
    ExperimentStore.setActiveExperimentId(updatedDsl.experiment.id);
    onApplyDsl(updatedDsl);

    setPatchHistory(prev => [
      {
        instruction: chatInput.trim(),
        resultText: description,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      },
      ...prev
    ]);

    setChatInput('');
  };

  const handleApply = () => {
    const target = generatedDraft || dsl;
    onApplyDsl(target);
    onNavigateToBuilder();
  };

  const handleLaunchInParticipant = () => {
    const target = generatedDraft || dsl;
    ExperimentStore.saveExperiment(target);
    ExperimentStore.setActiveExperimentId(target.experiment.id);
    onApplyDsl(target);

    if (onLaunchParticipant) {
      onLaunchParticipant(target);
    } else {
      onNavigateToBuilder();
    }
  };

  const targetDsl = generatedDraft || dsl;
  const validation = ExperimentValidator.validate(targetDsl);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-400" />
            <span>AI Research Game & Experiment Generator</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Author complete multi-condition research experiments, trial banks, and gamified skins from natural language.
          </p>
        </div>

        <button
          onClick={() => setShowSettings(!showSettings)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-300 text-xs transition-colors self-start sm:self-auto"
        >
          <Sliders className="h-3.5 w-3.5 text-purple-400" />
          <span>{showSettings ? 'Hide AI Config' : 'AI Gateway Config'}</span>
        </button>
      </div>

      {/* Gateway Configuration */}
      {showSettings && (
        <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white flex items-center gap-2 text-xs">
              <Key className="h-4 w-4 text-purple-400" />
              <span>AI Provider & Asset Gateway Settings</span>
            </span>
            <span className="text-[10px] text-slate-400">
              Provider Boundary: Decoupled via AssetService
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Provider</label>
              <select
                value={provider}
                onChange={(e) => setProvider(e.target.value as 'gemini' | 'openai')}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-xs"
              >
                <option value="gemini">Google Gemini 1.5 Flash</option>
                <option value="openai">OpenAI GPT-4o / GPT-4o-mini</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-[11px] text-slate-400 mb-1">Optional API Key (Stored in session)</label>
              <input
                type="password"
                placeholder="Enter API key for live external LLM generation..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-xs"
              />
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Natural Language Prompt Input & Presets */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span>Researcher Goal / Hypothesis</span>
              </label>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800">
                AssetService: Active
              </span>
            </div>
            <textarea
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your research experiment (conditions, question types, stimuli, game skin, balancing)..."
              className="w-full bg-slate-900/80 border border-slate-700 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-purple-500 transition-colors resize-none"
            />

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mt-3">
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <Lightbulb className="h-3.5 w-3.5 text-amber-400" />
                <span>Supports Tree Perception, Clinical Scales, Factorial Grids, & Arcade HUD</span>
              </span>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs px-4 py-2.5 rounded-xl transition-all shadow-lg shadow-purple-500/25 disabled:opacity-50 ring-2 ring-purple-500/20 hover:ring-purple-400/40"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span>Decomposing Intent & Conditions...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="h-4 w-4" />
                    <span>Generate Research Experiment</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>Representative Research Paradigms</span>
              <span className="text-[10px] text-slate-500 font-normal">Click to load</span>
            </h3>
            <div className="space-y-2">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(preset.prompt);
                    setGeneratedDraft(null);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800/80 hover:border-purple-500/40 transition-all flex items-center justify-between group"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-200 group-hover:text-purple-300">
                      {preset.title}
                    </div>
                    <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                      {preset.prompt}
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-slate-600 group-hover:text-purple-400 shrink-0 ml-2" />
                </button>
              ))}
            </div>
          </div>

          {/* Conversational Structured Patching (Section 17) */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <MessageSquare className="h-3.5 w-3.5 text-sky-400" />
                <span>Structured Parameter Patching (No Regeneration)</span>
              </h3>
              <span className="text-[10px] text-sky-400 bg-sky-950/40 px-2 py-0.5 rounded border border-sky-800">
                Token-Efficient Edit
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Apply surgical modifications without wiping the experiment (e.g., <em>"Change 30 trials to 60"</em>, <em>"Add an unknown option"</em>, <em>"Switch skin to academic"</em>, <em>"Change small to tiny"</em>).
            </p>

            {/* Patch History Log */}
            {patchHistory.length > 0 && (
              <div className="space-y-1.5 mb-3 max-h-36 overflow-y-auto pr-1">
                {patchHistory.map((item, i) => (
                  <div key={i} className="text-[11px] p-2 rounded-lg bg-slate-900/90 border border-slate-800 flex items-start justify-between gap-2">
                    <div>
                      <span className="text-purple-400 font-semibold">"{item.instruction}"</span>
                      <span className="text-slate-300 ml-2">→ {item.resultText}</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 shrink-0">{item.time}</span>
                  </div>
                ))}
              </div>
            )}

            <form onSubmit={handleApplyChatPatch} className="flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder='e.g., "Change 30 trials to 60", "Add unknown option", "Forest skin"...'
                className="flex-1 bg-slate-900/80 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500 transition-colors"
              />
              <button
                type="submit"
                disabled={!chatInput.trim()}
                className="flex items-center gap-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-medium text-xs px-3.5 py-2 rounded-xl transition-all"
              >
                <Zap className="h-3.5 w-3.5" />
                <span>Apply Patch</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: AI Plan, Visible Assumptions, Conditions, & Launch */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Brain className="h-4 w-4 text-sky-400" />
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Experiment Plan & Assumptions
                </h3>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                generatedDraft 
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800' 
                  : 'bg-amber-950/60 text-amber-400 border border-amber-800'
              }`}>
                {generatedDraft ? 'Plan Synthesized' : 'Awaiting Input'}
              </span>
            </div>

            {/* Generated Plan Overview */}
            {generatedDraft && (
              <div className="mb-4 p-3.5 rounded-xl bg-gradient-to-br from-slate-900 to-slate-950 border border-sky-500/30 text-xs shadow-md">
                <div className="font-bold text-sky-400 flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span>Synthesized Experiment:</span>
                </div>
                <div className="text-white font-bold text-sm">{generatedDraft.experiment.title}</div>
                <div className="text-[11px] text-slate-400 mt-1">{generatedDraft.experiment.description}</div>
                
                {/* Condition Chips */}
                {generatedDraft.conditions && generatedDraft.conditions.length > 0 && (
                  <div className="mt-3">
                    <div className="text-[10px] font-mono uppercase text-slate-400 mb-1.5">Conditions ({generatedDraft.conditions.length}):</div>
                    <div className="flex flex-wrap gap-1.5">
                      {generatedDraft.conditions.map((c) => (
                        <span key={c.id} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-emerald-300">
                          {c.label} {c.variables?.emoji || ''}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Templates Chips */}
                {generatedDraft.trial_templates && generatedDraft.trial_templates.length > 0 && (
                  <div className="mt-2.5">
                    <div className="text-[10px] font-mono uppercase text-slate-400 mb-1.5">Question Templates ({generatedDraft.trial_templates.length}):</div>
                    <div className="space-y-1">
                      {generatedDraft.trial_templates.map((t) => (
                        <div key={t.id} className="text-[11px] text-slate-300 bg-slate-950/50 p-1.5 rounded border border-slate-800/80">
                          <span className="font-semibold text-purple-300">[{t.response_type}]</span> {t.question_template}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Visible Assumptions Disclosure (Section 13) */}
            {assumptions.length > 0 && (
              <div className="mb-4 p-3 rounded-xl bg-amber-950/20 border border-amber-500/40 text-xs">
                <div className="text-amber-400 font-bold mb-1.5 flex items-center gap-1.5 text-xs">
                  <Info className="h-4 w-4" />
                  <span>Declared Assumptions (Review Before Launching):</span>
                </div>
                <ul className="list-disc list-inside text-[11px] text-amber-200/90 space-y-1 leading-relaxed">
                  {assumptions.map((assump, idx) => (
                    <li key={idx}>{assump}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Critic Verification Checklist */}
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 flex gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-[11px]">Asset Provider: Decoupled via AssetService</div>
                  <div className="text-[10px] text-emerald-400/80">
                    Queried through internal provider boundary (Option 1 EmojiHub + Local fallback + Future DB hook).
                  </div>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-sky-950/30 border border-sky-500/30 text-sky-300 flex gap-2">
                <FileCheck className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-[11px]">Token-Efficiency: Deterministic Runtime Expansion</div>
                  <div className="text-[10px] text-sky-400/80">
                    Zero LLM calls during participant runtime. Trials compiled from stored templates.
                  </div>
                </div>
              </div>
            </div>

            {/* Launch & Commit Actions */}
            <div className="mt-5 pt-4 border-t border-slate-800 space-y-2.5">
              <button
                onClick={handleLaunchInParticipant}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-500/20 active:scale-[0.99]"
              >
                <Zap className="h-4 w-4" />
                <span>Save & Launch in Participant Mode Now 🚀</span>
              </button>

              <button
                onClick={handleApply}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white font-medium text-xs transition-all flex items-center justify-center gap-2"
              >
                <span>Commit DSL & View on Visual Canvas</span>
                <ArrowRight className="h-4 w-4 text-sky-400" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
