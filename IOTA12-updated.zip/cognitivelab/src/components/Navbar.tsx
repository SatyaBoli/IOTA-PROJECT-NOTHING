import React from 'react';
import { 
  Network, 
  Sparkles, 
  Play, 
  BarChart3, 
  Code2, 
  Gamepad2, 
  BookOpen, 
  CheckCircle2, 
  AlertTriangle,
  Bug,
  LayoutDashboard,
  Brain,
  Radio,
  FileSpreadsheet,
  Compass,
  UserCheck,
  ShieldAlert
} from 'lucide-react';
import { ExperimentDSL, ValidationIssue } from '../types/dsl';

export type WorkspaceRole = 'researcher' | 'participant';

export type TabId = 
  | 'command-center'
  | 'builder' 
  | 'ai' 
  | 'runner' 
  | 'debugger' 
  | 'telemetry'
  | 'analytics' 
  | 'ai-analyst'
  | 'exports'
  | 'code'
  | 'participant-dashboard';

interface NavbarProps {
  currentRole: WorkspaceRole;
  setCurrentRole: (role: WorkspaceRole) => void;
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  dsl: ExperimentDSL;
  setDsl: React.Dispatch<React.SetStateAction<ExperimentDSL>>;
  validationIssues: ValidationIssue[];
  isValid: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  setCurrentRole,
  activeTab,
  setActiveTab,
  dsl,
  setDsl,
  validationIssues,
  isValid
}) => {
  const toggleGameSkin = () => {
    setDsl(prev => ({
      ...prev,
      game_skin: {
        ...prev.game_skin,
        enabled: !prev.game_skin.enabled
      }
    }));
  };

  const criticalErrors = validationIssues.filter(i => i.severity === 'critical');

  return (
    <header className="border-b border-slate-800 bg-[#070a13]/95 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
        {/* Brand & Active Experiment Title */}
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-sky-500/20 shrink-0">
            <Network className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-white">CognitiveLab</span>
              <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full ${
                currentRole === 'researcher'
                  ? 'bg-purple-950/80 text-purple-300 border border-purple-800'
                  : 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
              }`}>
                {currentRole === 'researcher' ? 'Researcher Hub' : 'Participant Mode'}
              </span>
            </div>
            <div className="text-xs text-slate-400 font-medium truncate max-w-xs sm:max-w-sm">
              {dsl.experiment.title}
            </div>
          </div>
        </div>

        {/* Dynamic Navigation Tabs based on Active Role */}
        <nav className="hidden lg:flex items-center bg-slate-900/80 p-1 rounded-xl border border-slate-800 text-xs font-medium overflow-x-auto max-w-2xl">
          {currentRole === 'participant' ? (
            <>
              <button
                onClick={() => setActiveTab('participant-dashboard')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'participant-dashboard'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Compass className="h-4 w-4" />
                <span>Studies Portal</span>
              </button>

              <button
                onClick={() => setActiveTab('runner')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'runner'
                    ? 'bg-emerald-500 text-white shadow-sm font-semibold'
                    : 'text-emerald-400 hover:bg-emerald-950/30'
                }`}
              >
                <Play className="h-4 w-4 fill-current" />
                <span>Live Runner</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setActiveTab('command-center')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'command-center'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <LayoutDashboard className="h-4 w-4" />
                <span>Command Center</span>
              </button>

              <button
                onClick={() => setActiveTab('builder')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'builder'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Network className="h-4 w-4" />
                <span>Visual Graph</span>
              </button>

              <button
                onClick={() => setActiveTab('ai')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'ai'
                    ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sparkles className="h-4 w-4" />
                <span>AI Designer</span>
              </button>

              <button
                onClick={() => setActiveTab('debugger')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'debugger'
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Bug className="h-4 w-4" />
                <span>Step Debugger</span>
              </button>

              <button
                onClick={() => setActiveTab('telemetry')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'telemetry'
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Radio className="h-4 w-4" />
                <span>Live Telemetry</span>
              </button>

              <button
                onClick={() => setActiveTab('analytics')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'analytics'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <BarChart3 className="h-4 w-4" />
                <span>Analytics</span>
              </button>

              <button
                onClick={() => setActiveTab('ai-analyst')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'ai-analyst'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                <Brain className="h-4 w-4" />
                <span>AI Analyst</span>
              </button>

              <button
                onClick={() => setActiveTab('exports')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'exports'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileSpreadsheet className="h-4 w-4" />
                <span>Data & R/Py</span>
              </button>

              <button
                onClick={() => setActiveTab('code')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'code'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Code2 className="h-4 w-4" />
                <span>DSL JSON</span>
              </button>
            </>
          )}
        </nav>

        {/* Right Controls: Role Switcher, Skin Toggle & Validation */}
        <div className="flex items-center gap-2.5">
          {/* Dual Role Persona Switcher */}
          <button
            onClick={() => {
              if (currentRole === 'researcher') {
                setCurrentRole('participant');
                setActiveTab('participant-dashboard');
              } else {
                setCurrentRole('researcher');
                setActiveTab('command-center');
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              currentRole === 'researcher'
                ? 'bg-purple-950/50 border-purple-500/50 text-purple-300 hover:bg-purple-900/50'
                : 'bg-emerald-950/50 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/50'
            }`}
            title="Switch between Participant Experience and Researcher Command Center"
          >
            <UserCheck className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">
              {currentRole === 'researcher' ? 'View as Participant' : 'Switch to Researcher'}
            </span>
          </button>

          {/* Gamification Skin Toggle (Researcher view only) */}
          {currentRole === 'researcher' && (
            <button
              onClick={toggleGameSkin}
              title={dsl.game_skin.enabled ? "Switch to Academic Plain Skin" : "Enable Space Arcade Gamification Skin"}
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                dsl.game_skin.enabled
                  ? 'bg-purple-950/40 border-purple-500/50 text-purple-300'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400'
              }`}
            >
              {dsl.game_skin.enabled ? (
                <>
                  <Gamepad2 className="h-3.5 w-3.5 text-purple-400" />
                  <span className="text-[11px]">Arcade</span>
                </>
              ) : (
                <>
                  <BookOpen className="h-3.5 w-3.5 text-slate-400" />
                  <span className="text-[11px]">Plain</span>
                </>
              )}
            </button>
          )}

          {/* Validation Status Indicator */}
          <div className="flex items-center">
            {isValid ? (
              <div 
                className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-1.5 rounded-lg"
                title="Experiment passes all structural and logical validation checks"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span className="hidden md:inline font-mono">Validated</span>
              </div>
            ) : (
              <div 
                className="flex items-center gap-1 text-[11px] text-rose-400 bg-rose-950/40 border border-rose-500/30 px-2 py-1.5 rounded-lg"
                title={`${criticalErrors.length} critical validation error(s)`}
              >
                <AlertTriangle className="h-3.5 w-3.5" />
                <span className="font-mono">{criticalErrors.length}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
