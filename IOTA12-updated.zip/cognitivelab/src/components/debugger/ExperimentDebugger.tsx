import React, { useState, useMemo, useEffect } from 'react';
import { 
  Bug, 
  Play, 
  RotateCcw, 
  FastForward, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ArrowRight, 
  Code, 
  Download, 
  Database, 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  Zap,
  Sliders
} from 'lucide-react';
import { ExperimentDSL, TrialRecord } from '../../types/dsl';
import { ExperimentCompiler, CompiledExperiment } from '../../runtime/compiler';
import { LocalExperimentStorage } from '../../runtime/storage';
import { Exporter } from '../../export/Exporter';

interface ExperimentDebuggerProps {
  dsl: ExperimentDSL;
  onNavigateToAnalytics?: () => void;
}

interface SimulatedTrialOutcome {
  trialIndex: number;
  condition: string;
  stimulus: string;
  expectedKey: string;
  responseKey: string | null;
  reactionTimeMs: number | null;
  isCorrect: boolean | null;
  scoreDelta: number;
  runningScore: number;
  runningStreak: number;
  evaluatedBranch: 'true_branch' | 'false_branch' | 'timeout_branch';
  timestamp: string;
}

export const ExperimentDebugger: React.FC<ExperimentDebuggerProps> = ({
  dsl,
  onNavigateToAnalytics
}) => {
  const [seed, setSeed] = useState<number>(42);
  const [currentTrialIdx, setCurrentTrialIdx] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [history, setHistory] = useState<SimulatedTrialOutcome[]>([]);
  const [customKey, setCustomKey] = useState<string>('');
  const [customRt, setCustomRt] = useState<number>(400);
  const [autoAccuracy, setAutoAccuracy] = useState<number>(85);
  const [autoMeanRt, setAutoMeanRt] = useState<number>(420);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Compile experiment plan
  const compiled: CompiledExperiment = useMemo(() => {
    return ExperimentCompiler.compile(dsl, seed);
  }, [dsl, seed]);

  const totalTrials = compiled.trials.length;
  const isFinished = currentTrialIdx >= totalTrials;
  const currentTrial = !isFinished ? compiled.trials[currentTrialIdx] : null;

  // Initialize custom key to first allowed key
  useEffect(() => {
    if (compiled.allowedKeys.length > 0 && !customKey) {
      setCustomKey(compiled.allowedKeys[0]);
    }
  }, [compiled.allowedKeys, customKey]);

  // Reset simulation
  const handleReset = () => {
    setCurrentTrialIdx(0);
    setScore(0);
    setStreak(0);
    setLives(3);
    setHistory([]);
    setExportNotice(null);
  };

  // Step single trial with mock response
  const handleStepTrial = (responseKey: string | null, rtMs: number | null) => {
    if (isFinished || !currentTrial) return;

    let isCorrect: boolean | null = null;
    let scoreDelta = 0;
    let newStreak = streak;
    let newLives = lives;
    let evaluatedBranch: 'true_branch' | 'false_branch' | 'timeout_branch' = 'false_branch';

    if (responseKey === null || (rtMs !== null && rtMs > compiled.responseDeadlineMs)) {
      // Timeout
      isCorrect = false;
      newStreak = 0;
      scoreDelta = -25;
      newLives = Math.max(0, lives - 1);
      evaluatedBranch = 'timeout_branch';
    } else if (responseKey.toLowerCase() === currentTrial.expectedKey.toLowerCase()) {
      // Correct
      isCorrect = true;
      newStreak = streak + 1;
      const base = compiled.scoreRules.basePoints;
      const bonus = newStreak > 2 ? Math.round(base * (compiled.scoreRules.streakMultiplier - 1)) : 0;
      scoreDelta = base + bonus;
      evaluatedBranch = 'true_branch';
    } else {
      // Incorrect
      isCorrect = false;
      newStreak = 0;
      scoreDelta = -50;
      newLives = Math.max(0, lives - 1);
      evaluatedBranch = 'false_branch';
    }

    const newScore = Math.max(0, score + scoreDelta);

    const outcome: SimulatedTrialOutcome = {
      trialIndex: currentTrialIdx + 1,
      condition: currentTrial.condition,
      stimulus: currentTrial.stimulusText || currentTrial.hexColor || currentTrial.stimulusValue,
      expectedKey: currentTrial.expectedKey,
      responseKey,
      reactionTimeMs: rtMs,
      isCorrect,
      scoreDelta,
      runningScore: newScore,
      runningStreak: newStreak,
      evaluatedBranch,
      timestamp: new Date().toISOString()
    };

    setScore(newScore);
    setStreak(newStreak);
    setLives(newLives);
    setHistory(prev => [...prev, outcome]);
    setCurrentTrialIdx(idx => idx + 1);
  };

  // Quick Mock Actions
  const handleSimulateCorrect = () => {
    if (!currentTrial) return;
    const rt = Math.round(340 + Math.random() * 140);
    handleStepTrial(currentTrial.expectedKey, rt);
  };

  const handleSimulateIncorrect = () => {
    if (!currentTrial) return;
    const wrongKey = compiled.allowedKeys.find(k => k.toLowerCase() !== currentTrial.expectedKey.toLowerCase()) || 'x';
    const rt = Math.round(450 + Math.random() * 180);
    handleStepTrial(wrongKey, rt);
  };

  const handleSimulateTimeout = () => {
    handleStepTrial(null, compiled.responseDeadlineMs + 100);
  };

  const handleSimulateCustom = () => {
    handleStepTrial(customKey, customRt);
  };

  // Auto-Simulate Remaining Trials in Batch
  const handleAutoSimulate = (count?: number) => {
    const trialsToSimulate = count ? Math.min(count, totalTrials - currentTrialIdx) : (totalTrials - currentTrialIdx);
    if (trialsToSimulate <= 0) return;

    let curScore = score;
    let curStreak = streak;
    let curLives = lives;
    const newOutcomes: SimulatedTrialOutcome[] = [];

    for (let i = 0; i < trialsToSimulate; i++) {
      const idx = currentTrialIdx + i;
      const trial = compiled.trials[idx];
      const willBeCorrect = (Math.random() * 100) < autoAccuracy;

      let key: string | null = null;
      let rt: number | null = null;
      let isCorrect: boolean | null = false;
      let delta = 0;
      let branch: 'true_branch' | 'false_branch' | 'timeout_branch' = 'false_branch';

      if (willBeCorrect) {
        key = trial.expectedKey;
        rt = Math.max(120, Math.round(autoMeanRt + (Math.random() - 0.5) * 120));
        isCorrect = true;
        curStreak += 1;
        const base = compiled.scoreRules.basePoints;
        const bonus = curStreak > 2 ? Math.round(base * (compiled.scoreRules.streakMultiplier - 1)) : 0;
        delta = base + bonus;
        branch = 'true_branch';
      } else {
        const isTimeout = Math.random() < 0.2;
        if (isTimeout) {
          key = null;
          rt = compiled.responseDeadlineMs + 120;
          curStreak = 0;
          curLives = Math.max(0, curLives - 1);
          delta = -25;
          branch = 'timeout_branch';
        } else {
          key = compiled.allowedKeys.find(k => k.toLowerCase() !== trial.expectedKey.toLowerCase()) || 'x';
          rt = Math.max(180, Math.round(autoMeanRt + 80 + (Math.random() - 0.5) * 150));
          curStreak = 0;
          curLives = Math.max(0, curLives - 1);
          delta = -50;
          branch = 'false_branch';
        }
      }

      curScore = Math.max(0, curScore + delta);

      newOutcomes.push({
        trialIndex: idx + 1,
        condition: trial.condition,
        stimulus: trial.stimulusText || trial.hexColor || trial.stimulusValue,
        expectedKey: trial.expectedKey,
        responseKey: key,
        reactionTimeMs: rt,
        isCorrect,
        scoreDelta: delta,
        runningScore: curScore,
        runningStreak: curStreak,
        evaluatedBranch: branch,
        timestamp: new Date().toISOString()
      });
    }

    setScore(curScore);
    setStreak(curStreak);
    setLives(curLives);
    setHistory(prev => [...prev, ...newOutcomes]);
    setCurrentTrialIdx(idx => idx + trialsToSimulate);
  };

  // Step Backward / Undo Last Trial
  const handleUndo = () => {
    if (history.length === 0) return;
    const newHistory = [...history];
    newHistory.pop();
    const prevTrial = newHistory.length > 0 ? newHistory[newHistory.length - 1] : null;

    setHistory(newHistory);
    setCurrentTrialIdx(prev => Math.max(0, prev - 1));
    setScore(prevTrial ? prevTrial.runningScore : 0);
    setStreak(prevTrial ? prevTrial.runningStreak : 0);
  };

  // Commit Simulated Session to Storage for Analytics
  const handleCommitToDatabase = async () => {
    if (history.length === 0) return;
    setIsExporting(true);
    const mockSessionId = `sim_session_${Date.now()}`;

    try {
      for (const item of history) {
        const record: TrialRecord = {
          id: `sim_tr_${mockSessionId}_${item.trialIndex}`,
          sessionId: mockSessionId,
          trialIndex: item.trialIndex,
          nodeId: 'node_stimulus_display',
          condition: item.condition,
          stimulus: item.stimulus,
          responseKey: item.responseKey,
          expectedKey: item.expectedKey,
          isCorrect: item.isCorrect,
          reactionTimeMs: item.reactionTimeMs,
          frameOnsetTs: performance.now(),
          displayLagMs: 0.85,
          score: item.runningScore,
          streak: item.runningStreak,
          qualityFlags: item.reactionTimeMs && item.reactionTimeMs < 150 ? ['fast_guess'] : [],
          timestamp: item.timestamp
        };
        await LocalExperimentStorage.bufferTrial(record);
      }

      setExportNotice(`Successfully exported ${history.length} simulated trials to database under session ${mockSessionId}!`);
    } catch (err) {
      console.error('Failed to commit simulated session', err);
      setExportNotice('Failed to commit trials to database.');
    } finally {
      setIsExporting(false);
    }
  };

  // Export CSV directly from debugger
  const handleDownloadCSV = () => {
    if (history.length === 0) return;
    const mockRecords: TrialRecord[] = history.map((item, idx) => ({
      id: `sim_${idx + 1}`,
      sessionId: `sim_session_${Date.now()}`,
      trialIndex: item.trialIndex,
      nodeId: 'node_stimulus_display',
      condition: item.condition,
      stimulus: item.stimulus,
      responseKey: item.responseKey,
      expectedKey: item.expectedKey,
      isCorrect: item.isCorrect,
      reactionTimeMs: item.reactionTimeMs,
      frameOnsetTs: performance.now(),
      displayLagMs: 0.85,
      score: item.runningScore,
      streak: item.runningStreak,
      qualityFlags: [],
      timestamp: item.timestamp
    }));

    const csvContent = Exporter.generateLongCSV(mockRecords, dsl);
    Exporter.downloadFile(`simulated_experiment_trials_${Date.now()}.csv`, csvContent, 'text/csv');
  };

  // Summary Metrics
  const correctCount = history.filter(h => h.isCorrect === true).length;
  const currentAccuracy = history.length > 0 ? Math.round((correctCount / history.length) * 100) : 0;
  const validRts = history.filter(h => h.reactionTimeMs !== null).map(h => h.reactionTimeMs as number);
  const meanRt = validRts.length > 0 ? Math.round(validRts.reduce((a, b) => a + b, 0) / validRts.length) : 0;

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-600 text-white shadow-lg shadow-rose-500/20">
            <Bug className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              Visual Step-Through & Simulation Debugger
              <span className="text-[10px] font-mono font-normal bg-rose-950/60 text-rose-300 border border-rose-800 px-2 py-0.5 rounded-full">
                Interactive State Inspector
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Step trial-by-trial, mock keypress responses, evaluate JSON Logic branches, and verify dynamic state variables without manual play.
            </p>
          </div>
        </div>

        {/* Global Toolbar */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-white transition-all"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Simulation</span>
          </button>
          {history.length > 0 && (
            <button
              onClick={handleCommitToDatabase}
              disabled={isExporting}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition-all"
            >
              <Database className="h-3.5 w-3.5" />
              <span>{isExporting ? 'Exporting...' : 'Export to DB'}</span>
            </button>
          )}
          {history.length > 0 && (
            <button
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-sm transition-all"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          )}
        </div>
      </div>

      {exportNotice && (
        <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            <span>{exportNotice}</span>
          </div>
          {onNavigateToAnalytics && (
            <button
              onClick={onNavigateToAnalytics}
              className="text-emerald-400 hover:text-emerald-200 underline font-semibold flex items-center gap-1"
            >
              <span>View in Analytics Tab</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Top Overview Cards: Live State Inspection */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Trial Progress</div>
          <div className="text-xl font-bold text-white font-mono">
            {currentTrialIdx} <span className="text-xs text-slate-500 font-normal">/ {totalTrials}</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div 
              className="bg-sky-500 h-full transition-all" 
              style={{ width: `${(currentTrialIdx / Math.max(totalTrials, 1)) * 100}%` }}
            />
          </div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Running Score</div>
          <div className="text-xl font-bold text-amber-400 font-mono">
            {score.toLocaleString()} <span className="text-xs text-slate-500 font-normal">pts</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Streak: {streak}x</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Simulated Accuracy</div>
          <div className="text-xl font-bold text-emerald-400 font-mono">
            {currentAccuracy}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">{correctCount} / {history.length} trials</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Mean Reaction Time</div>
          <div className="text-xl font-bold text-sky-400 font-mono">
            {meanRt} <span className="text-xs text-slate-500 font-normal">ms</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Deadline: {compiled.responseDeadlineMs}ms</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Allowed Keys</div>
          <div className="text-base font-bold text-purple-300 font-mono flex items-center gap-1.5 mt-0.5">
            {compiled.allowedKeys.map(k => (
              <span key={k} className="px-1.5 py-0.5 rounded bg-purple-950/60 border border-purple-800 uppercase text-xs">
                {k}
              </span>
            ))}
          </div>
          <div className="text-[10px] text-slate-400 mt-1.5 font-mono">2AFC/3AFC Matrix</div>
        </div>

        <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] uppercase font-mono text-slate-400 mb-1">Mulberry32 Seed</div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <input
              type="number"
              value={seed}
              onChange={(e) => {
                setSeed(parseInt(e.target.value, 10) || 1);
                handleReset();
              }}
              className="w-16 bg-slate-900 border border-slate-700 text-white font-mono text-xs px-1.5 py-0.5 rounded"
            />
            <span className="text-[10px] text-emerald-400">Fixed</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Deterministic</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Trial Execution Controller & Condition Inspector */}
        <div className="lg:col-span-6 space-y-4">
          {/* Active Trial Inspector */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-sky-400" />
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Active Trial Inspector {currentTrial ? `(#${currentTrialIdx + 1})` : '(Completed)'}
                </h3>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                isFinished 
                  ? 'bg-purple-950/60 text-purple-300 border border-purple-800'
                  : 'bg-sky-950/60 text-sky-300 border border-sky-800'
              }`}>
                {isFinished ? 'Plan Completed' : 'Awaiting Response'}
              </span>
            </div>

            {currentTrial ? (
              <div className="space-y-4">
                {/* Stimulus Preview Card */}
                <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div 
                      className="h-12 w-12 rounded-xl flex items-center justify-center font-bold text-lg shadow-inner"
                      style={{ 
                        backgroundColor: currentTrial.hexColor ? currentTrial.hexColor : '#1e293b',
                        color: '#ffffff'
                      }}
                    >
                      {currentTrial.stimulusText ? currentTrial.stimulusText.substring(0, 3) : '•'}
                    </div>
                    <div>
                      <div className="text-xs font-mono text-slate-400">Condition: <strong className="text-white">{currentTrial.condition}</strong></div>
                      <div className="text-sm font-semibold text-white mt-0.5">
                        Stimulus: {currentTrial.stimulusText || currentTrial.stimulusValue || currentTrial.hexColor}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-mono uppercase text-slate-500">Expected Key</div>
                    <span className="inline-block mt-1 px-3 py-1 bg-emerald-950/80 border border-emerald-500/50 rounded-lg text-emerald-300 font-mono font-bold text-sm">
                      {currentTrial.expectedKey.toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* Pipeline Flow Visualization */}
                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase mb-2">Active Node Pipeline Sequence</div>
                  <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] font-mono text-slate-300 py-1">
                    <span className="px-2 py-1 rounded bg-slate-800 text-slate-400">node_fixation ({compiled.fixationDurationMs}ms)</span>
                    <ArrowRight className="h-3 w-3 text-slate-600 shrink-0" />
                    <span className="px-2 py-1 rounded bg-sky-950/80 border border-sky-500/50 text-sky-300 font-semibold shrink-0">
                      node_stimulus_display (active)
                    </span>
                    <ArrowRight className="h-3 w-3 text-slate-600 shrink-0" />
                    <span className="px-2 py-1 rounded bg-slate-800 text-slate-400 shrink-0">node_evaluate_condition</span>
                    <ArrowRight className="h-3 w-3 text-slate-600 shrink-0" />
                    <span className="px-2 py-1 rounded bg-slate-800 text-slate-400 shrink-0">node_iti ({compiled.itiDurationMs}ms)</span>
                  </div>
                </div>

                {/* Mock Response Stepper Buttons */}
                <div>
                  <div className="text-[10px] font-mono text-slate-400 uppercase mb-2">Step Single Trial with Mock Participant Action</div>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={handleSimulateCorrect}
                      className="py-2.5 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      <span>Mock Correct (380ms)</span>
                    </button>
                    <button
                      onClick={handleSimulateIncorrect}
                      className="py-2.5 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <XCircle className="h-4 w-4 text-rose-400" />
                      <span>Mock Error (520ms)</span>
                    </button>
                    <button
                      onClick={handleSimulateTimeout}
                      className="py-2.5 px-3 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Clock className="h-4 w-4 text-amber-400" />
                      <span>Mock Timeout</span>
                    </button>
                  </div>
                </div>

                {/* Custom Key / RT Step */}
                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase mb-2">Custom Injected Response</div>
                  <div className="flex items-center gap-2">
                    <select
                      value={customKey}
                      onChange={(e) => setCustomKey(e.target.value)}
                      className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono text-xs"
                    >
                      {compiled.allowedKeys.map(k => (
                        <option key={k} value={k}>Key: {k.toUpperCase()}</option>
                      ))}
                      <option value="invalid">Key: Other (Invalid)</option>
                    </select>

                    <div className="flex items-center gap-1 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-xs">
                      <span className="text-slate-500 font-mono">RT:</span>
                      <input
                        type="number"
                        value={customRt}
                        onChange={(e) => setCustomRt(parseInt(e.target.value, 10) || 300)}
                        className="w-16 bg-transparent text-white font-mono outline-none"
                      />
                      <span className="text-slate-500">ms</span>
                    </div>

                    <button
                      onClick={handleSimulateCustom}
                      className="flex-1 py-2 px-3 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-all flex items-center justify-center gap-1"
                    >
                      <Zap className="h-3.5 w-3.5" />
                      <span>Inject & Step</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center space-y-3">
                <CheckCircle2 className="h-10 w-10 text-emerald-400 mx-auto" />
                <div className="text-sm font-semibold text-white">Full Experiment Simulation Completed!</div>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  All {totalTrials} trials executed. You can inspect the complete execution trace below or commit to the database.
                </p>
                <div className="flex justify-center gap-2 pt-2">
                  <button
                    onClick={handleReset}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
                  >
                    Run Another Seed
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Batch Auto-Simulation Section */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <FastForward className="h-3.5 w-3.5 text-sky-400" />
                <span>Batch Auto-Simulation (Fast-Forward)</span>
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">Controllable Accuracy</span>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3 text-xs">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Cohort Accuracy (%): {autoAccuracy}%</label>
                <input
                  type="range"
                  min="40"
                  max="100"
                  value={autoAccuracy}
                  onChange={(e) => setAutoAccuracy(parseInt(e.target.value, 10))}
                  className="w-full accent-sky-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Mean RT: {autoMeanRt}ms</label>
                <input
                  type="range"
                  min="200"
                  max="900"
                  step="25"
                  value={autoMeanRt}
                  onChange={(e) => setAutoMeanRt(parseInt(e.target.value, 10))}
                  className="w-full accent-sky-500"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => handleAutoSimulate(10)}
                disabled={isFinished}
                className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold transition-all"
              >
                Fast-Forward 10 Trials
              </button>
              <button
                onClick={() => handleAutoSimulate()}
                disabled={isFinished}
                className="flex-1 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-xs font-semibold transition-all shadow-md"
              >
                Auto-Simulate All Remaining
              </button>
              {history.length > 0 && (
                <button
                  onClick={handleUndo}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-all"
                  title="Undo last trial"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic AST & JSON Logic Branch Inspector */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Code className="h-4 w-4 text-purple-400" />
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Condition & AST Branch Evaluator
                </h3>
              </div>
              <span className="text-[10px] font-mono text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800">
                JSON Logic Engine
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 border border-slate-800 space-y-2">
              <div className="text-slate-500">// Evaluated Rule Expression:</div>
              <div className="text-purple-300">
                {JSON.stringify({
                  "==": [
                    { "var": "response.key" },
                    { "var": "trial.expected_key" }
                  ]
                }, null, 2)}
              </div>
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Current Context:</span>
                <span className="text-sky-300">
                  expected = "{currentTrial?.expectedKey || '-'}"
                </span>
              </div>
            </div>

            {/* Last Branch Evaluation Status */}
            {history.length > 0 && (
              <div className="mt-3 p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
                <div className="font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Last Executed Branch: Trial #{history[history.length - 1].trialIndex}</span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Branch: <strong className={history[history.length - 1].isCorrect ? 'text-emerald-400' : 'text-rose-400'}>
                    {history[history.length - 1].evaluatedBranch}
                  </strong> → Triggered: {history[history.length - 1].isCorrect ? 'node_reward_score (+100)' : 'node_penalty_score (-50)'}
                </div>
              </div>
            )}
          </div>

          {/* Condition Matrix & Factor Distribution */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Generated Factorial Plan Matrix
            </h3>
            <div className="max-h-56 overflow-y-auto pr-1">
              <table className="w-full text-[11px] text-left">
                <thead className="text-[10px] uppercase font-mono text-slate-500 border-b border-slate-800">
                  <tr>
                    <th className="py-1.5 px-2">#</th>
                    <th className="py-1.5 px-2">Condition</th>
                    <th className="py-1.5 px-2">Stimulus</th>
                    <th className="py-1.5 px-2">Key</th>
                    <th className="py-1.5 px-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {compiled.trials.map((trial, i) => {
                    const isPassed = i < currentTrialIdx;
                    const isCurrent = i === currentTrialIdx;
                    const historyItem = history[i];

                    return (
                      <tr 
                        key={i} 
                        className={`${
                          isCurrent 
                            ? 'bg-sky-950/40 text-sky-200' 
                            : isPassed 
                            ? 'text-slate-400' 
                            : 'text-slate-500'
                        }`}
                      >
                        <td className="py-1.5 px-2 font-semibold">{i + 1}</td>
                        <td className="py-1.5 px-2">{trial.condition}</td>
                        <td className="py-1.5 px-2">{trial.stimulusText || trial.hexColor || trial.stimulusValue}</td>
                        <td className="py-1.5 px-2 font-bold uppercase">{trial.expectedKey}</td>
                        <td className="py-1.5 px-2 text-right">
                          {isPassed ? (
                            historyItem?.isCorrect ? (
                              <span className="text-emerald-400">✓ {historyItem.reactionTimeMs}ms</span>
                            ) : (
                              <span className="text-rose-400">✗ {historyItem?.reactionTimeMs ? `${historyItem.reactionTimeMs}ms` : 'timeout'}</span>
                            )
                          ) : isCurrent ? (
                            <span className="text-sky-400 animate-pulse">● active</span>
                          ) : (
                            <span className="text-slate-600">pending</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Full-Width Table: Chronological Simulation Trace */}
      <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-sky-400" />
            <span>Execution Trace History ({history.length} Trials Simulated)</span>
          </h3>
          <span className="text-[10px] font-mono text-slate-500">Chronological Event Stream</span>
        </div>

        {history.length > 0 ? (
          <div className="overflow-x-auto max-h-72 overflow-y-auto">
            <table className="w-full text-xs text-left">
              <thead className="text-[10px] uppercase font-mono text-slate-500 bg-slate-900/60 sticky top-0 border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Trial #</th>
                  <th className="py-2 px-3">Condition</th>
                  <th className="py-2 px-3">Stimulus</th>
                  <th className="py-2 px-3">Expected Key</th>
                  <th className="py-2 px-3">Pressed Key</th>
                  <th className="py-2 px-3">RT (ms)</th>
                  <th className="py-2 px-3">Outcome</th>
                  <th className="py-2 px-3">Score Δ</th>
                  <th className="py-2 px-3 text-right">Running Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 font-mono">
                {history.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2 px-3 text-slate-400 font-semibold">{item.trialIndex}</td>
                    <td className="py-2 px-3 text-slate-300">{item.condition}</td>
                    <td className="py-2 px-3 text-white font-sans">{item.stimulus}</td>
                    <td className="py-2 px-3 text-slate-300 uppercase font-bold">{item.expectedKey}</td>
                    <td className="py-2 px-3 font-bold uppercase">
                      {item.responseKey ? (
                        <span className={item.isCorrect ? 'text-emerald-400' : 'text-rose-400'}>
                          {item.responseKey}
                        </span>
                      ) : (
                        <span className="text-amber-400">None (Timeout)</span>
                      )}
                    </td>
                    <td className="py-2 px-3 text-sky-300">{item.reactionTimeMs ? `${item.reactionTimeMs} ms` : '-'}</td>
                    <td className="py-2 px-3">
                      {item.isCorrect === true && (
                        <span className="inline-flex items-center gap-1 text-emerald-400 font-sans font-semibold text-[11px]">
                          <CheckCircle2 className="h-3 w-3" /> Correct
                        </span>
                      )}
                      {item.isCorrect === false && (
                        <span className="inline-flex items-center gap-1 text-rose-400 font-sans font-semibold text-[11px]">
                          <XCircle className="h-3 w-3" /> Error
                        </span>
                      )}
                    </td>
                    <td className={`py-2 px-3 ${item.scoreDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {item.scoreDelta >= 0 ? `+${item.scoreDelta}` : item.scoreDelta}
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-amber-400">
                      {item.runningScore.toLocaleString()} pts
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-6 text-center text-xs text-slate-500 font-mono">
            No trials simulated yet. Click "Mock Correct", "Mock Error", or "Fast-Forward" above to start stepping through the experiment.
          </div>
        )}
      </div>
    </div>
  );
};
