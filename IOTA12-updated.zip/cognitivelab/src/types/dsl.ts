export type NodeType =
  | 'flow_start'
  | 'flow_end'
  | 'presentation_text'
  | 'presentation_fixation'
  | 'presentation_stimulus'
  | 'presentation_question'
  | 'response_keyboard'
  | 'response_multimodal'
  | 'trial_template_block'
  | 'logic_condition'
  | 'logic_loop'
  | 'randomization_balanced_block'
  | 'game_reward'
  | 'timing_wait'
  | 'timing_calibration'
  | 'data_record_trial';

export interface DSLNode {
  id: string;
  type: NodeType;
  label: string;
  config: Record<string, any>;
  position?: { x: number; y: number };
}

export interface DSLEdge {
  id: string;
  from: string;
  to: string;
  port?: string;
  label?: string;
}

export interface ExperimentMetadata {
  id: string;
  slug: string;
  version: number;
  title: string;
  description: string;
  created_at: string;
  author: {
    user_id: string;
    institution: string;
  };
  reproducibility: {
    dsl_version: string;
    target_runtime: string;
    hash_sha256?: string;
  };
}

export interface ParticipantSettings {
  allow_anonymous: boolean;
  enforce_fullscreen: boolean;
  minimum_display_hz: number;
  device_allowlist: string[];
  required_inputs: string[];
}

export interface ConsentSettings {
  required: boolean;
  ethics_protocol_id: string;
  statement_text: string;
  require_checkbox: boolean;
  minimum_age: number;
}

export type GameSkinTheme = 
  | 'deep-space-arcade' 
  | 'academic-clean' 
  | 'retro-synth' 
  | 'forest-adventure' 
  | 'food-challenge';

export interface GameSkinSettings {
  enabled: boolean;
  theme: GameSkinTheme;
  sound_enabled: boolean;
  hud_elements: {
    show_score: boolean;
    show_streak: boolean;
    show_progress_bar: boolean;
  };
  score_rules: {
    correct_base_points: number;
    streak_bonus_multiplier: number;
    incorrect_penalty: number;
    max_rt_for_bonus_ms: number;
  };
}

// -------------------------------------------------------------
// Scalable Experiment Architecture (Conditions, Templates & Branching)
// -------------------------------------------------------------

export type ResponseType =
  | 'keyboard_reaction'
  | 'true_false_unknown'
  | 'single_choice'
  | 'multiple_choice'
  | 'rating_scale'
  | 'slider'
  | 'open_text';

export interface BranchRule {
  outcome: string; // e.g., "unknown", "true", "false", "default"
  action: 'next_trial' | 'branch_node' | 'record_uncertainty_and_continue';
  target_node_id?: string;
}

export interface ExperimentCondition {
  id: string;
  label: string;
  variables: Record<string, any>;
  stimulus_ref?: {
    provider: string; // e.g., 'asset_service'
    asset_id: string;
    filter?: Record<string, any>;
  };
}

export interface TrialTemplate {
  id: string;
  question_template: string;
  stimulus_template: string;
  response_type: ResponseType;
  response_options?: string[]; // e.g. ["true", "false", "I don't know"] or ["small", "medium", "large"]
  scale_min?: number;
  scale_max?: number;
  scale_labels?: { min: string; max: string; mid?: string };
  correct_value_rule?: string;
  branching?: BranchRule[];
  metadata?: Record<string, any>;
}

export interface RandomizationSpec {
  strategy: 'balanced' | 'randomized' | 'blocked';
  total_trials: number;
  repetitions_per_condition?: number;
  no_repeat_max?: number;
  seed?: number;
}

export interface ExperimentPlan {
  research_objective: string;
  assumptions: string[]; // Explicit visible assumptions for researcher review
  independent_variables: { name: string; levels: string[] }[];
  dependent_variables: string[];
  conditions: ExperimentCondition[];
  trial_templates: TrialTemplate[];
  randomization: RandomizationSpec;
  presentation_skin: GameSkinTheme;
  data_provenance_schema: string[];
}

export interface ExperimentDSL {
  $schema?: string;
  experiment: ExperimentMetadata;
  participant_settings: ParticipantSettings;
  consent_settings: ConsentSettings;
  variables: Record<string, { type: 'string' | 'number' | 'boolean'; default: any; scope: 'global' | 'trial' }>;
  game_skin: GameSkinSettings;
  plan?: ExperimentPlan;
  conditions?: ExperimentCondition[];
  trial_templates?: TrialTemplate[];
  nodes: DSLNode[];
  edges: DSLEdge[];
}

export interface ValidationIssue {
  id: string;
  severity: 'critical' | 'warning' | 'info';
  category: 'structural' | 'logical' | 'timing' | 'ethics';
  nodeId?: string;
  message: string;
  suggestion?: string;
}

export interface TrialRecord {
  id: string;
  sessionId: string;
  experimentId?: string;
  experimentVersion?: number;
  trialIndex: number;
  nodeId: string;
  templateId?: string;
  stimulusId?: string;
  condition: string;
  conditionVariables?: Record<string, any>;
  stimulus: string;
  questionText?: string;
  responseType?: ResponseType;
  responseValue?: string | number | string[] | null;
  responseKey: string | null;
  expectedKey?: string;
  expectedValue?: string | number | null;
  isCorrect: boolean | null;
  isUncertain?: boolean; // Specific scientific flag for "I don't know" / "Uncertain"
  reactionTimeMs: number | null;
  frameOnsetTs: number;
  displayLagMs: number;
  score: number;
  streak: number;
  qualityFlags: string[];
  generationSource?: 'ai_planner' | 'manual_builder';
  assetSource?: string;
  timestamp: string;
}

export interface SessionCalibration {
  sessionId: string;
  measuredRefreshHz: number;
  frameJitterStdMs: number;
  userAgent: string;
  viewportDimensions: string;
  isStable: boolean;
}
