import { TrialRecord } from '../types/dsl';

export interface ConditionSummary {
  condition: string;
  trials: number;
  sessions: number;
  responseCounts: Array<{ response: string; count: number }>;
  meanRtMs: number | null;
  medianRtMs: number | null;
  accuracyPercent: number | null;
  uncertaintyCount: number;
  meanNumericResponse: number | null;
}

export interface DatasetSummary {
  trialCount: number;
  sessionCount: number;
  conditions: ConditionSummary[];
  responseTypes: string[];
  missingResponses: number;
}

const isUncertain = (trial: TrialRecord): boolean =>
  trial.isUncertain === true || /unknown|don't know|uncertain|not sure|can't tell|prefer not to say/i.test(String(trial.responseValue ?? ''));

const median = (values: number[]): number | null => {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};

export function summarizeDataset(trials: TrialRecord[]): DatasetSummary {
  const grouped = new Map<string, TrialRecord[]>();
  for (const trial of trials) {
    const group = grouped.get(trial.condition) || [];
    group.push(trial);
    grouped.set(trial.condition, group);
  }

  const conditions = Array.from(grouped, ([condition, rows]) => {
    const responseCounts = new Map<string, number>();
    rows.forEach(row => {
      const recordedResponse = row.responseValue ?? row.responseKey;
      if (recordedResponse !== null && recordedResponse !== undefined && String(recordedResponse).trim() !== '') {
        const response = String(recordedResponse);
        responseCounts.set(response, (responseCounts.get(response) || 0) + 1);
      }
    });

    const rts = rows.flatMap(row => row.reactionTimeMs !== null && Number.isFinite(row.reactionTimeMs) ? [row.reactionTimeMs] : []);
    const judged = rows.filter(row => row.isCorrect !== null && row.isCorrect !== undefined && !isUncertain(row));
    const numericResponses = rows
      .filter(row => row.responseType === 'rating_scale' || row.responseType === 'slider')
      .flatMap(row => {
        const value = Number(row.responseValue);
        return row.responseValue !== null && row.responseValue !== undefined && Number.isFinite(value) ? [value] : [];
      });

    return {
      condition,
      trials: rows.length,
      sessions: new Set(rows.map(row => row.sessionId)).size,
      responseCounts: Array.from(responseCounts, ([response, count]) => ({ response, count })).sort((a, b) => b.count - a.count || a.response.localeCompare(b.response)),
      meanRtMs: rts.length ? rts.reduce((sum, value) => sum + value, 0) / rts.length : null,
      medianRtMs: median(rts),
      accuracyPercent: judged.length ? (judged.filter(row => row.isCorrect === true).length / judged.length) * 100 : null,
      uncertaintyCount: rows.filter(isUncertain).length,
      meanNumericResponse: numericResponses.length ? numericResponses.reduce((sum, value) => sum + value, 0) / numericResponses.length : null,
    };
  }).sort((a, b) => a.condition.localeCompare(b.condition));

  return {
    trialCount: trials.length,
    sessionCount: new Set(trials.map(trial => trial.sessionId)).size,
    conditions,
    responseTypes: Array.from(new Set(trials.flatMap(trial => trial.responseType ? [trial.responseType] : []))).sort(),
    missingResponses: trials.filter(trial => trial.responseValue === 'TIMEOUT' || (trial.responseValue == null && trial.responseKey == null && trial.reactionTimeMs === null && trial.isCorrect !== true)).length,
  };
}

const percent = (count: number, total: number): string => total ? `${((count / total) * 100).toFixed(1)}%` : 'N/A';

export function answerDatasetQuestion(question: string, trials: TrialRecord[]): { text: string; formula: string; sample: string } {
  if (!trials.length) {
    return {
      text: 'There are no recorded participant responses for this study yet. Run the study or import a dataset, then ask again. I will not fill in missing data with a simulated cohort.',
      formula: 'No calculation: dataset contains 0 trial records.',
      sample: '0 sessions; 0 trials',
    };
  }

  const summary = summarizeDataset(trials);
  const query = question.toLowerCase();
  const conditionLines = summary.conditions.map(condition => {
    const measures: string[] = [`n=${condition.trials}`];
    if (condition.meanNumericResponse !== null) measures.push(`mean numeric response ${condition.meanNumericResponse.toFixed(2)}`);
    if (condition.meanRtMs !== null) measures.push(`mean RT ${condition.meanRtMs.toFixed(1)} ms`);
    if (condition.accuracyPercent !== null) measures.push(`accuracy ${condition.accuracyPercent.toFixed(1)}%`);
    if (condition.uncertaintyCount) measures.push(`${condition.uncertaintyCount} uncertain responses`);
    return `• ${condition.condition}: ${measures.join('; ')}`;
  });

  let text: string;
  let formula: string;

  if (/uncertain|unknown|don't know|not sure|can't tell|prefer not/i.test(query)) {
    text = `Uncertain responses: ${summary.conditions.map(c => `${c.condition}: ${c.uncertaintyCount}/${c.trials} (${percent(c.uncertaintyCount, c.trials)})`).join('; ')}. Total: ${summary.conditions.reduce((sum, c) => sum + c.uncertaintyCount, 0)}/${summary.trialCount} (${percent(summary.conditions.reduce((sum, c) => sum + c.uncertaintyCount, 0), summary.trialCount)}).`;
    formula = 'Uncertain count uses isUncertain=true or an explicit uncertainty response label; rate = count / condition trial count.';
  } else if (/accuracy|correct|error|wrong|mistake/i.test(query)) {
    text = summary.conditions.some(c => c.accuracyPercent !== null)
      ? `Accuracy is calculated only for records with a non-null correctness value.\n${conditionLines.join('\n')}`
      : 'This study has no scored correct/incorrect responses, so accuracy is not applicable. For ratings and preference questions, review the response distributions or mean numeric responses instead.';
    formula = 'accuracy = count(isCorrect=true) / count(isCorrect is true or false); unscored trials are excluded.';
  } else if (/rating|scale|slider|score|likert|numeric/i.test(query)) {
    text = summary.conditions.some(c => c.meanNumericResponse !== null)
      ? `Mean numeric responses for rating and slider items (descriptive only):\n${summary.conditions.map(c => `${c.condition}: ${c.meanNumericResponse === null ? 'no numeric ratings' : c.meanNumericResponse.toFixed(2)} (${c.trials} trials)`).join('\n')}`
      : 'No numeric rating or slider responses were recorded in this dataset.';
    formula = 'arithmetic mean of recorded numeric responseValue entries for rating_scale and slider trials, grouped by condition.';
  } else if (/reaction|\brt\b|latency|speed|fast|slow|\btime\b/i.test(query)) {
    text = summary.conditions.some(c => c.meanRtMs !== null)
      ? `Reaction-time summaries (descriptive only):\n${summary.conditions.map(c => `${c.condition}: ${c.meanRtMs === null ? 'no reaction-time values' : `mean ${c.meanRtMs.toFixed(1)} ms, median ${c.medianRtMs?.toFixed(1)} ms`} (${c.trials} trials)`).join('\n')}`
      : 'This dataset contains no reaction-time measurements. It appears to use non-speeded responses, so RT comparisons do not apply.';
    formula = 'mean and median over non-null, finite reactionTimeMs values within each condition; no significance test is run.';
  } else if (/distribution|which response|most common|popular|choice|answer|response/i.test(query)) {
    text = summary.conditions.map(c => {
      const responses = c.responseCounts.length ? c.responseCounts.map(r => `${r.response}: ${r.count} (${percent(r.count, c.trials)})`).join(', ') : 'no response values recorded';
      return `${c.condition} (n=${c.trials}): ${responses}`;
    }).join('\n');
    formula = 'count and percentage of each responseValue (or legacy responseKey when responseValue is absent) within condition; percentages use all trials in that condition.';
  } else {
    text = `Descriptive overview for ${summary.trialCount} recorded trials across ${summary.sessionCount} sessions. Response types: ${summary.responseTypes.join(', ') || 'not recorded'}. Missing or timed-out responses: ${summary.missingResponses}.\n${conditionLines.join('\n')}\n\nAsk about response distributions, accuracy, uncertainty, ratings, or reaction time. Inferential tests and clinical interpretations are not generated by this local summary tool.`;
    formula = 'Counts, grouped descriptive means/medians, uncertainty counts, and scored accuracy from recorded rows only.';
  }

  return {
    text,
    formula,
    sample: `${summary.sessionCount} sessions; ${summary.trialCount} trials; ${summary.conditions.length} conditions`,
  };
}

export function buildExploratoryReport(title: string, trials: TrialRecord[]): string {
  if (!trials.length) return `EXPLORATORY DATA SUMMARY: ${title}\n\nNo participant response records are available yet. Run the study or import data to generate a report.`;
  const summary = summarizeDataset(trials);
  const lines = summary.conditions.map(c => {
    const parts = [`n=${c.trials}`, `${c.sessions} sessions`];
    if (c.meanNumericResponse !== null) parts.push(`mean rating=${c.meanNumericResponse.toFixed(2)}`);
    if (c.meanRtMs !== null) parts.push(`mean RT=${c.meanRtMs.toFixed(1)} ms; median=${c.medianRtMs?.toFixed(1)} ms`);
    if (c.accuracyPercent !== null) parts.push(`accuracy=${c.accuracyPercent.toFixed(1)}%`);
    parts.push(`uncertain=${c.uncertaintyCount}`);
    return `${c.condition}: ${parts.join('; ')}`;
  });
  return [
    `EXPLORATORY DATA SUMMARY: ${title}`,
    `Sessions: ${summary.sessionCount}`,
    `Trials: ${summary.trialCount}`,
    `Response types: ${summary.responseTypes.join(', ') || 'not recorded'}`,
    `Missing or timed-out responses: ${summary.missingResponses}`,
    '',
    ...lines,
    '',
    'These are descriptive summaries of the selected records. This report does not run significance tests or infer causes.'
  ].join('\n');
}
