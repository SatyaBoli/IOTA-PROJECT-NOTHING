import { TrialRecord } from '../types/dsl';

export type QualityFlagType = 
  | 'fast_guess' 
  | 'deadline_timeout' 
  | 'motor_perseveration' 
  | 'frame_jitter_spike' 
  | 'window_blur';

export interface QualityFilterOptions {
  excludeFastGuesses: boolean;
  minRtMs: number;
  excludeTimeouts: boolean;
  maxRtMs: number;
  excludePerseveration: boolean;
  excludeFrameJitter: boolean;
  onlyCorrectTrialsForRt: boolean;
}

export interface SessionQualityMetrics {
  sessionId: string;
  totalTrials: number;
  validTrials: number;
  fastGuessesCount: number;
  timeoutsCount: number;
  perseverationDetected: boolean;
  meanFrameJitterMs: number;
  healthScorePercent: number;
  isUsable: boolean;
}

export interface CohortHealthSummary {
  totalSessions: number;
  totalTrialsRecorded: number;
  cleanTrialsCount: number;
  retentionRatePercent: number;
  overallHealthScore: number;
  flagBreakdown: {
    fastGuesses: number;
    timeouts: number;
    perseverations: number;
    frameJitterSpikes: number;
  };
  alerts: string[];
}

export const defaultQualityOptions: QualityFilterOptions = {
  excludeFastGuesses: true,
  minRtMs: 150,
  excludeTimeouts: true,
  maxRtMs: 2000,
  excludePerseveration: true,
  excludeFrameJitter: true,
  onlyCorrectTrialsForRt: true
};

export class QualityEngine {
  /**
   * Evaluates and tags a single trial record without mutating raw data
   */
  public static diagnoseTrial(
    trial: TrialRecord,
    deadlineMs: number = 2000,
    minRtMs: number = 150
  ): QualityFlagType[] {
    const flags: QualityFlagType[] = [...(trial.qualityFlags as QualityFlagType[] || [])];

    // 1. Fast guess heuristic (< 150ms)
    if (trial.reactionTimeMs !== null && trial.reactionTimeMs < minRtMs && !flags.includes('fast_guess')) {
      flags.push('fast_guess');
    }

    // 2. Deadline timeout heuristic
    if ((trial.reactionTimeMs === null || trial.reactionTimeMs >= deadlineMs) && !flags.includes('deadline_timeout')) {
      flags.push('deadline_timeout');
    }

    // 3. Frame jitter spike heuristic (> 3ms lag)
    if (trial.displayLagMs > 3.0 && !flags.includes('frame_jitter_spike')) {
      flags.push('frame_jitter_spike');
    }

    return flags;
  }

  /**
   * Detects motor perseveration within a session (e.g. participant hitting same key 6+ times in a row)
   */
  public static detectPerseveration(trials: TrialRecord[], consecutiveThreshold: number = 6): Set<string> {
    const perseverationTrialIds = new Set<string>();
    let currentKey: string | null = null;
    let consecutiveStreak = 0;
    const streakTrialIds: string[] = [];

    for (const t of trials) {
      if (t.responseKey && t.responseKey === currentKey) {
        consecutiveStreak++;
        streakTrialIds.push(t.id);
        if (consecutiveStreak >= consecutiveThreshold) {
          streakTrialIds.forEach(id => perseverationTrialIds.add(id));
        }
      } else {
        currentKey = t.responseKey;
        consecutiveStreak = 1;
        streakTrialIds.length = 0;
        if (t.responseKey) streakTrialIds.push(t.id);
      }
    }

    return perseverationTrialIds;
  }

  /**
   * Applies non-destructive researcher filter settings to produce an analysis-ready dataset
   */
  public static filterTrials(
    trials: TrialRecord[],
    options: QualityFilterOptions = defaultQualityOptions
  ): { cleanTrials: TrialRecord[]; excludedTrials: TrialRecord[]; exclusionReasons: Record<string, number> } {
    const cleanTrials: TrialRecord[] = [];
    const excludedTrials: TrialRecord[] = [];
    const exclusionReasons: Record<string, number> = {
      fast_guess: 0,
      timeout: 0,
      perseveration: 0,
      incorrect_rt: 0,
      frame_jitter: 0
    };

    const perseverationIds = options.excludePerseveration 
      ? this.detectPerseveration(trials) 
      : new Set<string>();

    for (const t of trials) {
      let exclude = false;
      const isTimedResponse = t.responseType ? t.responseType === 'keyboard_reaction' : true;

      // 1. Fast guess check
      if (options.excludeFastGuesses && t.reactionTimeMs !== null && t.reactionTimeMs < options.minRtMs) {
        exclude = true;
        exclusionReasons.fast_guess++;
      }

      // 2. Timeout check
      if (!exclude && options.excludeTimeouts && isTimedResponse && (t.reactionTimeMs === null || t.reactionTimeMs > options.maxRtMs)) {
        exclude = true;
        exclusionReasons.timeout++;
      }

      // 3. Incorrect trial exclusion for chronometric RT analysis
      if (!exclude && options.onlyCorrectTrialsForRt && t.isCorrect === false) {
        exclude = true;
        exclusionReasons.incorrect_rt++;
      }

      // 4. Motor perseveration
      if (!exclude && perseverationIds.has(t.id)) {
        exclude = true;
        exclusionReasons.perseveration++;
      }

      // 5. Frame jitter spike
      if (!exclude && options.excludeFrameJitter && t.displayLagMs > 3.0) {
        exclude = true;
        exclusionReasons.frame_jitter++;
      }

      if (exclude) {
        excludedTrials.push(t);
      } else {
        cleanTrials.push(t);
      }
    }

    return { cleanTrials, excludedTrials, exclusionReasons };
  }

  /**
   * Evaluates quality metrics for an individual session
   */
  public static evaluateSessionQuality(trials: TrialRecord[]): SessionQualityMetrics {
    const total = trials.length;
    if (total === 0) {
      return {
        sessionId: 'unknown',
        totalTrials: 0,
        validTrials: 0,
        fastGuessesCount: 0,
        timeoutsCount: 0,
        perseverationDetected: false,
        meanFrameJitterMs: 0,
        healthScorePercent: 100,
        isUsable: true
      };
    }

    const sessionId = trials[0].sessionId;
    const timedTrials = trials.filter(t => !t.responseType || t.responseType === 'keyboard_reaction');
    const fastGuesses = timedTrials.filter(t => t.reactionTimeMs !== null && t.reactionTimeMs < 150).length;
    const timeouts = timedTrials.filter(t => t.reactionTimeMs === null || t.reactionTimeMs > 2000).length;
    const perseverationIds = this.detectPerseveration(trials);
    const meanJitter = trials.reduce((sum, t) => sum + (t.displayLagMs || 0), 0) / total;

    const invalidTimingIds = new Set(timedTrials.filter(t => (t.reactionTimeMs !== null && t.reactionTimeMs < 150) || t.reactionTimeMs === null || t.reactionTimeMs > 2000).map(t => t.id));
    const penalty = (fastGuesses * 5) + (timeouts * 10) + (perseverationIds.size * 5) + (meanJitter > 2.0 ? 20 : 0);
    const healthScore = Math.max(0, Math.min(100, Math.round(100 - (penalty / total) * 100)));

    return {
      sessionId,
      totalTrials: total,
      validTrials: total - invalidTimingIds.size,
      fastGuessesCount: fastGuesses,
      timeoutsCount: timeouts,
      perseverationDetected: perseverationIds.size > 0,
      meanFrameJitterMs: Math.round(meanJitter * 100) / 100,
      healthScorePercent: healthScore,
      isUsable: healthScore >= 70
    };
  }

  /**
   * Generates a global cohort health summary across all recorded sessions
   */
  public static evaluateCohortHealth(allTrials: TrialRecord[]): CohortHealthSummary {
    const sessionMap = new Map<string, TrialRecord[]>();
    for (const t of allTrials) {
      const arr = sessionMap.get(t.sessionId) || [];
      arr.push(t);
      sessionMap.set(t.sessionId, arr);
    }

    const totalSessions = sessionMap.size;
    const totalTrials = allTrials.length;
    const { cleanTrials, exclusionReasons } = this.filterTrials(allTrials);

    const retentionRate = totalTrials > 0 ? Math.round((cleanTrials.length / totalTrials) * 1000) / 10 : 100;
    const alerts: string[] = [];

    if (exclusionReasons.fast_guess > totalTrials * 0.05) {
      alerts.push(`High rate of anticipatory fast guesses detected (${exclusionReasons.fast_guess} trials, >5%). Consider increasing fixation jitter.`);
    }

    if (exclusionReasons.timeout > totalTrials * 0.08) {
      alerts.push(`Elevated timeout rate (${exclusionReasons.timeout} trials, >8%). Consider increasing the response deadline window.`);
    }

    if (exclusionReasons.frame_jitter > totalTrials * 0.03) {
      alerts.push(`Display V-Sync jitter detected in ${exclusionReasons.frame_jitter} trials. Some participants may be using low-power browser modes.`);
    }

    if (totalSessions > 0 && alerts.length === 0) {
      alerts.push('Overall data quality is excellent. 95%+ of trials conform to high-precision behavioral research standards.');
    }

    return {
      totalSessions,
      totalTrialsRecorded: totalTrials,
      cleanTrialsCount: cleanTrials.length,
      retentionRatePercent: retentionRate,
      overallHealthScore: Math.min(100, Math.round(retentionRate)),
      flagBreakdown: {
        fastGuesses: exclusionReasons.fast_guess,
        timeouts: exclusionReasons.timeout,
        perseverations: exclusionReasons.perseveration,
        frameJitterSpikes: exclusionReasons.frame_jitter
      },
      alerts
    };
  }
}
