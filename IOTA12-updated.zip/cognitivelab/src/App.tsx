import React, { useState, useMemo } from 'react';
import { Navbar, WorkspaceRole, TabId } from './components/Navbar';
import { NodeCanvas } from './components/builder/NodeCanvas';
import { NodeInspector } from './components/builder/NodeInspector';
import { AiDesignerModal } from './components/ai/AiDesignerModal';
import { ParticipantRunner } from './components/runner/ParticipantRunner';
import { ExperimentDebugger } from './components/debugger/ExperimentDebugger';
import { AnalyticsDashboard } from './components/analytics/AnalyticsDashboard';
import { AiDataAnalyst } from './components/analytics/AiDataAnalyst';
import { ParticipantDashboard } from './components/participant/ParticipantDashboard';
import { ResearcherCommandCenter } from './components/researcher/ResearcherCommandCenter';
import { LiveMonitoring } from './components/telemetry/LiveMonitoring';
import { ExportHub } from './components/export/ExportHub';
import { CodeInspector } from './components/code/CodeInspector';
import { defaultExperimentDSL } from './dsl/defaultExperiment';
import { ExperimentValidator } from './dsl/validator';
import { ExperimentDSL, DSLNode, DSLEdge } from './types/dsl';
import { ExperimentStore } from './runtime/experimentStore';

export const App: React.FC = () => {
  const [currentRole, setCurrentRole] = useState<WorkspaceRole>('researcher');
  const [activeTab, setActiveTab] = useState<TabId>('command-center');
  const [dsl, setDslState] = useState<ExperimentDSL>(() => {
    const activeId = ExperimentStore.getActiveExperimentId();
    return ExperimentStore.getExperiment(activeId);
  });
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

  // Synchronize state with persistent ExperimentStore
  const setDsl: React.Dispatch<React.SetStateAction<ExperimentDSL>> = (updater) => {
    setDslState(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      ExperimentStore.saveExperiment(next);
      return next;
    });
  };

  React.useEffect(() => {
    const handleActiveChanged = () => {
      const activeId = ExperimentStore.getActiveExperimentId();
      const loaded = ExperimentStore.getExperiment(activeId);
      setDslState(loaded);
    };
    window.addEventListener('cognitivelab_active_experiment_changed', handleActiveChanged);
    return () => window.removeEventListener('cognitivelab_active_experiment_changed', handleActiveChanged);
  }, []);

  // Run two-tier validation on DSL
  const validationResult = useMemo(() => {
    return ExperimentValidator.validate(dsl);
  }, [dsl]);

  // Selected node reference
  const selectedNode = useMemo(() => {
    return dsl.nodes.find((n) => n.id === selectedNodeId) || null;
  }, [dsl.nodes, selectedNodeId]);

  // Update node position
  const handleUpdateNodePosition = (id: string, x: number, y: number) => {
    setDsl((prev) => ({
      ...prev,
      nodes: prev.nodes.map((n) => (n.id === id ? { ...n, position: { x, y } } : n)),
    }));
  };

  // Update node configuration
  const handleUpdateNodeConfig = (nodeId: string, newConfig: Record<string, any>) => {
    setDsl((prev) => ({
      ...prev,
      nodes: prev.nodes.map((n) => (n.id === nodeId ? { ...n, config: newConfig } : n)),
    }));
  };

  // Update node label
  const handleUpdateNodeLabel = (nodeId: string, newLabel: string) => {
    setDsl((prev) => ({
      ...prev,
      nodes: prev.nodes.map((n) => (n.id === nodeId ? { ...n, label: newLabel } : n)),
    }));
  };

  // Add new node from palette
  const handleAddNode = (newNode: DSLNode) => {
    setDsl((prev) => ({
      ...prev,
      nodes: [...prev.nodes, newNode],
    }));
    setSelectedNodeId(newNode.id);
  };

  // Delete node and remove all attached edges
  const handleDeleteNode = (nodeId: string) => {
    setDsl((prev) => ({
      ...prev,
      nodes: prev.nodes.filter((n) => n.id !== nodeId),
      edges: prev.edges.filter((e) => e.from !== nodeId && e.to !== nodeId),
    }));
    if (selectedNodeId === nodeId) {
      setSelectedNodeId(null);
    }
  };

  // Add edge between two nodes
  const handleAddEdge = (from: string, to: string) => {
    const exists = dsl.edges.some((e) => e.from === from && e.to === to);
    if (exists) return;

    const newEdge: DSLEdge = {
      id: `e_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      from,
      to,
    };

    setDsl((prev) => ({
      ...prev,
      edges: [...prev.edges, newEdge],
    }));
  };

  // Delete edge
  const handleDeleteEdge = (edgeId: string) => {
    setDsl((prev) => ({
      ...prev,
      edges: prev.edges.filter((e) => e.id !== edgeId),
    }));
  };

  // Auto-arrange layout
  const handleAutoLayout = () => {
    const nodeOrder = [...dsl.nodes];
    const arrangedNodes = nodeOrder.map((node, index) => {
      let yPos = 200;
      if (node.id.includes('correct')) yPos = 100;
      if (node.id.includes('wrong') || node.id.includes('incorrect')) yPos = 280;
      if (node.id.includes('debrief') || node.id.includes('end')) yPos = 360;

      return {
        ...node,
        position: {
          x: 60 + index * 190,
          y: yPos,
        },
      };
    });

    setDsl((prev) => ({
      ...prev,
      nodes: arrangedNodes,
    }));
  };

  return (
    <div className="min-h-screen bg-[#070a13] flex flex-col overflow-hidden text-slate-100">
      {/* Navigation Header */}
      <Navbar
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        dsl={dsl}
        setDsl={setDsl}
        validationIssues={validationResult.issues}
        isValid={validationResult.isValid}
      />

      {/* Main View Area */}
      <main className="flex-1 relative flex overflow-hidden">
        {/* PARTICIPANT VIEWS */}
        {activeTab === 'participant-dashboard' && (
          <div className="flex-1 overflow-y-auto">
            <ParticipantDashboard
              currentDsl={dsl}
              onLaunchExperiment={(chosenDsl) => {
                setDsl(chosenDsl);
                setActiveTab('runner');
              }}
              onSwitchToResearcher={() => {
                setCurrentRole('researcher');
                setActiveTab('command-center');
              }}
            />
          </div>
        )}

        {/* RESEARCHER COMMAND CENTER */}
        {activeTab === 'command-center' && (
          <div className="flex-1 overflow-y-auto">
            <ResearcherCommandCenter
              currentDsl={dsl}
              onSelectExperiment={(selectedDsl, targetTab) => {
                setDsl(selectedDsl);
                setActiveTab((targetTab as TabId) || 'builder');
              }}
              onNewExperiment={() => setActiveTab('ai')}
              onSwitchToParticipant={() => {
                setCurrentRole('participant');
                setActiveTab('participant-dashboard');
              }}
            />
          </div>
        )}

        {/* VISUAL BLUEPRINT BUILDER */}
        {activeTab === 'builder' && (
          <div className="flex-1 flex overflow-hidden">
            <div className="flex-1 relative">
              <NodeCanvas
                nodes={dsl.nodes}
                edges={dsl.edges}
                selectedNodeId={selectedNodeId}
                onSelectNode={setSelectedNodeId}
                onUpdateNodePosition={handleUpdateNodePosition}
                onAddNode={handleAddNode}
                onAddEdge={handleAddEdge}
                onDeleteEdge={handleDeleteEdge}
                onDeleteNode={handleDeleteNode}
                onUpdateNodeLabel={handleUpdateNodeLabel}
                onAutoLayout={handleAutoLayout}
                validationIssues={validationResult.issues}
              />
            </div>
            {selectedNode && (
              <NodeInspector
                node={selectedNode}
                onClose={() => setSelectedNodeId(null)}
                onUpdateConfig={handleUpdateNodeConfig}
                onUpdateLabel={handleUpdateNodeLabel}
                onDeleteNode={handleDeleteNode}
                validationIssues={validationResult.issues}
              />
            )}
          </div>
        )}

        {/* AI EXPERIMENT DESIGNER */}
        {activeTab === 'ai' && (
          <div className="flex-1 overflow-y-auto">
            <AiDesignerModal
              dsl={dsl}
              onApplyDsl={setDsl}
              onNavigateToBuilder={() => setActiveTab('builder')}
              onLaunchParticipant={(newDsl) => {
                setDsl(newDsl);
                setCurrentRole('participant');
                setActiveTab('runner');
              }}
            />
          </div>
        )}

        {/* PARTICIPANT EXPERIMENT RUNNER */}
        {activeTab === 'runner' && (
          <div className="flex-1 overflow-hidden">
            <ParticipantRunner
              dsl={dsl}
              onSessionComplete={() => {
                if (currentRole === 'participant') {
                  setActiveTab('participant-dashboard');
                } else {
                  setActiveTab('analytics');
                }
              }}
            />
          </div>
        )}

        {/* SIMULATION STEP DEBUGGER */}
        {activeTab === 'debugger' && (
          <div className="flex-1 overflow-y-auto">
            <ExperimentDebugger
              dsl={dsl}
              onNavigateToAnalytics={() => setActiveTab('analytics')}
            />
          </div>
        )}

        {/* LIVE WEBSOCKET TELEMETRY */}
        {activeTab === 'telemetry' && (
          <div className="flex-1 overflow-y-auto">
            <LiveMonitoring
              dsl={dsl}
              onNavigateToAnalytics={() => setActiveTab('analytics')}
            />
          </div>
        )}

        {/* BEHAVIORAL ANALYTICS DASHBOARD */}
        {activeTab === 'analytics' && (
          <div className="flex-1 overflow-y-auto">
            <AnalyticsDashboard
              dsl={dsl}
              onNavigateToAiAnalyst={() => setActiveTab('ai-analyst')}
            />
          </div>
        )}

        {/* ANTI-HALLUCINATION AI DATA ANALYST */}
        {activeTab === 'ai-analyst' && (
          <div className="flex-1 overflow-y-auto">
            <AiDataAnalyst dsl={dsl} />
          </div>
        )}

        {/* DATASET EXPLORER & R/PYTHON REPLICATION HUB */}
        {activeTab === 'exports' && (
          <div className="flex-1 overflow-y-auto">
            <ExportHub dsl={dsl} />
          </div>
        )}

        {/* DSL JSON CODE INSPECTOR */}
        {activeTab === 'code' && (
          <div className="flex-1 overflow-y-auto">
            <CodeInspector
              dsl={dsl}
              onUpdateDsl={setDsl}
              validationIssues={validationResult.issues}
              isValid={validationResult.isValid}
            />
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
