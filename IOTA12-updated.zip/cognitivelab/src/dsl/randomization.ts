export class Mulberry32 {
  private state: number;

  constructor(seed: number) {
    this.state = seed >>> 0;
  }

  public next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  public nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  public shuffle<T>(array: T[]): T[] {
    const copy = [...array];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }
}

export interface FactorLevel {
  value: string;
  weight?: number;
  metadata?: Record<string, any>;
}

export interface Factor {
  name: string;
  levels: FactorLevel[];
}

export interface BalancedTrialItem {
  condition: string;
  stimulusType: 'color_circle' | 'color_square' | 'text' | 'word_ink' | 'spatial_grid';
  stimulusValue: string;
  stimulusText?: string;
  hexColor?: string;
  expectedKey: string;
  factorState: Record<string, any>;
  gridRow?: number;
  gridCol?: number;
}

export class FactorialEngine {
  /**
   * Generates a fully balanced factorial design across N factors with run-length constraints
   */
  public static generateBalancedBlock(
    config: {
      factors?: Factor[];
      repetitions_per_level?: number;
      total_trials?: number;
      max_consecutive_identical?: number;
    },
    prng: Mulberry32
  ): BalancedTrialItem[] {
    const factors = config.factors && config.factors.length > 0 ? config.factors : [
      {
        name: "color",
        levels: [
          { value: "red", weight: 1, metadata: { hex: "#ef4444", expected_key: "a", type: "color_circle" } },
          { value: "blue", weight: 1, metadata: { hex: "#3b82f6", expected_key: "l", type: "color_circle" } }
        ]
      }
    ];

    // Compute Cartesian product across all factors
    let combinations: Record<string, FactorLevel>[] = [{}];
    for (const factor of factors) {
      const nextCombos: Record<string, FactorLevel>[] = [];
      for (const existing of combinations) {
        for (const level of factor.levels) {
          nextCombos.push({
            ...existing,
            [factor.name]: level,
          });
        }
      }
      combinations = nextCombos;
    }

    const cellCount = Math.max(combinations.length, 1);
    const targetTotal = config.total_trials || 30;
    const reps = config.repetitions_per_level || Math.max(Math.floor(targetTotal / cellCount), 1);

    const rawPool: BalancedTrialItem[] = [];

    // Factorial cell expansion
    for (const combo of combinations) {
      // Build a unified metadata state
      const combinedState: Record<string, any> = {};
      const conditionParts: string[] = [];

      let expectedKey = 'a';
      let hexColor = '#38bdf8';
      let stimulusType: BalancedTrialItem['stimulusType'] = 'color_circle';
      let stimulusText: string | undefined = undefined;
      let stimulusValue = '';
      let gridRow: number | undefined = undefined;
      let gridCol: number | undefined = undefined;

      Object.entries(combo).forEach(([fName, lvl]) => {
        conditionParts.push(`${lvl.value}`);
        Object.assign(combinedState, lvl.metadata);
        if (lvl.metadata?.expected_key) expectedKey = String(lvl.metadata.expected_key).toLowerCase();
        if (lvl.metadata?.hex) hexColor = lvl.metadata.hex;
        if (lvl.metadata?.type) stimulusType = lvl.metadata.type;
        if (lvl.metadata?.text) stimulusText = lvl.metadata.text;
        if (lvl.metadata?.gridRow !== undefined) gridRow = lvl.metadata.gridRow;
        if (lvl.metadata?.gridCol !== undefined) gridCol = lvl.metadata.gridCol;
        stimulusValue = lvl.value;
      });

      const conditionName = conditionParts.join('_');

      for (let r = 0; r < reps; r++) {
        rawPool.push({
          condition: conditionName,
          stimulusType,
          stimulusValue,
          stimulusText,
          hexColor,
          expectedKey,
          factorState: combinedState,
          gridRow,
          gridCol,
        });
      }
    }

    // Seeded shuffle with run-length constraint checks
    let shuffled = prng.shuffle(rawPool);
    const maxConsecutive = config.max_consecutive_identical || 3;

    let attempts = 0;
    while (attempts < 25 && this.hasExcessiveRuns(shuffled, maxConsecutive)) {
      shuffled = prng.shuffle(rawPool);
      attempts++;
    }

    return shuffled;
  }

  private static hasExcessiveRuns(items: BalancedTrialItem[], maxRun: number): boolean {
    if (items.length <= maxRun) return false;
    let currentRun = 1;
    for (let i = 1; i < items.length; i++) {
      if (items[i].condition === items[i - 1].condition) {
        currentRun++;
        if (currentRun > maxRun) return true;
      } else {
        currentRun = 1;
      }
    }
    return false;
  }
}
