import { ExperimentDSL } from '../types/dsl';

export const defaultExperimentDSL: ExperimentDSL = {
  $schema: "https://cognitivelab.io/schemas/v1/experiment.json",
  experiment: {
    id: "exp_stroop_space_001",
    slug: "space-color-reaction",
    version: 1,
    title: "Space Orbit Color Discrimination Task",
    description: "Balanced two-alternative forced choice (2AFC) measuring reaction time and accuracy to chromatic stimuli under gamified space presentation.",
    created_at: new Date().toISOString(),
    author: {
      user_id: "usr_researcher_demo",
      institution: "Laboratory for Cognitive & Behavioral Science"
    },
    reproducibility: {
      dsl_version: "1.0.0",
      target_runtime: "jspsych-7.3.4",
      hash_sha256: "4b9f2c8d1e3a7f05b6d8c9e0a2f1b3d5e7c9a1b3f5d7e9c1a3b5d7f9e1c3a5b7"
    }
  },
  participant_settings: {
    allow_anonymous: true,
    enforce_fullscreen: true,
    minimum_display_hz: 58,
    device_allowlist: ["desktop", "laptop"],
    required_inputs: ["keyboard"]
  },
  consent_settings: {
    required: true,
    ethics_protocol_id: "IRB-2026-COG-044",
    statement_text: "You are invited to participate in a study on visual processing speed. Your participation is completely voluntary, anonymous, and no personally identifying information (PII) is captured. You may withdraw at any time by closing your browser window.",
    require_checkbox: true,
    minimum_age: 18
  },
  variables: {
    total_score: { type: "number", default: 0, scope: "global" },
    streak_count: { type: "number", default: 0, scope: "global" },
    current_stimulus_color: { type: "string", default: "", scope: "trial" },
    expected_key: { type: "string", default: "", scope: "trial" },
    trial_accuracy: { type: "boolean", default: false, scope: "trial" }
  },
  game_skin: {
    enabled: true,
    theme: "deep-space-arcade",
    sound_enabled: true,
    hud_elements: {
      show_score: true,
      show_streak: true,
      show_progress_bar: true
    },
    score_rules: {
      correct_base_points: 100,
      streak_bonus_multiplier: 1.25,
      incorrect_penalty: 0,
      max_rt_for_bonus_ms: 450
    }
  },
  nodes: [
    {
      id: "node_start",
      type: "flow_start",
      label: "Experiment Entry",
      config: {},
      position: { x: 50, y: 220 }
    },
    {
      id: "node_consent",
      type: "presentation_text",
      label: "IRB Informed Consent",
      config: {
        title: "Informed Consent & Ethics Briefing",
        content_markdown: "### Cognitive Reaction Experiment\n\nThis study measures rapid visual decision-making speed. Participation is strictly anonymous.",
        continue_button_text: "I Consent & Agree"
      },
      position: { x: 240, y: 220 }
    },
    {
      id: "node_calibration",
      type: "timing_calibration",
      label: "Display & Refresh Calibration",
      config: {
        measure_fps_frames: 120,
        reject_frame_jitter_ms: 8.0,
        prompt_keyboard_test: true
      },
      position: { x: 440, y: 220 }
    },
    {
      id: "node_instruction",
      type: "presentation_text",
      label: "Mission Briefing",
      config: {
        title: "Pilot Briefing: Deep Space Drone Scan",
        content_markdown: "Target signals will appear in your optical scanner.\n\n* When you detect a **RED** drone, press **A**\n* When you detect a **BLUE** drone, press **L**\n\nRespond as quickly and accurately as possible.",
        continue_button_text: "Initiate Scan (Begin)"
      },
      position: { x: 650, y: 220 }
    },
    {
      id: "node_trial_generator",
      type: "randomization_balanced_block",
      label: "Factorial Balanced Block",
      config: {
        factors: [
          {
            name: "color",
            levels: [
              { value: "red", weight: 1, metadata: { hex: "#ef4444", expected_key: "a" } },
              { value: "blue", weight: 1, metadata: { hex: "#3b82f6", expected_key: "l" } }
            ]
          }
        ],
        repetitions_per_level: 15,
        total_trials: 30,
        max_consecutive_identical: 3,
        prng_algorithm: "mulberry32",
        seed_strategy: "participant_session_seeded"
      },
      position: { x: 860, y: 220 }
    },
    {
      id: "node_loop_trials",
      type: "logic_loop",
      label: "Execute 30 Trials",
      config: {
        iterator_source: "node_trial_generator",
        max_iterations: 30
      },
      position: { x: 1080, y: 220 }
    },
    {
      id: "node_fixation",
      type: "presentation_fixation",
      label: "Fixation Crosshair",
      config: {
        shape: "cross",
        color: "#94a3b8",
        size_px: 36,
        duration_ms: 500,
        jitter_ms: 150
      },
      position: { x: 1280, y: 120 }
    },
    {
      id: "node_stimulus_display",
      type: "presentation_stimulus",
      label: "Chromatic Drone Stimulus",
      config: {
        stimulus_type: "dynamic_color_circle",
        diameter_px: 130,
        duration_max_ms: 1500
      },
      position: { x: 1480, y: 120 }
    },
    {
      id: "node_keyboard_response",
      type: "response_keyboard",
      label: "2AFC Keystroke Capture",
      config: {
        allowed_keys: ["a", "l"],
        deadline_ms: 1500,
        record_rt: true
      },
      position: { x: 1680, y: 120 }
    },
    {
      id: "node_evaluate_response",
      type: "logic_condition",
      label: "Accuracy Evaluator",
      config: {
        condition_expression: "response.key === variables.expected_key",
        output_variable: "trial_accuracy"
      },
      position: { x: 1880, y: 120 }
    },
    {
      id: "node_score_correct",
      type: "game_reward",
      label: "Add Score (+100) & Streak",
      config: {
        points: 100,
        streak_delta: 1,
        feedback_text: "+100! WARP DRIVE HIT",
        color: "#22c55e"
      },
      position: { x: 2100, y: 60 }
    },
    {
      id: "node_score_wrong",
      type: "game_reward",
      label: "Missed Target Feedback",
      config: {
        points: 0,
        streak_delta: 0,
        feedback_text: "DEFLECTED",
        color: "#ef4444"
      },
      position: { x: 2100, y: 200 }
    },
    {
      id: "node_record_trial_data",
      type: "data_record_trial",
      label: "Log Trial Telemetry",
      config: {
        persist_to_indexeddb: true,
        stream_batch_size: 5
      },
      position: { x: 2320, y: 130 }
    },
    {
      id: "node_iti",
      type: "timing_wait",
      label: "Inter-Trial Interval (ITI)",
      config: {
        duration_ms: 350
      },
      position: { x: 2520, y: 130 }
    },
    {
      id: "node_debrief",
      type: "presentation_text",
      label: "Mission Accomplished",
      config: {
        title: "Mission Debriefing",
        content_markdown: "Thank you for completing this empirical session!\n\nYour data has been anonymously committed and encrypted for cognitive science analysis.",
        continue_button_text: "Return to Base"
      },
      position: { x: 1280, y: 350 }
    },
    {
      id: "node_end",
      type: "flow_end",
      label: "Experiment Terminate",
      config: {},
      position: { x: 1480, y: 350 }
    }
  ],
  edges: [
    { id: "e1", from: "node_start", to: "node_consent" },
    { id: "e2", from: "node_consent", to: "node_calibration" },
    { id: "e3", from: "node_calibration", to: "node_instruction" },
    { id: "e4", from: "node_instruction", to: "node_trial_generator" },
    { id: "e5", from: "node_trial_generator", to: "node_loop_trials" },
    { id: "e6", from: "node_loop_trials", to: "node_fixation", port: "loop_body", label: "Each Trial" },
    { id: "e7", from: "node_fixation", to: "node_stimulus_display" },
    { id: "e8", from: "node_stimulus_display", to: "node_keyboard_response" },
    { id: "e9", from: "node_keyboard_response", to: "node_evaluate_response" },
    { id: "e10", from: "node_evaluate_response", to: "node_score_correct", port: "true", label: "Correct ('a' or 'l')" },
    { id: "e11", from: "node_evaluate_response", to: "node_score_wrong", port: "false", label: "Incorrect / Missed" },
    { id: "e12", from: "node_score_correct", to: "node_record_trial_data" },
    { id: "e13", from: "node_score_wrong", to: "node_record_trial_data" },
    { id: "e14", from: "node_record_trial_data", to: "node_iti" },
    { id: "e15", from: "node_iti", to: "node_loop_trials", port: "loop_next", label: "Next Trial" },
    { id: "e16", from: "node_loop_trials", to: "node_debrief", port: "complete", label: "All Trials Finished" },
    { id: "e17", from: "node_debrief", to: "node_end" }
  ]
};
