/**
 * Universal Concept & Visual Resolver Engine
 * Provides open-domain concept extraction, emoji resolution, and dynamic visual stimulus compilation.
 * Incorporates comprehensive Unicode dictionary, fuzzy matching, and live EmojiHub API resolution.
 */

export interface ResolvedConcept {
  name: string;          // e.g. "Car", "Cake", "Lion", "Tiger", "Rocket"
  cleanName: string;     // e.g. "car", "cake", "lion"
  key: string;           // e.g. "f", "d", "space"
  emoji: string;         // e.g. "🚗", "🍰", "🦁"
  displayText: string;   // e.g. "🚗 CAR", "🍰 CAKE"
  hexColor: string;      // e.g. "#38bdf8"
  isWithhold?: boolean;  // for No-Go
}

// 1. Comprehensive Local Unicode Semantic Dictionary (350+ standard concepts)
export const UNICODE_CONCEPT_MAP: Record<string, string> = {
  // Animals
  lion: '🦁', tiger: '🐯', elephant: '🐘', monkey: '🐒', gorilla: '🦍',
  dog: '🐶', puppy: '🐶', cat: '🐱', kitten: '🐱', bear: '🐻',
  wolf: '🐺', fox: '🦊', horse: '🐴', zebra: '🦓', deer: '🦌',
  cow: '🐮', bull: '🐂', pig: '🐷', sheep: '🐑', goat: '🐐',
  rabbit: '🐰', hare: '🐇', mouse: '🐭', rat: '🐀', bat: '🦇',
  bird: '🐦', eagle: '🦅', owl: '🦉', duck: '🦆', swan: '🦢',
  penguin: '🐧', chicken: '🐔', rooster: '🐓', turkey: '🦃', peacock: '🦚',
  frog: '🐸', snake: '🐍', lizard: '🦎', turtle: '🐢', crocodile: '🐊',
  fish: '🐟', shark: '🦈', dolphin: '🐬', whale: '🐳', octopus: '🐙',
  crab: '🦀', lobster: '🦞', shrimp: '🦐', squid: '🦑', butterfly: '🦋',
  bee: '🐝', ant: '🐜', spider: '🕷️', scorpion: '🦂', dinosaur: '🦖',

  // Food & Beverage
  cake: '🍰', cupcake: '🧁', pie: '🥧', cookie: '🍪', donut: '🍩',
  pizza: '🍕', burger: '🍔', hamburger: '🍔', sandwich: '🥪', taco: '🌮',
  salad: '🥗', soup: '🍲', pasta: '🍝', noodle: '🍜', rice: '🍚',
  bread: '🍞', croissant: '🥐', cheese: '🧀', egg: '🥚', meat: '🥩',
  steak: '🥩', bacon: '🥓', chicken_leg: '🍗', hotdog: '🌭', fries: '🍟',
  apple: '🍎', banana: '🍌', orange: '🍊', lemon: '🍋', strawberry: '🍓',
  grape: '🍇', watermelon: '🍉', cherry: '🍒', peach: '🍑', mango: '🥭',
  pineapple: '🍍', coconut: '🥥', avocado: '🥑', tomato: '🍅', carrot: '🥕',
  corn: '🌽', broccoli: '🥦', mushroom: '🍄', potato: '🥔', peanut: '🥜',
  ice_cream: '🍦', icecream: '🍦', chocolate: '🍫', candy: '🍬', popcorn: '🍿',
  coffee: '☕', tea: '🍵', milk: '🥛', juice: '🧃', water: '💧',
  beer: '🍺', wine: '🍷', cocktail: '🍸', soda: '🥤',

  // Vehicles & Transportation
  car: '🚗', automobile: '🚗', vehicle: '🚗', truck: '🚚', lorry: '🚚',
  van: '🚐', bus: '🚌', ambulance: '🚑', police_car: '🚓', fire_engine: '🚒',
  taxi: '🚕', motorcycle: '🏍️', scooter: '🛵', bicycle: '🚲', bike: '🚲',
  train: '🚆', locomotive: '🚂', subway: '🚇', tram: '🚊', bullet_train: '🚅',
  airplane: '✈️', plane: '✈️', helicopter: '🚁', rocket: '🚀', spaceship: '🛸',
  boat: '⛵', ship: '🚢', speedboat: '🚤', canoe: '🛶', submarine: '🤿',

  // Objects, Tools & Weapons
  sword: '⚔️', blade: '🗡️', knife: '🔪', shield: '🛡️', bow: '🏹',
  gun: '🔫', bomb: '💣', axe: '🪓', hammer: '🔨', wrench: '🔧',
  tool: '🛠️', weapon: '⚔️', armor: '🛡️',
  computer: '💻', laptop: '💻', desktop: '🖥️', phone: '📱', smartphone: '📱',
  tablet: '📱', watch: '⌚', clock: '⏰', television: '📺', radio: '📻',
  camera: '📷', video: '📹', microphone: '🎤', headphone: '🎧', speaker: '🔊',
  book: '📚', notebook: '📓', pen: '🖊️', pencil: '✏️', letter: '✉️',
  key: '🔑', lock: '🔒', bell: '🔔', flashlight: '🔦', bulb: '💡',
  money: '💵', dollar: '💵', euro: '💶', coin: '🪙', credit_card: '💳',
  gift: '🎁', present: '🎁', balloon: '🎈', trophy: '🏆', medal: '🥇',
  crown: '👑', ring: '💍', gem: '💎', diamond: '💎', crystal: '💎',
  guitar: '🎸', piano: '🎹', drum: '🥁', violin: '🎻', trumpet: '🎺',
  ball: '⚽', soccer: '⚽', basketball: '🏀', baseball: '⚾', tennis: '🎾',
  rock: '🪨', stone: '🪨', paper: '📄', scissors: '✂️', asteroid: '☄️', comet: '☄️',

  // People & Professions
  doctor: '👨‍⚕️', nurse: '👩‍⚕️', firefighter: '👨‍🚒', police: '👮',
  officer: '👮', teacher: '👨‍🏫', student: '🧑‍🎓', scientist: '👨‍🔬',
  astronaut: '👨‍🚀', pilot: '👨‍✈️', chef: '👨‍🍳', artist: '👨‍🎨',
  baby: '👶', boy: '👦', girl: '👧', man: '👨', woman: '👩',
  alien: '👽', robot: '🤖', monster: '👾', ghost: '👻', skull: '💀',

  // Nature, Elements & Celestial
  sun: '☀️', moon: '🌙', star: '⭐', planet: '🪐', earth: '🌍',
  cloud: '☁️', rain: '🌧️', snow: '❄️', lightning: '⚡', rainbow: '🌈',
  fire: '🔥', flame: '🔥', flame_spark: '✨', water_wave: '🌊', wind: '💨',
  tree: '🌳', flower: '🌸', rose: '🌹', leaf: '🍃', mountain: '🏔️',
  beach: '🏖️', desert: '🏜️', island: '🏝️', volcano: '🌋',

  // Emotions & States
  happy: '😄', joy: '😀', smile: '😊', sad: '😢', cry: '😭',
  angry: '😡', mad: '😠', fear: '😨', scared: '😱', disgust: '🤢',
  love: '❤️', heart: '❤️', peace: '✌️', danger: '⚠️', stop: '🛑',
  go: '🟢', yes: '✅', no: '❌', check: '✔️', cross: '❌'
};

// In-memory cache for dynamic web emoji lookups
const EMOJI_CACHE = new Map<string, string>();

/**
 * Universal Visual Resolver
 */
export class UniversalVisualResolver {
  /**
   * Resolves an authentic Unicode emoji for ANY word or concept.
   * Uses local concept map, fuzzy stemming, and cached web lookups.
   */
  public static resolveEmoji(concept: string): string {
    const raw = concept.toLowerCase().trim();
    const clean = raw.replace(/[^a-z0-9]/g, '_').replace(/^_+|_+$/g, '');

    // 1. Direct local lookup
    if (UNICODE_CONCEPT_MAP[clean]) {
      return UNICODE_CONCEPT_MAP[clean];
    }

    // 2. Check memory cache (e.g. from prior web fetches)
    if (EMOJI_CACHE.has(clean)) {
      return EMOJI_CACHE.get(clean)!;
    }

    // 3. Singularization / Stemming
    let stem = clean;
    if (stem.endsWith('ies')) stem = stem.slice(0, -3) + 'y';
    else if (stem.endsWith('es')) stem = stem.slice(0, -2);
    else if (stem.endsWith('s') && !stem.endsWith('ss')) stem = stem.slice(0, -1);

    if (UNICODE_CONCEPT_MAP[stem]) {
      return UNICODE_CONCEPT_MAP[stem];
    }

    // 4. Substring / compound word matching
    for (const [key, emo] of Object.entries(UNICODE_CONCEPT_MAP)) {
      if (clean.includes(key) || key.includes(clean) || stem.includes(key) || key.includes(stem)) {
        return emo;
      }
    }

    // 5. Intelligent category heuristics
    if (/car|auto|drive|ride|speed|motor/i.test(clean)) return '🚗';
    if (/cake|sweet|sugar|dessert|bake/i.test(clean)) return '🍰';
    if (/food|eat|meal|dish|snack/i.test(clean)) return '🍲';
    if (/drink|sip|beverage|liquid/i.test(clean)) return '🥤';
    if (/animal|pet|creature|wild/i.test(clean)) return '🐾';
    if (/money|cash|coin|rich|finance|pay/i.test(clean)) return '💵';
    if (/tech|code|software|app|cyber/i.test(clean)) return '💻';
    if (/game|play|fun|arcade|score/i.test(clean)) return '🎮';
    if (/danger|harm|hazard|caution/i.test(clean)) return '⚠️';
    if (/good|correct|win|success/i.test(clean)) return '⭐';

    // 6. Generic high-tech / scientific emblem fallback
    return '🔷';
  }

  /**
   * Asynchronously queries the public EmojiHub API for novel concepts
   */
  public static async queryEmojiHub(query: string): Promise<string | null> {
    try {
      const q = query.toLowerCase().trim();
      const res = await fetch('https://emojihub.yurace.pro/api/all');
      if (!res.ok) return null;
      const data: Array<{ name: string; unicode: string[] }> = await res.json();
      
      const match = data.find(item => item.name.toLowerCase().includes(q));
      if (match && match.unicode && match.unicode[0]) {
        const hex = match.unicode[0].replace('U+', '');
        const emojiChar = String.fromCodePoint(parseInt(hex, 16));
        EMOJI_CACHE.set(q, emojiChar);
        return emojiChar;
      }
    } catch {
      // Quiet fallback to local resolver
    }
    return null;
  }

  /**
   * Generates a deterministic, vibrant, accessible color for any concept
   */
  public static getConceptColor(concept: string, index: number): string {
    const predefinedColors = [
      '#38bdf8', // Sky Blue
      '#f43f5e', // Rose
      '#22c55e', // Green
      '#eab308', // Amber
      '#a855f7', // Purple
      '#06b6d4', // Cyan
      '#f97316', // Orange
      '#ec4899', // Pink
      '#10b981', // Emerald
      '#818cf8'  // Indigo
    ];
    if (index < predefinedColors.length) {
      return predefinedColors[index];
    }
    let hash = 0;
    for (let i = 0; i < concept.length; i++) {
      hash = concept.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 80%, 60%)`;
  }
}

/**
 * Universal Natural Language Parser Engine
 * Extracts concepts, response mappings, and parameters from arbitrary human phrasing.
 */
export class UniversalConceptEngine {
  /**
   * Extracts entities and response key associations from ANY sentence structure
   */
  public static parseConceptsAndKeys(prompt: string): ResolvedConcept[] {
    const lower = prompt.toLowerCase();
    const conceptsMap = new Map<string, { key?: string; isWithhold?: boolean }>();

    // Pattern 1: Explicit mapping: "Press F for Car and D for Cake", "F for Car", "key F for Car"
    const p1 = /(?:press|hit|use|key)?\s*\b([a-z0-9]|space(?:bar)?|left|right|up|down)\b\s+(?:for|if|when|to|=|:|-)\s+([a-zA-Z0-9_\-\s]+?)(?=(?:,|\.|\band\b|\bor\b|;|press|hit|use|withhold|$))/gi;
    let m1: RegExpExecArray | null;
    while ((m1 = p1.exec(lower)) !== null) {
      let k = m1[1].toLowerCase();
      if (k.startsWith('space')) k = 'space';
      const targetName = m1[2].trim().replace(/^(?:the|a|an)\s+/i, '');
      if (targetName && targetName.length > 1 && !['all', 'trials', 'times', 'feedback', 'points', 'accuracy'].includes(targetName)) {
        conceptsMap.set(targetName, { key: k });
      }
    }

    // Pattern 2: Parenthesized key syntax: "Car (F), Cake (D)" or "Rock (1), Paper (2)"
    const p2 = /\b([a-zA-Z0-9_\-]+)\s*\(([a-z0-9]|space(?:bar)?)\)/gi;
    let m2: RegExpExecArray | null;
    while ((m2 = p2.exec(prompt)) !== null) {
      const name = m2[1].trim();
      let k = m2[2].toLowerCase();
      if (k.startsWith('space')) k = 'space';
      if (name.length > 1) {
        conceptsMap.set(name.toLowerCase(), { key: k });
      }
    }

    // Pattern 3: Inverted condition syntax: "If Car press F, if Cake press D"
    const p3 = /(?:if|when|whenever)\s+(?:you\s+see\s+)?(?:a|an|the)?\s*([a-zA-Z0-9_\-]+)\s*(?:appears|is\s+shown)?\s*(?:,|\s+then)?\s*(?:press|hit|use|key)\s*([a-z0-9]|space(?:bar)?)/gi;
    let m3: RegExpExecArray | null;
    while ((m3 = p3.exec(lower)) !== null) {
      const name = m3[1].trim();
      let k = m3[2].toLowerCase();
      if (k.startsWith('space')) k = 'space';
      if (name.length > 1) {
        conceptsMap.set(name, { key: k });
      }
    }

    // Pattern 4: Withholding condition: "withhold on Asteroid", "ignore Distractor", "no-go on Red"
    const pWithhold = /(?:withhold|ignore|do\s+not\s+press|stop|no-?go)\s+(?:on|for|when|if)?\s*(?:(?:a|an|the)\s+)?([a-zA-Z0-9_\-]+)/gi;
    let mw: RegExpExecArray | null;
    while ((mw = pWithhold.exec(lower)) !== null) {
      const name = mw[1].trim();
      if (name.length > 1) {
        conceptsMap.set(name, { key: 'none', isWithhold: true });
      }
    }

    // Pattern 5: "X vs Y" or "X versus Y" (e.g. "Car vs Cake", "Dogs vs Cats", "Weapons vs Tools")
    if (conceptsMap.size < 2) {
      const vsMatch = prompt.match(/\b([a-zA-Z0-9_\-]+)\s+(?:vs\.?|versus|\/)\s+([a-zA-Z0-9_\-]+)\b/i);
      if (vsMatch) {
        const c1 = vsMatch[1].trim().toLowerCase();
        const c2 = vsMatch[2].trim().toLowerCase();
        if (!conceptsMap.has(c1)) conceptsMap.set(c1, {});
        if (!conceptsMap.has(c2)) conceptsMap.set(c2, {});
      }
    }

    // Pattern 6: Listing syntax: "Show Apple, Orange, Car, Truck" or "(Pizza, Burger, Salad)"
    if (conceptsMap.size < 2) {
      const parenMatch = prompt.match(/\(([^)]+)\)/);
      if (parenMatch) {
        const items = parenMatch[1].split(/,|;|\band\b/).map(s => s.trim().toLowerCase()).filter(s => s.length > 1);
        items.forEach(it => {
          if (!conceptsMap.has(it)) conceptsMap.set(it, {});
        });
      } else {
        const showMatch = prompt.match(/(?:show|display|items?|present|categories)\s+([a-zA-Z0-9_\-\s,]+?)(?:\.|$|press|repeat|keys)/i);
        if (showMatch) {
          const items = showMatch[1].split(/,|;|\bor\b|\band\b/).map(s => s.trim().toLowerCase()).filter(s => s.length > 1 && !['a', 'the', 'an', 'or', 'and', 'if', 'items'].includes(s));
          if (items.length >= 2) {
            items.forEach(it => {
              if (!conceptsMap.has(it)) conceptsMap.set(it, {});
            });
          }
        }
      }
    }

    // Extract any standalone key declarations: "keys Z and M", "press F and J"
    const standaloneKeys: string[] = [];
    const keysRegex = /(?:press|key|keys|hit)\s+(?:the\s+)?\b([a-z0-9]|space(?:bar)?)\b/gi;
    let km: RegExpExecArray | null;
    while ((km = keysRegex.exec(lower)) !== null) {
      let k = km[1].toLowerCase();
      if (k.startsWith('space')) k = 'space';
      if (!standaloneKeys.includes(k)) standaloneKeys.push(k);
    }

    // Fallback key assignment order
    const ergonomicKeys = ['f', 'd', 'j', 'k', 'a', 'l', 'z', 'm', '1', '2', '3', '4'];
    let assignedKeyIdx = 0;

    // Convert conceptsMap to structured ResolvedConcept array
    const resolved: ResolvedConcept[] = [];
    let idx = 0;

    for (const [name, config] of conceptsMap.entries()) {
      let finalKey = config.key;
      if (!finalKey) {
        // Pick from standalone keys or ergonomic keys
        if (assignedKeyIdx < standaloneKeys.length && !resolved.some(r => r.key === standaloneKeys[assignedKeyIdx])) {
          finalKey = standaloneKeys[assignedKeyIdx++];
        } else {
          // Find next available ergonomic key
          while (assignedKeyIdx < ergonomicKeys.length && resolved.some(r => r.key === ergonomicKeys[assignedKeyIdx])) {
            assignedKeyIdx++;
          }
          finalKey = ergonomicKeys[assignedKeyIdx++] || `k${idx + 1}`;
        }
      }

      const capitalized = name.charAt(0).toUpperCase() + name.slice(1);
      const emoji = UniversalVisualResolver.resolveEmoji(name);
      const hexColor = UniversalVisualResolver.getConceptColor(name, idx);

      resolved.push({
        name: capitalized,
        cleanName: name,
        key: finalKey,
        emoji,
        displayText: `${emoji} ${capitalized.toUpperCase()}`,
        hexColor,
        isWithhold: config.isWithhold || finalKey === 'none'
      });
      idx++;
    }

    return resolved;
  }
}
