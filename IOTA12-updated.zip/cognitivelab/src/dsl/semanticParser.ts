import { ExperimentDSL, DSLNode, DSLEdge } from '../types/dsl';
import { defaultExperimentDSL } from './defaultExperiment';
import { ExperimentValidator } from './validator';
import { UniversalConceptEngine, UniversalVisualResolver } from './universalConceptEngine';

export interface SemanticIntent {
  paradigm: string;
  theme: 'deep-space-arcade' | 'academic-clean' | 'retro-synth';
  totalTrials: number;
  fixationDurationMs: number;
  fixationJitterMs: number;
  responseDeadlineMs: number;
  allowedKeys: string[];
  factors: Array<{
    name: string;
    levels: Array<{
      value: string;
      metadata: Record<string, any>;
    }>;
  }>;
  gameRules: {
    pointsCorrect: number;
    penaltyIncorrect: number;
    lives: number;
  };
}

export interface SemanticParseResult {
  dsl: ExperimentDSL;
  intent: SemanticIntent;
  assumptions: string[];
  criticWarnings: string[];
  providerUsed: 'local_semantic_compiler' | 'openai' | 'gemini';
}

export const EMOJI_DICTIONARY: Record<string, string> = {
  car: '🚗',
  cars: '🚗',
  vehicle: '🚗',
  vehicles: '🚗',
  cake: '🍰',
  cakes: '🍰',
  dessert: '🍰',
  pizza: '🍕',
  pizzas: '🍕',
  burger: '🍔',
  burgers: '🍔',
  salad: '🥗',
  salads: '🥗',
  ice_cream: '🍦',
  icecream: '🍦',
  apple: '🍎',
  apples: '🍎',
  banana: '🍌',
  bananas: '🍌',
  orange: '🍊',
  oranges: '🍊',
  fruit: '🍎',
  fruits: '🍎',
  cookie: '🍪',
  cookies: '🍪',
  donut: '🍩',
  candy: '🍬',
  dog: '🐶',
  dogs: '🐶',
  cat: '🐱',
  cats: '🐱',
  bird: '🐦',
  birds: '🐦',
  fish: '🐟',
  truck: '🚚',
  trucks: '🚚',
  plane: '✈️',
  airplane: '✈️',
  train: '🚆',
  rocket: '🚀',
  star: '⭐',
  stars: '⭐',
  heart: '❤️',
  hearts: '❤️',
  diamond: '💎',
  fire: '🔥',
  water: '💧',
  bomb: '💣',
  shield: '🛡️',
  sword: '⚔️',
  coffee: '☕',
  tea: '🍵',
  beer: '🍺',
  tree: '🌳',
  flower: '🌸',
  music: '🎵',
  book: '📚',
  books: '📚',
  computer: '💻',
  phone: '📱',
  money: '💵',
  house: '🏠',
  door: '🚪',
  bell: '🔔',
  gift: '🎁',
  trophy: '🏆',
  crown: '👑',
  ring: '💍',
  ball: '⚽',
  chair: '🪑'
};

export function getEmojiForWord(word: string): string {
  const clean = word.toLowerCase().trim().replace(/[^a-z0-9]/g, '_');
  if (EMOJI_DICTIONARY[clean]) return EMOJI_DICTIONARY[clean];
  for (const [k, emo] of Object.entries(EMOJI_DICTIONARY)) {
    if (clean.includes(k) || k.includes(clean)) return emo;
  }
  return '✨';
}

export class SemanticParser {
  /**
   * Compiles any natural-language prompt into a valid, strongly-typed Experiment DSL
   */
  public static async parsePrompt(
    prompt: string,
    apiKey?: string,
    provider: 'openai' | 'gemini' = 'gemini'
  ): Promise<SemanticParseResult> {
    // If an external API key is supplied, attempt live LLM synthesis
    if (apiKey && apiKey.trim().length > 10) {
      try {
        if (provider === 'gemini') {
          return await this.callGeminiAPI(prompt, apiKey);
        } else {
          return await this.callOpenAIAPI(prompt, apiKey);
        }
      } catch (err) {
        console.warn('External LLM call failed, falling back to local semantic engine', err);
      }
    }

    // Default: High-Precision Local Semantic Engine
    return this.parseLocally(prompt);
  }

  /**
   * High-Precision Local Semantic Rule & Intent Parser
   * Dynamically synthesizes arbitrary cognitive/behavioral experiments from natural language
   */
  public static parseLocally(prompt: string): SemanticParseResult {
    const lower = prompt.toLowerCase();
    const assumptions: string[] = [];
    const criticWarnings: string[] = [];

    // 1. Extract Trial Count (e.g. "60 trials", "repeat 50 times", "32 repetitions")
    let totalTrials = 32;
    const trialsMatch = lower.match(/(\d+)\s*(?:trials|times|repetitions|blocks|items)/);
    if (trialsMatch) {
      totalTrials = parseInt(trialsMatch[1], 10);
    } else {
      assumptions.push("Trial count unspecified; calibrated to 32 balanced trials.");
    }

    // 2. Extract Timing (Fixation cross duration, response deadline, ITI)
    let fixationMs = 500;
    let fixationJitter = 100;
    const fixMatch = lower.match(/fixation(?:\s*cross)?\s*(?:for)?\s*(\d+)\s*ms/);
    if (fixMatch) {
      fixationMs = parseInt(fixMatch[1], 10);
    } else {
      assumptions.push("Fixation duration set to 500 ms ± 100 ms pseudo-random jitter to prevent motor anticipation.");
    }

    let deadlineMs = 2000;
    const deadlineMatch = lower.match(/(?:deadline|timeout|response window)\s*(?:of)?\s*(\d+)\s*ms/);
    if (deadlineMatch) {
      deadlineMs = parseInt(deadlineMatch[1], 10);
    }

    // 3. Extract Gamification & Theme
    const isGame = lower.includes('space') || lower.includes('game') || lower.includes('arcade') || 
                   lower.includes('points') || lower.includes('score') || lower.includes('asteroid') || 
                   lower.includes('lives');
    const theme: 'deep-space-arcade' | 'academic-clean' = isGame ? 'deep-space-arcade' : 'academic-clean';
    
    let pointsCorrect = 100;
    const pointsMatch = lower.match(/(\d+)\s*points/);
    if (pointsMatch) {
      pointsCorrect = parseInt(pointsMatch[1], 10);
    }

    // 4. Dynamic Key Extraction & Target Mapping
    // Extract explicit key-target mappings: "press X for Y", "X for Y", "press spacebar"
    const keyMatches: string[] = [];
    const targetKeyMap: Record<string, string> = {};

    // Pattern 1: "press J for red, K for blue, and L for green", "F for fruits and V for vehicles"
    const mappingRegex = /(?:press\s+)?\b(space(?:bar)?|[a-z0-9])\b\s+(?:for|if|when|to)\s+([a-zA-Z0-9_\-]+)/gi;
    let mm: RegExpExecArray | null;
    while ((mm = mappingRegex.exec(lower)) !== null) {
      let k = mm[1].toLowerCase();
      if (k.startsWith('space')) k = 'space';
      const target = mm[2].toLowerCase();
      if (!keyMatches.includes(k)) keyMatches.push(k);
      targetKeyMap[target] = k;
    }

    // Pattern 2: "press X", "keys Z and M", "press spacebar"
    const keyRegex = /(?:press|key|keys|hit)\s+(?:the\s+)?\b(space(?:bar)?|[a-z0-9])\b/gi;
    let km: RegExpExecArray | null;
    while ((km = keyRegex.exec(lower)) !== null) {
      let k = km[1].toLowerCase();
      if (k.startsWith('space')) k = 'space';
      if (!keyMatches.includes(k)) keyMatches.push(k);
    }

    // 5. Intelligent Domain Paradigm Classification & Factor Synthesis
    let intent: SemanticIntent;

    // Pattern A: Spatial Grid / Matrix Working Memory
    if (lower.includes('spatial') || lower.includes('matrix') || lower.includes('grid') || lower.includes('corsi') || (lower.includes('tile') && lower.includes('position'))) {
      const allowedKeys = keyMatches.length >= 2 ? keyMatches.slice(0, 2) : ['z', 'm'];
      totalTrials = totalTrials > 0 && totalTrials % 4 === 0 ? totalTrials : 32;

      intent = {
        paradigm: 'spatial_grid_working_memory',
        theme,
        totalTrials,
        fixationDurationMs: fixationMs,
        fixationJitterMs: fixationJitter,
        responseDeadlineMs: Math.max(deadlineMs, 2200),
        allowedKeys,
        factors: [
          {
            name: 'spatial_location',
            levels: [
              { value: 'grid_top_left', metadata: { hex: '#38bdf8', text: 'GRID (1,1) TOP-LEFT', expected_key: allowedKeys[0], type: 'spatial_grid', gridRow: 0, gridCol: 0 } },
              { value: 'grid_center', metadata: { hex: '#38bdf8', text: 'GRID (2,2) CENTER', expected_key: allowedKeys[0], type: 'spatial_grid', gridRow: 1, gridCol: 1 } },
              { value: 'grid_top_right', metadata: { hex: '#f43f5e', text: 'GRID (1,3) TOP-RIGHT', expected_key: allowedKeys[1], type: 'spatial_grid', gridRow: 0, gridCol: 2 } },
              { value: 'grid_bottom_right', metadata: { hex: '#f43f5e', text: 'GRID (3,3) BOTTOM-RIGHT', expected_key: allowedKeys[1], type: 'spatial_grid', gridRow: 2, gridCol: 2 } }
            ]
          }
        ],
        gameRules: {
          pointsCorrect,
          penaltyIncorrect: 0,
          lives: 3
        }
      };
      assumptions.push("Synthesized 3x3 visuospatial matrix with left/right target quadrant discrimination.");
    }
    // Pattern B: Go / No-Go or CPT Inhibitory Control
    else if (lower.includes('go/no-go') || lower.includes('go-no-go') || lower.includes('gonogo') || lower.includes('go nogo') || lower.includes('withhold') || (lower.includes('inhibition') && lower.includes('space'))) {
      const goKey = (keyMatches.includes('space') || lower.includes('space')) ? 'space' : (keyMatches.length > 0 ? keyMatches[0] : 'space');
      totalTrials = totalTrials > 0 && totalTrials % 4 === 0 ? totalTrials : 32;

      intent = {
        paradigm: 'go_nogo_inhibitory_control',
        theme,
        totalTrials,
        fixationDurationMs: fixationMs,
        fixationJitterMs: fixationJitter,
        responseDeadlineMs: 1500,
        allowedKeys: [goKey],
        factors: [
          {
            name: 'trial_type',
            levels: [
              { value: 'go_target', metadata: { hex: '#22c55e', text: 'GO TARGET 🟢', expected_key: goKey, type: 'color_circle', is_target: true } },
              { value: 'go_target_alt', metadata: { hex: '#10b981', text: 'GO TARGET 🟢', expected_key: goKey, type: 'color_circle', is_target: true } },
              { value: 'go_target_flash', metadata: { hex: '#34d399', text: 'GO TARGET 🟢', expected_key: goKey, type: 'color_circle', is_target: true } },
              { value: 'nogo_distractor', metadata: { hex: '#ef4444', text: 'NO-GO WITHHOLD 🔴', expected_key: 'none', type: 'color_circle', is_target: false } }
            ]
          }
        ],
        gameRules: {
          pointsCorrect,
          penaltyIncorrect: 1,
          lives: 3
        }
      };
      assumptions.push("Constructed Go/No-Go inhibitory control paradigm: 75% Go frequency to establish prepotent motor response, 25% No-Go frequency.");
    }
    // Pattern C: Stroop Color-Word Interference
    else if (lower.includes('stroop') || (lower.includes('color') && lower.includes('word') && lower.includes('ink'))) {
      const allowedKeys = keyMatches.length >= 2 ? keyMatches.slice(0, 2) : ['r', 'b'];
      totalTrials = totalTrials > 0 && totalTrials % 4 === 0 ? totalTrials : 32;

      intent = {
        paradigm: 'stroop_color_word_interference',
        theme: 'academic-clean',
        totalTrials,
        fixationDurationMs: fixationMs,
        fixationJitterMs: fixationJitter,
        responseDeadlineMs: deadlineMs,
        allowedKeys,
        factors: [
          {
            name: 'congruency',
            levels: [
              { value: 'congruent_red', metadata: { hex: '#ef4444', text: 'RED', expected_key: allowedKeys[0], type: 'word_ink' } },
              { value: 'incongruent_blue_in_red', metadata: { hex: '#ef4444', text: 'BLUE', expected_key: allowedKeys[0], type: 'word_ink' } },
              { value: 'congruent_blue', metadata: { hex: '#3b82f6', text: 'BLUE', expected_key: allowedKeys[1], type: 'word_ink' } },
              { value: 'incongruent_red_in_blue', metadata: { hex: '#3b82f6', text: 'RED', expected_key: allowedKeys[1], type: 'word_ink' } }
            ]
          }
        ],
        gameRules: {
          pointsCorrect,
          penaltyIncorrect: 0,
          lives: 3
        }
      };
      assumptions.push("Synthesized classic Stroop factorial design with 2x2 Congruency (Congruent vs Incongruent) x Ink Hue.");
    }
    // Pattern D: Eriksen Flanker Attentional Inhibition
    else if (lower.includes('flanker') || lower.includes('arrow')) {
      const allowedKeys = keyMatches.length >= 2 ? keyMatches.slice(0, 2) : ['z', 'm'];
      totalTrials = totalTrials > 0 && totalTrials % 4 === 0 ? totalTrials : 32;

      intent = {
        paradigm: 'eriksen_flanker_attentional_inhibition',
        theme: 'academic-clean',
        totalTrials,
        fixationDurationMs: fixationMs,
        fixationJitterMs: fixationJitter,
        responseDeadlineMs: 1800,
        allowedKeys,
        factors: [
          {
            name: 'compatibility',
            levels: [
              { value: 'congruent_left', metadata: { hex: '#38bdf8', text: '< < < < <', expected_key: allowedKeys[0], type: 'text' } },
              { value: 'incongruent_left', metadata: { hex: '#38bdf8', text: '> > < > >', expected_key: allowedKeys[0], type: 'text' } },
              { value: 'congruent_right', metadata: { hex: '#818cf8', text: '> > > > >', expected_key: allowedKeys[1], type: 'text' } },
              { value: 'incongruent_right', metadata: { hex: '#818cf8', text: '< < > < <', expected_key: allowedKeys[1], type: 'text' } }
            ]
          }
        ],
        gameRules: {
          pointsCorrect,
          penaltyIncorrect: 0,
          lives: 3
        }
      };
      assumptions.push("Synthesized Eriksen 5-arrow array measuring spatial attentional interference.");
    }
    // Pattern E: Universal Concept & Visual Stimulus Extraction
    else {
      // 1. Extract concepts and keys dynamically using UniversalConceptEngine
      const universalConcepts = UniversalConceptEngine.parseConceptsAndKeys(prompt);

      // Check for explicitly mentioned colors
      const colorPalettes: Record<string, string> = {
        red: '#ef4444',
        blue: '#3b82f6',
        green: '#22c55e',
        yellow: '#eab308',
        purple: '#a855f7',
        orange: '#f97316',
        pink: '#ec4899',
        cyan: '#06b6d4',
        white: '#f8fafc'
      };
      const foundColors = Object.keys(colorPalettes).filter(c => lower.includes(c));

      if (universalConcepts.length >= 2) {
        const numItems = universalConcepts.length;
        totalTrials = totalTrials > 0 && totalTrials % numItems === 0 ? totalTrials : numItems * 8;

        const levels = universalConcepts.map((concept) => ({
          value: concept.cleanName.replace(/\s+/g, '_'),
          metadata: {
            hex: concept.hexColor,
            text: concept.displayText,
            expected_key: concept.key,
            type: 'text',
            is_target: !concept.isWithhold
          }
        }));

        const activeKeys = Array.from(new Set(levels.map(l => l.metadata.expected_key).filter(k => k !== 'none')));
        const hasWithhold = levels.some(l => l.metadata.expected_key === 'none');

        let paradigmName = hasWithhold ? 'go_nogo_inhibitory_control' : 'category_evaluative_choice';
        if (/\b(food|foods|eat|eating|taste|tasting|snack|snacks|meal|meals)\b/i.test(lower)) {
          paradigmName = 'food_preference_choice';
        }

        intent = {
          paradigm: paradigmName,
          theme,
          totalTrials,
          fixationDurationMs: fixationMs,
          fixationJitterMs: fixationJitter,
          responseDeadlineMs: deadlineMs,
          allowedKeys: activeKeys.length > 0 ? activeKeys : ['f', 'd'],
          factors: [
            {
              name: 'stimulus_item',
              levels
            }
          ],
          gameRules: {
            pointsCorrect,
            penaltyIncorrect: hasWithhold ? 1 : 0,
            lives: 3
          }
        };
        assumptions.push(`Synthesized open-domain cognitive task with ${numItems} visual conditions: [${universalConcepts.map(c => c.displayText).join(', ')}].`);
      } else if (foundColors.length >= 2) {
        // Multi-color visual discrimination (2AFC or 3AFC)
        const numColors = foundColors.length;
        totalTrials = totalTrials > 0 && totalTrials % numColors === 0 ? totalTrials : numColors * 12;
        const isSquare = lower.includes('square');
        const allowedKeys = keyMatches.length >= numColors ? keyMatches.slice(0, numColors) : ['a', 'l', 'j', 'k'].slice(0, numColors);

        const levels = foundColors.map((colorName, idx) => {
          const keyForColor = targetKeyMap[colorName] || allowedKeys[idx % allowedKeys.length];
          return {
            value: colorName,
            metadata: {
              hex: colorPalettes[colorName] || '#38bdf8',
              text: `${colorName.toUpperCase()} TARGET`,
              expected_key: keyForColor,
              type: isSquare ? 'color_square' : 'color_circle'
            }
          };
        });

        const activeKeys = Array.from(new Set(levels.map(l => l.metadata.expected_key)));
        intent = {
          paradigm: `${activeKeys.length}afc_visual_color_discrimination`,
          theme,
          totalTrials,
          fixationDurationMs: fixationMs,
          fixationJitterMs: fixationJitter,
          responseDeadlineMs: deadlineMs,
          allowedKeys: activeKeys,
          factors: [
            {
              name: 'color_factor',
              levels
            }
          ],
          gameRules: {
            pointsCorrect,
            penaltyIncorrect: isGame ? 1 : 0,
            lives: 3
          }
        };
        assumptions.push(`Extracted ${numColors} chromatic conditions: [${foundColors.join(', ')}] with balanced trials.`);
      } else {
        // Universal synthesis fallback: Star vs Gem
        totalTrials = totalTrials > 0 && totalTrials % 2 === 0 ? totalTrials : 32;
        const allowedKeys = ['f', 'j'];

        intent = {
          paradigm: 'speeded_visual_reaction_time',
          theme,
          totalTrials,
          fixationDurationMs: fixationMs,
          fixationJitterMs: fixationJitter,
          responseDeadlineMs: deadlineMs,
          allowedKeys,
          factors: [
            {
              name: 'stimulus_item',
              levels: [
                { value: 'star', metadata: { hex: '#eab308', text: '⭐ GOLDEN STAR', expected_key: 'f', type: 'text' } },
                { value: 'gem', metadata: { hex: '#38bdf8', text: '💎 COSMIC GEM', expected_key: 'j', type: 'text' } }
              ]
            }
          ],
          gameRules: {
            pointsCorrect,
            penaltyIncorrect: 0,
            lives: 3
          }
        };
        assumptions.push("Universal synthesis fallback: Initialized Speeded Reaction Task with Golden Star (F) vs Cosmic Gem (J).");
      }
    }

    // 6. Assemble Canonical DSL Graph with Compact Structured Viewport Layout
    const dsl = this.buildDSLFromIntent(intent, prompt);

    // 7. Execute Semantic Validator & Critic
    const validation = ExperimentValidator.validate(dsl);
    if (!validation.isValid) {
      criticWarnings.push(...validation.issues.map(i => i.message));
    }

    return {
      dsl,
      intent,
      assumptions,
      criticWarnings,
      providerUsed: 'local_semantic_compiler'
    };
  }

  /**
   * Assembles a fully wired Canonical Experiment DSL from structured intent.
   * Node positions are laid out in a compact multi-row pipeline that fits on screen.
   */
  private static buildDSLFromIntent(intent: SemanticIntent, originalPrompt: string): ExperimentDSL {
    const slug = intent.paradigm.replace(/_/g, '-');
    const factor = intent.factors[0];
    const repsPerLevel = Math.max(Math.floor(intent.totalTrials / factor.levels.length), 1);

    // Generate plain-text instruction markdown
    const keyLines = factor.levels.map((lvl) => {
      const displayDesc = lvl.metadata.text || lvl.value.toUpperCase();
      const expected = lvl.metadata.expected_key;
      const keyDesc = expected === 'none' ? 'DO NOT PRESS ANY KEY (WITHHOLD)' : `press **${expected.toUpperCase()}**`;
      return `* When you see **${displayDesc}**, ${keyDesc}`;
    }).join('\n');

    const instructionMarkdown = `### ${intent.paradigm.replace(/_/g, ' ').toUpperCase()}\n\nTarget stimuli will appear rapidly.\n\n${keyLines}\n\nRespond as quickly and accurately as possible.`;

    // Compact, structured 4-row layout:
    // Row 1 (Setup): Start -> Consent -> Calibration -> Instruction -> Generator
    // Row 2 (Trial Loop): Loop -> Fixation -> Stimulus -> Response -> Condition
    // Row 3 (Outcomes & Telemetry): Reward / Penalty -> Record -> ITI
    // Row 4 (Debrief): Debrief -> End
    const nodes: DSLNode[] = [
      {
        id: 'n_start',
        type: 'flow_start',
        label: 'Experiment Entry',
        config: {},
        position: { x: 60, y: 60 }
      },
      {
        id: 'n_consent',
        type: 'presentation_text',
        label: 'Informed Consent',
        config: {
          title: 'IRB Ethics Consent',
          content_markdown: '### Study Participation\n\nYour participation is anonymous and voluntary. You may exit at any time.',
          continue_button_text: 'I Agree & Proceed'
        },
        position: { x: 240, y: 60 }
      },
      {
        id: 'n_calibration',
        type: 'timing_calibration',
        label: 'Display Benchmark',
        config: { measure_fps_frames: 120, reject_frame_jitter_ms: 8 },
        position: { x: 420, y: 60 }
      },
      {
        id: 'n_instruction',
        type: 'presentation_text',
        label: 'Task Instructions',
        config: {
          title: 'Task Briefing',
          content_markdown: instructionMarkdown,
          continue_button_text: 'Start Task'
        },
        position: { x: 600, y: 60 }
      },
      {
        id: 'n_generator',
        type: 'randomization_balanced_block',
        label: `${factor.name.toUpperCase()} Generator`,
        config: {
          factors: intent.factors,
          total_trials: intent.totalTrials,
          repetitions_per_level: repsPerLevel,
          max_consecutive_identical: 3,
          prng_algorithm: 'mulberry32'
        },
        position: { x: 780, y: 60 }
      },
      {
        id: 'n_loop',
        type: 'logic_loop',
        label: `Loop (${intent.totalTrials} Trials)`,
        config: { iterator_source: 'n_generator', max_iterations: intent.totalTrials },
        position: { x: 60, y: 220 }
      },
      {
        id: 'n_fixation',
        type: 'presentation_fixation',
        label: 'Fixation Cross',
        config: {
          duration_ms: intent.fixationDurationMs,
          jitter_ms: intent.fixationJitterMs,
          shape: 'cross',
          color: '#94a3b8'
        },
        position: { x: 240, y: 220 }
      },
      {
        id: 'n_stimulus',
        type: 'presentation_stimulus',
        label: 'Target Stimulus',
        config: {
          stimulus_type: factor.levels[0]?.metadata.type || 'color_circle',
          duration_max_ms: intent.responseDeadlineMs
        },
        position: { x: 420, y: 220 }
      },
      {
        id: 'n_response',
        type: 'response_keyboard',
        label: 'Keystroke Capture',
        config: {
          allowed_keys: intent.allowedKeys,
          deadline_ms: intent.responseDeadlineMs,
          record_rt: true
        },
        position: { x: 600, y: 220 }
      },
      {
        id: 'n_condition',
        type: 'logic_condition',
        label: 'Evaluate Accuracy',
        config: { condition_expression: 'response.key === variables.expected_key' },
        position: { x: 780, y: 220 }
      },
      {
        id: 'n_reward_correct',
        type: 'game_reward',
        label: `+${intent.gameRules.pointsCorrect} Points`,
        config: {
          points: intent.gameRules.pointsCorrect,
          streak_delta: 1,
          feedback_text: `+${intent.gameRules.pointsCorrect} HIT!`,
          color: '#22c55e'
        },
        position: { x: 970, y: 150 }
      },
      {
        id: 'n_penalty_incorrect',
        type: 'game_reward',
        label: 'Incorrect Feedback',
        config: {
          points: 0,
          streak_delta: 0,
          feedback_text: intent.gameRules.penaltyIncorrect > 0 ? '-1 LIFE MISS' : 'MISS',
          color: '#ef4444'
        },
        position: { x: 970, y: 270 }
      },
      {
        id: 'n_record',
        type: 'data_record_trial',
        label: 'Commit Trial Telemetry',
        config: { persist_to_indexeddb: true },
        position: { x: 1160, y: 220 }
      },
      {
        id: 'n_iti',
        type: 'timing_wait',
        label: 'Inter-Trial Interval',
        config: { duration_ms: 350 },
        position: { x: 1340, y: 220 }
      },
      {
        id: 'n_debrief',
        type: 'presentation_text',
        label: 'Session Complete',
        config: {
          title: 'Session Debriefing',
          content_markdown: 'Thank you for completing this behavioral session!\n\nYour data has been encrypted and recorded.',
          continue_button_text: 'Finish'
        },
        position: { x: 420, y: 360 }
      },
      {
        id: 'n_end',
        type: 'flow_end',
        label: 'Experiment End',
        config: {},
        position: { x: 600, y: 360 }
      }
    ];

    const edges: DSLEdge[] = [
      { id: 'e1', from: 'n_start', to: 'n_consent' },
      { id: 'e2', from: 'n_consent', to: 'n_calibration' },
      { id: 'e3', from: 'n_calibration', to: 'n_instruction' },
      { id: 'e4', from: 'n_instruction', to: 'n_generator' },
      { id: 'e5', from: 'n_generator', to: 'n_loop' },
      { id: 'e6', from: 'n_loop', to: 'n_fixation', port: 'loop_body', label: 'Trial' },
      { id: 'e7', from: 'n_fixation', to: 'n_stimulus' },
      { id: 'e8', from: 'n_stimulus', to: 'n_response' },
      { id: 'e9', from: 'n_response', to: 'n_condition' },
      { id: 'e10', from: 'n_condition', to: 'n_reward_correct', port: 'true', label: 'Correct' },
      { id: 'e11', from: 'n_condition', to: 'n_penalty_incorrect', port: 'false', label: 'Incorrect' },
      { id: 'e12', from: 'n_reward_correct', to: 'n_record' },
      { id: 'e13', from: 'n_penalty_incorrect', to: 'n_record' },
      { id: 'e14', from: 'n_record', to: 'n_iti' },
      { id: 'e15', from: 'n_iti', to: 'n_loop', port: 'loop_next', label: 'Next' },
      { id: 'e16', from: 'n_loop', to: 'n_debrief', port: 'complete', label: 'Finished' },
      { id: 'e17', from: 'n_debrief', to: 'n_end' }
    ];

    let title = intent.paradigm.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    let description = `Generated from researcher prompt: "${originalPrompt}"`;

    if (intent.factors[0]?.name === 'stimulus_item' && intent.factors[0].levels.length >= 2) {
      const itemsList = intent.factors[0].levels.map(l => l.value.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()));
      title = `${itemsList.slice(0, 3).join(' vs ')} Discrimination Task`;
      const keyMapps = intent.factors[0].levels.map(l => `${l.metadata.text || l.value} (key: ${l.metadata.expected_key?.toUpperCase()})`).join(', ');
      description = `Visual choice discrimination task evaluating response latencies and accuracy: ${keyMapps}.`;
    }

    return {
      $schema: 'https://cognitivelab.io/schemas/v1/experiment.json',
      experiment: {
        id: `exp_${slug}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`,
        slug,
        version: 1,
        title,
        description,
        created_at: new Date().toISOString(),
        author: { user_id: 'usr_researcher', institution: 'CognitiveLab AI Studio' },
        reproducibility: { dsl_version: '1.0.0', target_runtime: 'jspsych-7.3.4' }
      },
      participant_settings: {
        allow_anonymous: true,
        enforce_fullscreen: true,
        minimum_display_hz: 58,
        device_allowlist: ['desktop', 'laptop'],
        required_inputs: ['keyboard']
      },
      consent_settings: {
        required: true,
        ethics_protocol_id: 'IRB-COG-2026',
        statement_text: 'You are invited to participate in a cognitive visual decision study. Participation is anonymous and voluntary.',
        require_checkbox: true,
        minimum_age: 18
      },
      variables: {
        total_score: { type: 'number', default: 0, scope: 'global' },
        streak_count: { type: 'number', default: 0, scope: 'global' },
        lives: { type: 'number', default: intent.gameRules.lives, scope: 'global' }
      },
      game_skin: {
        enabled: intent.theme === 'deep-space-arcade',
        theme: intent.theme,
        sound_enabled: true,
        hud_elements: { show_score: true, show_streak: true, show_progress_bar: true },
        score_rules: {
          correct_base_points: intent.gameRules.pointsCorrect,
          streak_bonus_multiplier: 1.25,
          incorrect_penalty: intent.gameRules.penaltyIncorrect,
          max_rt_for_bonus_ms: 450
        }
      },
      nodes,
      edges
    };
  }

  /**
   * Applies iterative conversational mutations (RFC 6902-style edits)
   */
  public static applyIterativePatch(
    currentDsl: ExperimentDSL,
    instruction: string
  ): { updatedDsl: ExperimentDSL; description: string } {
    const lower = instruction.toLowerCase();
    const cloned: ExperimentDSL = JSON.parse(JSON.stringify(currentDsl));
    let description = 'Applied parameter adjustments';

    // 1. Modify trial count (e.g. "change trials to 48", "make it 50 trials", "repeat 60 times")
    const trialMatch = lower.match(/(?:trials|times|repetitions)\s*(?:to|=)?\s*(\d+)/) ||
                       lower.match(/(?:make it|change to|set to)?\s*(\d+)\s*(?:trials|times|repetitions)/);
    if (trialMatch) {
      const newTrials = parseInt(trialMatch[1], 10);
      cloned.nodes = cloned.nodes.map(n => {
        if (n.type === 'randomization_balanced_block') {
          const factorCount = n.config.factors?.[0]?.levels?.length || 2;
          return {
            ...n,
            config: {
              ...n.config,
              total_trials: newTrials,
              repetitions_per_level: Math.max(Math.floor(newTrials / factorCount), 1)
            }
          };
        }
        if (n.type === 'logic_loop') {
          return { ...n, config: { ...n.config, max_iterations: newTrials } };
        }
        return n;
      });
      description = `Updated total trial count to ${newTrials} across all blocks.`;
      return { updatedDsl: cloned, description };
    }

    // 2. Modify Fixation duration (e.g. "set fixation to 600ms", "make fixation 400ms")
    const fixMatch = lower.match(/(?:fixation|cross).*?(\d+)\s*ms/);
    if (fixMatch) {
      const newFix = parseInt(fixMatch[1], 10);
      cloned.nodes = cloned.nodes.map(n => {
        if (n.type === 'presentation_fixation') {
          return { ...n, config: { ...n.config, duration_ms: newFix } };
        }
        return n;
      });
      description = `Changed fixation cross duration to ${newFix} ms.`;
      return { updatedDsl: cloned, description };
    }

    // 3. Toggle/Change Gamification Skin (e.g. "make it space themed", "remove game", "disable sound")
    if (lower.includes('space') || lower.includes('arcade')) {
      cloned.game_skin.enabled = true;
      cloned.game_skin.theme = 'deep-space-arcade';
      description = 'Enabled Space Arcade presentation skin.';
      return { updatedDsl: cloned, description };
    }

    if (lower.includes('academic') || lower.includes('plain') || lower.includes('remove game') || lower.includes('disable game')) {
      cloned.game_skin.enabled = false;
      description = 'Switched to Academic High-Contrast Plain skin.';
      return { updatedDsl: cloned, description };
    }

    if (lower.includes('mute') || lower.includes('disable sound') || lower.includes('no sound')) {
      cloned.game_skin.sound_enabled = false;
      description = 'Muted WebAudio sound effects.';
      return { updatedDsl: cloned, description };
    }

    // 4. Modify Key Bindings (e.g. "use keys z and m", "use arrow keys")
    if (lower.includes('arrow')) {
      cloned.nodes = cloned.nodes.map(n => {
        if (n.type === 'response_keyboard') {
          return { ...n, config: { ...n.config, allowed_keys: ['arrowleft', 'arrowright'] } };
        }
        return n;
      });
      description = 'Re-mapped response input keys to Left and Right arrows.';
      return { updatedDsl: cloned, description };
    }

    return { updatedDsl: cloned, description: 'No matching parameter modification rule detected.' };
  }

  /**
   * Optional Gemini API provider
   */
  private static async callGeminiAPI(prompt: string, apiKey: string): Promise<SemanticParseResult> {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    const systemPrompt = `You are an expert cognitive scientist. Convert the user prompt into structured JSON:
{
  "title": string,
  "description": string,
  "trials": number,
  "theme": "deep-space-arcade" | "academic-clean",
  "keys": string[],
  "deadline_ms": number,
  "fixation_ms": number,
  "factor_name": string,
  "levels": [
    { "value": string, "text": string, "hex": string, "expected_key": string }
  ]
}`;

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          { parts: [{ text: `${systemPrompt}\n\nUser request: "${prompt}"` }] }
        ],
        generationConfig: { responseMimeType: 'application/json' }
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API returned status ${response.status}`);
    }

    const data = await response.json();
    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
    const parsed = JSON.parse(rawText);

    return this.mergeLlmResponse(prompt, parsed, 'gemini');
  }

  /**
   * Optional OpenAI API provider
   */
  private static async callOpenAIAPI(prompt: string, apiKey: string): Promise<SemanticParseResult> {
    const url = 'https://api.openai.com/v1/chat/completions';
    const systemPrompt = `You are an expert cognitive scientist. Convert the user's natural language experiment request into structured JSON with:
{
  "title": string,
  "description": string,
  "trials": number,
  "theme": "deep-space-arcade" | "academic-clean",
  "keys": ["a", "l"],
  "deadline_ms": number,
  "fixation_ms": number,
  "factor_name": string,
  "levels": [
    { "value": string, "text": string, "hex": string, "expected_key": string }
  ]
}`;

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt }
        ],
        response_format: { type: 'json_object' }
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API returned status ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '{}';
    const parsed = JSON.parse(content);

    return this.mergeLlmResponse(prompt, parsed, 'openai');
  }

  /**
   * Merges external LLM extracted parameters into a valid canonical DSL
   */
  private static mergeLlmResponse(
    prompt: string,
    parsed: any,
    provider: 'openai' | 'gemini'
  ): SemanticParseResult {
    const baseResult = this.parseLocally(prompt);
    const dsl = baseResult.dsl;

    if (parsed.title) dsl.experiment.title = parsed.title;
    if (parsed.description) dsl.experiment.description = parsed.description;
    if (parsed.theme === 'deep-space-arcade' || parsed.theme === 'academic-clean') {
      dsl.game_skin.theme = parsed.theme;
      dsl.game_skin.enabled = parsed.theme === 'deep-space-arcade';
    }

    const trials = typeof parsed.trials === 'number' && parsed.trials > 0 ? parsed.trials : null;
    const allowedKeys = Array.isArray(parsed.keys) && parsed.keys.length > 0 
      ? parsed.keys.map((k: string) => String(k).toLowerCase()) 
      : null;

    dsl.nodes = dsl.nodes.map(n => {
      if (n.type === 'randomization_balanced_block') {
        const factorLevels = Array.isArray(parsed.levels) && parsed.levels.length > 0
          ? parsed.levels.map((lvl: any, i: number) => ({
              value: lvl.value || `cond_${i + 1}`,
              metadata: {
                hex: lvl.hex || '#38bdf8',
                text: lvl.text || lvl.value,
                expected_key: lvl.expected_key || (allowedKeys ? allowedKeys[i % allowedKeys.length] : 'a'),
                type: 'text'
              }
            }))
          : n.config.factors?.[0]?.levels;

        const factorCount = factorLevels?.length || 2;
        const total = trials || n.config.total_trials || 30;

        return {
          ...n,
          config: {
            ...n.config,
            total_trials: total,
            repetitions_per_level: Math.max(Math.floor(total / factorCount), 1),
            factors: [
              {
                name: parsed.factor_name || 'stimulus_condition',
                levels: factorLevels
              }
            ]
          }
        };
      }

      if (n.type === 'response_keyboard' && allowedKeys) {
        return {
          ...n,
          config: {
            ...n.config,
            allowed_keys: allowedKeys,
            deadline_ms: parsed.deadline_ms || n.config.deadline_ms
          }
        };
      }

      if (n.type === 'presentation_fixation' && typeof parsed.fixation_ms === 'number') {
        return {
          ...n,
          config: {
            ...n.config,
            duration_ms: parsed.fixation_ms
          }
        };
      }

      return n;
    });

    baseResult.providerUsed = provider;
    return baseResult;
  }
}
