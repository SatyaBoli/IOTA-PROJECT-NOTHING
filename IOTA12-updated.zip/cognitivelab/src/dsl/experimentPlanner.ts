import { 
  ExperimentDSL, 
  ExperimentPlan, 
  ExperimentCondition, 
  TrialTemplate, 
  DSLNode, 
  DSLEdge, 
  GameSkinTheme,
  ResponseType 
} from '../types/dsl';
import { assetService } from '../services/assets/AssetService';

export interface PlanGenerationResult {
  dsl: ExperimentDSL;
  plan: ExperimentPlan;
  assumptions: string[];
}

export class ExperimentPlanner {
  /**
   * Transforms any natural language researcher prompt into a structured, executable ExperimentPlan and DSL
   */
  public static planExperiment(prompt: string): PlanGenerationResult {
    const p = prompt.toLowerCase();

    // 1. Detect Research Paradigm & Theme
    const isForestOrTree = /tree|forest|plant|nature|wood|foliage|shrub/.test(p);
    const isDepressionOrClinical = /depress|mood|anxiety|phq|clinical|sentence|feeling|mental|psychometric|likert/.test(p);
    const isFoodOrDiet = /food|cake|pizza|burger|snack|diet|healthy|junk|taste|nutrition/.test(p);
    const isCarOrVehicle = /car|vehicle|drive|truck|sedan|speed/.test(p);
    const isSpaceOrArcade = /space|star|asteroid|galaxy|cosmic|ship/.test(p);

    let theme: GameSkinTheme = 'academic-clean';
    if (isForestOrTree) theme = 'forest-adventure';
    else if (isFoodOrDiet) theme = 'food-challenge';
    else if (isSpaceOrArcade || p.includes('space')) theme = 'deep-space-arcade';
    else if (isDepressionOrClinical) theme = 'academic-clean';
    else if (p.includes('game') || p.includes('arcade')) theme = 'retro-synth';

    // 2. Extract Trial Count
    const countMatch = p.match(/(\d+)\s*(?:trials?|reps?|rounds?|questions?|times?)/);
    const requestedTrials = countMatch ? parseInt(countMatch[1], 10) : (isDepressionOrClinical ? 18 : 30);

    // 3. Condition & Variable Generation
    let conditions: ExperimentCondition[] = [];
    let independentVariables: { name: string; levels: string[] }[] = [];
    let trialTemplates: TrialTemplate[] = [];
    let researchObjective = '';
    const assumptions: string[] = [];

    // Factorial Check: Did researcher specify multiple dimensions? e.g. "small, medium and large trees with sunny and rainy backgrounds"
    const hasWeatherFactor = /sun|sunny|rain|rainy|cloud|weather/.test(p);
    const hasTreeSizeFactor = isForestOrTree && /size|small|medium|large|big/.test(p);

    if (hasTreeSizeFactor && hasWeatherFactor) {
      // 2x3 Factorial Grid
      researchObjective = 'Investigate interaction between Tree Size and Weather Environment on perception and perceived safety.';
      independentVariables = [
        { name: 'tree_size', levels: ['small', 'medium', 'large'] },
        { name: 'weather', levels: ['sunny', 'rainy'] }
      ];

      const sizes = [
        { key: 'small', label: 'Small Tree', emoji: '🌱', scale: 0.6 },
        { key: 'medium', label: 'Medium Tree', emoji: '🌲', scale: 1.0 },
        { key: 'large', label: 'Large Tree', emoji: '🌳', scale: 1.5 }
      ];
      const weathers = [
        { key: 'sunny', label: 'Sunny', emoji: '☀️', mood: 'positive' },
        { key: 'rainy', label: 'Rainy', emoji: '🌧️', mood: 'somber' }
      ];

      sizes.forEach(s => {
        weathers.forEach(w => {
          conditions.push({
            id: `${s.key}_${w.key}`,
            label: `${s.label} (${w.label})`,
            variables: {
              tree_size: s.key,
              weather: w.key,
              visual_scale: s.scale,
              weather_mood: w.mood,
              primary_emoji: s.emoji,
              secondary_emoji: w.emoji
            },
            stimulus_ref: {
              provider: 'asset_service',
              asset_id: 'tree',
              filter: { size: s.key, weather: w.key }
            }
          });
        });
      });

      assumptions.push('Created 2x3 Factorial Design: 3 Tree Sizes (Small, Medium, Large) × 2 Weather Conditions (Sunny, Rainy) = 6 unique cells.');
      assumptions.push(`Distributed ${requestedTrials} trials equally across all 6 factorial cells (${Math.max(Math.floor(requestedTrials / 6), 1)} trials/cell).`);
    } else if (isForestOrTree) {
      // Tree Perception Study
      researchObjective = 'Assess human size perception, cognitive comparison, and affective safety associations with tree stimuli.';
      independentVariables = [
        { name: 'tree_size', levels: ['small', 'medium', 'large'] }
      ];

      conditions = [
        {
          id: 'tree_small',
          label: 'Small Tree',
          variables: { tree_size: 'small', visual_scale: 0.6, expected_safety: 'moderate', emoji: '🌱' },
          stimulus_ref: { provider: 'asset_service', asset_id: 'tree', filter: { size: 'small' } }
        },
        {
          id: 'tree_medium',
          label: 'Medium Tree',
          variables: { tree_size: 'medium', visual_scale: 1.0, expected_safety: 'high', emoji: '🌲' },
          stimulus_ref: { provider: 'asset_service', asset_id: 'tree', filter: { size: 'medium' } }
        },
        {
          id: 'tree_large',
          label: 'Large Tree',
          variables: { tree_size: 'large', visual_scale: 1.5, expected_safety: 'high', emoji: '🌳' },
          stimulus_ref: { provider: 'asset_service', asset_id: 'tree', filter: { size: 'large' } }
        }
      ];

      assumptions.push('Created 3 hierarchical size conditions: Small (🌱), Medium (🌲), Large (🌳).');
      assumptions.push('Configured multi-question trial bank: True/False/Unknown comparison, 3-option categorical size, and 1-5 safety rating.');
    } else if (isDepressionOrClinical) {
      // Psychometric Sentence Inventory (Depression / Mood Screening)
      researchObjective = 'Assess affective state and depressive symptom indicators through validated psychometric sentence rating.';
      independentVariables = [
        { name: 'symptom_domain', levels: ['anhedonia', 'energy_fatigue', 'cognitive_hopelessness', 'positive_affect'] }
      ];

      conditions = [
        {
          id: 'domain_anhedonia',
          label: 'Anhedonia / Interest',
          variables: { domain: 'anhedonia', valence: 'negative', reverse_scored: false, emoji: '🥀' }
        },
        {
          id: 'domain_energy',
          label: 'Energy & Fatigue',
          variables: { domain: 'energy_fatigue', valence: 'negative', reverse_scored: false, emoji: '⚡' }
        },
        {
          id: 'domain_hopelessness',
          label: 'Cognitive Hopelessness',
          variables: { domain: 'cognitive_hopelessness', valence: 'negative', reverse_scored: false, emoji: '🌧️' }
        },
        {
          id: 'domain_positive_resilience',
          label: 'Positive Resilience',
          variables: { domain: 'positive_affect', valence: 'positive', reverse_scored: true, emoji: '☀️' }
        }
      ];

      assumptions.push('Structured 4 psychometric clinical domains: Anhedonia, Fatigue, Cognitive Hopelessness, and Positive Affect.');
      assumptions.push('Configured 1-5 Likert Agreement scale (Strongly Disagree to Strongly Agree) with reverse-scoring calibration.');
      assumptions.push('Ensured clinical neutrality: Presentation skin locked to Academic Clean.');
    } else if (isFoodOrDiet && isCarOrVehicle) {
      // Food vs Car Categorization / Preference
      researchObjective = 'Measure cognitive discrimination and categorization latency between Food and Vehicle concepts.';
      independentVariables = [
        { name: 'category', levels: ['food', 'car'] }
      ];

      conditions = [
        {
          id: 'concept_food',
          label: 'Food Concept',
          variables: { category: 'food', emoji: '🍲', exemplar: 'Culinary Stimulus', expected_key: 'f' },
          stimulus_ref: { provider: 'asset_service', asset_id: 'food' }
        },
        {
          id: 'concept_car',
          label: 'Car Concept',
          variables: { category: 'car', emoji: '🚗', exemplar: 'Vehicle Stimulus', expected_key: 'd' },
          stimulus_ref: { provider: 'asset_service', asset_id: 'car' }
        }
      ];

      assumptions.push('Extracted dual concept categories: Food (🍲) and Vehicle (🚗).');
      assumptions.push('Mapped keyboard discrimination: [F] for Food, [D] for Car with millisecond latency logging.');
    } else {
      // Open-Domain Concept Parsing via Universal Heuristics
      const tokens = p.match(/\b[a-z]{3,}\b/g) || [];
      const stopWords = new Set(['the', 'and', 'for', 'with', 'that', 'make', 'create', 'study', 'experiment', 'participants', 'see', 'look', 'game', 'test', 'press']);
      const candidates = tokens.filter(t => !stopWords.has(t));
      
      const conceptA = candidates[0] || 'Target Alpha';
      const conceptB = candidates[1] || 'Target Beta';

      researchObjective = `Examine perception and response accuracy for ${conceptA} versus ${conceptB}.`;
      independentVariables = [
        { name: 'stimulus_condition', levels: [conceptA, conceptB] }
      ];

      const emojiA = assetService.getEmojiSync(conceptA) || '⭐';
      const emojiB = assetService.getEmojiSync(conceptB) || '💎';

      conditions = [
        {
          id: `cond_${conceptA.toLowerCase().replace(/\s+/g, '_')}`,
          label: conceptA.toUpperCase(),
          variables: { concept: conceptA, emoji: emojiA, expected_key: 'a' },
          stimulus_ref: { provider: 'asset_service', asset_id: conceptA }
        },
        {
          id: `cond_${conceptB.toLowerCase().replace(/\s+/g, '_')}`,
          label: conceptB.toUpperCase(),
          variables: { concept: conceptB, emoji: emojiB, expected_key: 'l' },
          stimulus_ref: { provider: 'asset_service', asset_id: conceptB }
        }
      ];

      assumptions.push(`Identified open-domain concepts: ${conceptA} (${emojiA}) and ${conceptB} (${emojiB}).`);
      assumptions.push('Created balanced dual-condition comparison with reaction time and accuracy metrics.');
    }

    // 4. Generate Trial Templates with Appropriate Question & Response Types
    if (isForestOrTree) {
      trialTemplates = [
        {
          id: 'template_size_judgment',
          question_template: 'Is this tree larger than average forest trees?',
          stimulus_template: '{{emoji}}',
          response_type: 'true_false_unknown',
          response_options: ['True', 'False', "I don't know"],
          branching: [
            { outcome: "I don't know", action: 'record_uncertainty_and_continue' },
            { outcome: 'default', action: 'next_trial' }
          ],
          metadata: { variable_probed: 'tree_size' }
        },
        {
          id: 'template_size_classification',
          question_template: 'How would you classify the physical size of this tree?',
          stimulus_template: '{{emoji}}',
          response_type: 'single_choice',
          response_options: ['Small', 'Medium', 'Large', 'Uncertain'],
          branching: [
            { outcome: 'Uncertain', action: 'record_uncertainty_and_continue' }
          ],
          correct_value_rule: '{{tree_size}}',
          metadata: { variable_probed: 'tree_size' }
        },
        {
          id: 'template_safety_rating',
          question_template: 'How safe would you feel taking shelter near this tree?',
          stimulus_template: '{{emoji}}',
          response_type: 'rating_scale',
          scale_min: 1,
          scale_max: 5,
          scale_labels: { min: 'Very Hazardous (1)', max: 'Extremely Safe (5)', mid: 'Neutral (3)' },
          metadata: { variable_probed: 'safety_perception' }
        }
      ];
    } else if (isDepressionOrClinical) {
      trialTemplates = [
        {
          id: 'template_sentence_agreement',
          question_template: 'How accurately does this statement describe your experience over the past 2 weeks?',
          stimulus_template: '{{statement}}',
          response_type: 'rating_scale',
          scale_min: 1,
          scale_max: 5,
          scale_labels: { min: 'Strongly Disagree (1)', max: 'Strongly Agree (5)', mid: 'Neutral (3)' },
          metadata: { domain: '{{domain}}' }
        },
        {
          id: 'template_frequency_evaluation',
          question_template: 'How often do you experience this thought pattern?',
          stimulus_template: '{{thought_pattern}}',
          response_type: 'single_choice',
          response_options: ['Not at all', 'Several days', 'More than half the days', 'Nearly every day', 'Prefer not to say'],
          branching: [
            { outcome: 'Prefer not to say', action: 'record_uncertainty_and_continue' }
          ],
          metadata: { domain: '{{domain}}' }
        }
      ];
    } else {
      // Multimodal Choice & Reaction Template
      trialTemplates = [
        {
          id: 'template_concept_classification',
          question_template: 'Identify the category of the presented stimulus:',
          stimulus_template: '{{emoji}}',
          response_type: 'single_choice',
          response_options: conditions.map(c => c.label).concat(["Uncertain / Can't Tell"]),
          correct_value_rule: '{{label}}',
          branching: [
            { outcome: "Uncertain / Can't Tell", action: 'record_uncertainty_and_continue' }
          ]
        },
        {
          id: 'template_speed_reaction',
          question_template: 'Respond immediately to the target stimulus:',
          stimulus_template: '{{emoji}}',
          response_type: 'keyboard_reaction',
          response_options: conditions.map(c => c.variables.expected_key || 'a'),
          metadata: { deadline_ms: 1500 }
        }
      ];
    }

    assumptions.push(`Synthesized ${trialTemplates.length} distinct trial templates spanning diverse response types (${trialTemplates.map(t => t.response_type).join(', ')}).`);
    assumptions.push('Asset resolution wired through decoupled AssetService (with live API, local cache, and future database hook).');

    // 5. Construct Complete Experiment Plan
    const plan: ExperimentPlan = {
      research_objective: researchObjective,
      assumptions,
      independent_variables: independentVariables,
      dependent_variables: ['choice', 'is_uncertain', 'reaction_time_ms', 'rating_score', 'condition_consistency'],
      conditions,
      trial_templates: trialTemplates,
      randomization: {
        strategy: 'balanced',
        total_trials: requestedTrials,
        repetitions_per_condition: Math.max(Math.floor(requestedTrials / conditions.length), 1),
        no_repeat_max: 3,
        seed: 42
      },
      presentation_skin: theme,
      data_provenance_schema: [
        'experiment_id',
        'experiment_version',
        'trial_id',
        'template_id',
        'stimulus_id',
        'condition',
        'condition_variables',
        'response_type',
        'response_value',
        'is_uncertain',
        'reaction_time_ms',
        'generation_source',
        'asset_source',
        'timestamp'
      ]
    };

    // 6. Build the Visual Node DAG
    const dsl = this.compilePlanToDSL(plan);

    return {
      dsl,
      plan,
      assumptions
    };
  }

  /**
   * Compiles an ExperimentPlan into a valid ExperimentDSL with complete visual node graph
   */
  public static compilePlanToDSL(plan: ExperimentPlan): ExperimentDSL {
    const slug = plan.research_objective.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 32) || 'research-study';
    const experimentId = `exp_${slug}_${Date.now().toString(36)}`;

    const nodes: DSLNode[] = [
      {
        id: 'node_start',
        type: 'flow_start',
        label: 'Experiment Entry',
        config: {},
        position: { x: 50, y: 180 }
      },
      {
        id: 'node_consent',
        type: 'presentation_text',
        label: 'Ethics & Informed Consent',
        config: {
          title: 'Research Study Consent',
          content_markdown: `Welcome to this cognitive research study.
Objective: ${plan.research_objective}
Participation is entirely voluntary. Your responses are anonymous and protected under standard academic confidentiality protocols.`,
          require_confirmation: true
        },
        position: { x: 260, y: 180 }
      },
      {
        id: 'node_instructions',
        type: 'presentation_text',
        label: 'Task Instructions',
        config: {
          title: 'Study Instructions',
          content_markdown: `Please observe each stimulus carefully.
Respond using the on-screen options or assigned keyboard keys.
If you are genuinely unsure, select "I don't know" or "Uncertain" where provided.`,
          continue_button_text: 'Begin Session'
        },
        position: { x: 470, y: 180 }
      },
      {
        id: 'node_calibration',
        type: 'timing_calibration',
        label: 'Display Benchmark',
        config: { sample_frames: 60 },
        position: { x: 680, y: 180 }
      },
      {
        id: 'node_trial_block',
        type: 'trial_template_block',
        label: 'Empirical Trial Block',
        config: {
          templates: plan.trial_templates,
          conditions: plan.conditions,
          randomization: plan.randomization
        },
        position: { x: 890, y: 180 }
      },
      {
        id: 'node_record',
        type: 'data_record_trial',
        label: 'Data Provenance Logger',
        config: {
          schema: plan.data_provenance_schema,
          buffer_locally: true
        },
        position: { x: 1100, y: 180 }
      },
      {
        id: 'node_debrief',
        type: 'presentation_text',
        label: 'Scientific Debriefing',
        config: {
          title: 'Study Complete',
          content_markdown: `Thank you for contributing to this behavioral research!
Your trial data, response distributions, and condition ratings have been recorded.`
        },
        position: { x: 1310, y: 180 }
      },
      {
        id: 'node_end',
        type: 'flow_end',
        label: 'Session Terminate',
        config: {},
        position: { x: 1520, y: 180 }
      }
    ];

    const edges: DSLEdge[] = [
      { id: 'e1', from: 'node_start', to: 'node_consent' },
      { id: 'e2', from: 'node_consent', to: 'node_instructions' },
      { id: 'e3', from: 'node_instructions', to: 'node_calibration' },
      { id: 'e4', from: 'node_calibration', to: 'node_trial_block' },
      { id: 'e5', from: 'node_trial_block', to: 'node_record' },
      { id: 'e6', from: 'node_record', to: 'node_debrief' },
      { id: 'e7', from: 'node_debrief', to: 'node_end' }
    ];

    const dsl: ExperimentDSL = {
      $schema: 'https://cognitivelab.ai/schemas/experiment-dsl.v1.json',
      experiment: {
        id: experimentId,
        slug,
        version: 1,
        title: plan.research_objective.length > 50 ? plan.research_objective.slice(0, 50) + '...' : plan.research_objective,
        description: plan.research_objective,
        created_at: new Date().toISOString(),
        author: {
          user_id: 'researcher_ai_planner',
          institution: 'CognitiveLab Science Platform'
        },
        reproducibility: {
          dsl_version: '1.2.0',
          target_runtime: 'browser_wasm_webgl'
        }
      },
      participant_settings: {
        allow_anonymous: true,
        enforce_fullscreen: false,
        minimum_display_hz: 60,
        device_allowlist: ['desktop', 'tablet'],
        required_inputs: ['keyboard', 'mouse']
      },
      consent_settings: {
        required: true,
        ethics_protocol_id: 'IRB-AI-EXP-2026',
        statement_text: 'Participation in this scientific study is anonymous and voluntary. You may withdraw at any time without penalty.',
        require_checkbox: true,
        minimum_age: 18
      },
      variables: {
        total_trials: { type: 'number', default: plan.randomization.total_trials, scope: 'global' },
        current_condition: { type: 'string', default: 'baseline', scope: 'trial' }
      },
      game_skin: {
        enabled: plan.presentation_skin !== 'academic-clean',
        theme: plan.presentation_skin,
        sound_enabled: true,
        hud_elements: {
          show_score: plan.presentation_skin !== 'academic-clean',
          show_streak: plan.presentation_skin !== 'academic-clean',
          show_progress_bar: true
        },
        score_rules: {
          correct_base_points: 100,
          streak_bonus_multiplier: 1.25,
          incorrect_penalty: 25,
          max_rt_for_bonus_ms: 1200
        }
      },
      plan,
      conditions: plan.conditions,
      trial_templates: plan.trial_templates,
      nodes,
      edges
    };

    return dsl;
  }

  /**
   * Applies structured modifications to an existing DSL without regenerating from scratch (Section 17)
   */
  public static applyStructuredPatch(
    dsl: ExperimentDSL, 
    instruction: string
  ): { dsl: ExperimentDSL; description: string } {
    const inst = instruction.toLowerCase().trim();
    const cloned: ExperimentDSL = JSON.parse(JSON.stringify(dsl));
    let changeSummary = '';

    // Operation 1: Modify Trial Count (e.g. "Change 30 trials to 60" or "Set trials to 48")
    const trialCountMatch = inst.match(/(?:change|set|update)?\s*(?:trial\s*count|trials?)\s*(?:to|=)?\s*(\d+)/i) ||
                            inst.match(/(\d+)\s*trials?/i);
    if (trialCountMatch) {
      const newCount = parseInt(trialCountMatch[1], 10);
      if (cloned.plan) {
        cloned.plan.randomization.total_trials = newCount;
        cloned.plan.assumptions.push(`Modified total trial count to ${newCount}.`);
      }
      if (cloned.variables?.total_trials) {
        cloned.variables.total_trials.default = newCount;
      }
      const trialBlockNode = cloned.nodes.find(n => n.type === 'trial_template_block');
      if (trialBlockNode && trialBlockNode.config.randomization) {
        trialBlockNode.config.randomization.total_trials = newCount;
      }
      changeSummary = `Updated total trials to ${newCount} without modifying experimental conditions.`;
      cloned.experiment.version += 1;
      return { dsl: cloned, description: changeSummary };
    }

    // Operation 2: Add "I don't know" / "Unknown" option (e.g. "Add an unknown option")
    if (inst.includes('unknown') || inst.includes("don't know") || inst.includes('uncertain')) {
      let addedCount = 0;
      if (cloned.trial_templates) {
        cloned.trial_templates.forEach(t => {
          if (t.response_options && !t.response_options.some(o => /unknown|uncertain|don't know/i.test(o))) {
            t.response_options.push("I don't know");
            if (!t.branching) t.branching = [];
            t.branching.push({ outcome: "I don't know", action: 'record_uncertainty_and_continue' });
            addedCount++;
          }
        });
      }
      if (cloned.plan) {
        cloned.plan.trial_templates = cloned.trial_templates || [];
        cloned.plan.assumptions.push('Added "I don\'t know" uncertainty response option to trial templates.');
      }
      changeSummary = `Injected "I don't know" option and uncertainty branching to ${addedCount} trial templates.`;
      cloned.experiment.version += 1;
      return { dsl: cloned, description: changeSummary };
    }

    // Operation 3: Toggle / Change Theme (e.g. "Make it feel like a space game", "Change skin to academic", "Forest theme")
    if (inst.includes('academic') || inst.includes('plain')) {
      cloned.game_skin.theme = 'academic-clean';
      cloned.game_skin.enabled = false;
      if (cloned.plan) cloned.plan.presentation_skin = 'academic-clean';
      changeSummary = 'Switched presentation layer to Academic Clean (standardized psychological testing format).';
      cloned.experiment.version += 1;
      return { dsl: cloned, description: changeSummary };
    } else if (inst.includes('forest') || inst.includes('nature') || inst.includes('tree')) {
      cloned.game_skin.theme = 'forest-adventure';
      cloned.game_skin.enabled = true;
      if (cloned.plan) cloned.plan.presentation_skin = 'forest-adventure';
      changeSummary = 'Switched presentation layer to Forest Adventure (nature theme, explorer HUD).';
      cloned.experiment.version += 1;
      return { dsl: cloned, description: changeSummary };
    } else if (inst.includes('space') || inst.includes('arcade')) {
      cloned.game_skin.theme = 'deep-space-arcade';
      cloned.game_skin.enabled = true;
      if (cloned.plan) cloned.plan.presentation_skin = 'deep-space-arcade';
      changeSummary = 'Switched presentation layer to Deep Space Arcade.';
      cloned.experiment.version += 1;
      return { dsl: cloned, description: changeSummary };
    }

    // Operation 4: Condition level modification (e.g. "Change small/medium/large to tiny/small/large")
    if (inst.includes('tiny')) {
      if (cloned.conditions) {
        const small = cloned.conditions.find(c => c.variables.tree_size === 'small' || c.id.includes('small'));
        if (small) {
          small.label = 'Tiny Tree';
          small.variables.tree_size = 'tiny';
          small.variables.visual_scale = 0.4;
        }
      }
      changeSummary = 'Patched condition levels: Renamed small level to "Tiny Tree" (scale 0.4).';
      cloned.experiment.version += 1;
      return { dsl: cloned, description: changeSummary };
    }

    // Fallback: update description
    cloned.experiment.description += ` | Note: ${instruction}`;
    cloned.experiment.version += 1;
    return { dsl: cloned, description: `Updated experiment metadata: "${instruction}".` };
  }
}
