import { z } from 'zod';

export const ExperimentMetadataSchema = z.object({
  id: z.string().min(1, 'Experiment ID is required'),
  slug: z.string().min(1, 'Slug is required'),
  version: z.number().int().positive(),
  title: z.string().min(1, 'Title is required'),
  description: z.string(),
  created_at: z.string(),
  author: z.object({
    user_id: z.string(),
    institution: z.string(),
  }),
  reproducibility: z.object({
    dsl_version: z.string(),
    target_runtime: z.string(),
    hash_sha256: z.string().optional(),
  }),
});

export const ParticipantSettingsSchema = z.object({
  allow_anonymous: z.boolean(),
  enforce_fullscreen: z.boolean(),
  minimum_display_hz: z.number().min(30).max(360),
  device_allowlist: z.array(z.string()),
  required_inputs: z.array(z.string()),
});

export const ConsentSettingsSchema = z.object({
  required: z.boolean(),
  ethics_protocol_id: z.string(),
  statement_text: z.string().min(10, 'Informed consent statement must be detailed'),
  require_checkbox: z.boolean(),
  minimum_age: z.number().int().min(0),
});

export const DSLNodeTypeEnum = z.enum([
  'flow_start',
  'flow_end',
  'presentation_text',
  'presentation_fixation',
  'presentation_stimulus',
  'presentation_question',
  'response_keyboard',
  'response_multimodal',
  'trial_template_block',
  'logic_condition',
  'logic_loop',
  'randomization_balanced_block',
  'game_reward',
  'timing_wait',
  'timing_calibration',
  'data_record_trial'
]);

export const DSLNodeSchema = z.object({
  id: z.string().min(1),
  type: DSLNodeTypeEnum,
  label: z.string(),
  config: z.record(z.any()),
  position: z.object({ x: z.number(), y: z.number() }).optional(),
});

export const DSLEdgeSchema = z.object({
  id: z.string().min(1),
  from: z.string().min(1),
  to: z.string().min(1),
  port: z.string().optional(),
  label: z.string().optional(),
});

export const ResponseTypeEnum = z.enum([
  'keyboard_reaction',
  'true_false_unknown',
  'single_choice',
  'multiple_choice',
  'rating_scale',
  'slider',
  'open_text'
]);

export const BranchRuleSchema = z.object({
  outcome: z.string(),
  action: z.enum(['next_trial', 'branch_node', 'record_uncertainty_and_continue']),
  target_node_id: z.string().optional(),
});

export const ExperimentConditionSchema = z.object({
  id: z.string(),
  label: z.string(),
  variables: z.record(z.any()),
  stimulus_ref: z.object({
    provider: z.string(),
    asset_id: z.string(),
    filter: z.record(z.any()).optional(),
  }).optional(),
});

export const TrialTemplateSchema = z.object({
  id: z.string(),
  question_template: z.string(),
  stimulus_template: z.string(),
  response_type: ResponseTypeEnum,
  response_options: z.array(z.string()).optional(),
  scale_min: z.number().optional(),
  scale_max: z.number().optional(),
  scale_labels: z.object({
    min: z.string(),
    max: z.string(),
    mid: z.string().optional(),
  }).optional(),
  correct_value_rule: z.string().optional(),
  branching: z.array(BranchRuleSchema).optional(),
  metadata: z.record(z.any()).optional(),
});

export const ExperimentPlanSchema = z.object({
  research_objective: z.string(),
  assumptions: z.array(z.string()),
  independent_variables: z.array(z.object({
    name: z.string(),
    levels: z.array(z.string()),
  })),
  dependent_variables: z.array(z.string()),
  conditions: z.array(ExperimentConditionSchema),
  trial_templates: z.array(TrialTemplateSchema),
  randomization: z.object({
    strategy: z.enum(['balanced', 'randomized', 'blocked']),
    total_trials: z.number().positive(),
    repetitions_per_condition: z.number().optional(),
    no_repeat_max: z.number().optional(),
    seed: z.number().optional(),
  }),
  presentation_skin: z.enum(['deep-space-arcade', 'academic-clean', 'retro-synth', 'forest-adventure', 'food-challenge']),
  data_provenance_schema: z.array(z.string()),
});

export const ExperimentDSLSchema = z.object({
  $schema: z.string().optional(),
  experiment: ExperimentMetadataSchema,
  participant_settings: ParticipantSettingsSchema,
  consent_settings: ConsentSettingsSchema,
  variables: z.record(
    z.object({
      type: z.enum(['string', 'number', 'boolean']),
      default: z.any(),
      scope: z.enum(['global', 'trial']),
    })
  ),
  game_skin: z.object({
    enabled: z.boolean(),
    theme: z.enum(['deep-space-arcade', 'academic-clean', 'retro-synth', 'forest-adventure', 'food-challenge']),
    sound_enabled: z.boolean(),
    hud_elements: z.object({
      show_score: z.boolean(),
      show_streak: z.boolean(),
      show_progress_bar: z.boolean(),
    }),
    score_rules: z.object({
      correct_base_points: z.number(),
      streak_bonus_multiplier: z.number(),
      incorrect_penalty: z.number(),
      max_rt_for_bonus_ms: z.number(),
    }),
  }),
  plan: ExperimentPlanSchema.optional(),
  conditions: z.array(ExperimentConditionSchema).optional(),
  trial_templates: z.array(TrialTemplateSchema).optional(),
  nodes: z.array(DSLNodeSchema).min(2, 'Experiment must contain at least start and end nodes'),
  edges: z.array(DSLEdgeSchema),
});
