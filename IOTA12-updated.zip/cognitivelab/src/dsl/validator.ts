import { ExperimentDSL, ValidationIssue } from '../types/dsl';
import { ExperimentDSLSchema } from './schema';

export class ExperimentValidator {
  public static validate(dsl: ExperimentDSL): {
    isValid: boolean;
    issues: ValidationIssue[];
  } {
    const issues: ValidationIssue[] = [];

    // TIER 1: Structural Validation with Zod
    const zodResult = ExperimentDSLSchema.safeParse(dsl);
    if (!zodResult.success) {
      zodResult.error.errors.forEach((err) => {
        issues.push({
          id: `STRUCT_${err.path.join('_')}`,
          severity: 'critical',
          category: 'structural',
          message: `${err.path.join('.')}: ${err.message}`,
          suggestion: 'Fix the field type or supply required parameters.',
        });
      });
    }

    // TIER 2: Logical & Scientific Linting
    const nodeMap = new Map(dsl.nodes.map((n) => [n.id, n]));
    const incomingEdgeCount = new Map<string, number>();
    const outgoingEdgeCount = new Map<string, number>();

    dsl.nodes.forEach((n) => {
      incomingEdgeCount.set(n.id, 0);
      outgoingEdgeCount.set(n.id, 0);
    });

    dsl.edges.forEach((edge) => {
      if (!nodeMap.has(edge.from)) {
        issues.push({
          id: `EDGE_ORPHAN_FROM_${edge.id}`,
          severity: 'critical',
          category: 'logical',
          message: `Edge "${edge.id}" originates from non-existent node "${edge.from}".`,
        });
      }
      if (!nodeMap.has(edge.to)) {
        issues.push({
          id: `EDGE_ORPHAN_TO_${edge.id}`,
          severity: 'critical',
          category: 'logical',
          message: `Edge "${edge.id}" points to non-existent node "${edge.to}".`,
        });
      }
      outgoingEdgeCount.set(edge.from, (outgoingEdgeCount.get(edge.from) || 0) + 1);
      incomingEdgeCount.set(edge.to, (incomingEdgeCount.get(edge.to) || 0) + 1);
    });

    // Node-specific logical tests
    dsl.nodes.forEach((node) => {
      // 1. Entry node checks
      if (node.type === 'flow_start') {
        if ((outgoingEdgeCount.get(node.id) || 0) === 0) {
          issues.push({
            id: `ERR_START_UNCONNECTED`,
            severity: 'critical',
            category: 'logical',
            nodeId: node.id,
            message: `Entry node "${node.label}" has no outgoing connections.`,
            suggestion: 'Connect an edge from Entry to the first experiment step.',
          });
        }
      }

      // 2. Terminal node checks
      if (node.type === 'flow_end') {
        if ((incomingEdgeCount.get(node.id) || 0) === 0) {
          issues.push({
            id: `ERR_END_UNREACHABLE`,
            severity: 'critical',
            category: 'logical',
            nodeId: node.id,
            message: `Experiment terminate node "${node.label}" is unreachable.`,
            suggestion: 'Connect the final debrief node to the terminate node.',
          });
        }
      }

      // 3. Disconnected nodes (not start)
      if (node.type !== 'flow_start' && (incomingEdgeCount.get(node.id) || 0) === 0) {
        issues.push({
          id: `ERR_NODE_DISCONNECTED_${node.id}`,
          severity: 'warning',
          category: 'logical',
          nodeId: node.id,
          message: `Node "${node.label}" has no incoming edges (it will never execute).`,
          suggestion: 'Wire an edge into this node or remove it.',
        });
      }

      // 4. Branch completeness
      if (node.type === 'logic_condition') {
        const outEdges = dsl.edges.filter((e) => e.from === node.id);
        const hasTrue = outEdges.some((e) => e.port === 'true' || e.label?.toLowerCase().includes('correct') || e.label?.toLowerCase().includes('true'));
        const hasFalse = outEdges.some((e) => e.port === 'false' || e.label?.toLowerCase().includes('wrong') || e.label?.toLowerCase().includes('false'));

        if (!hasTrue || !hasFalse) {
          issues.push({
            id: `ERR_BRANCH_INCOMPLETE_${node.id}`,
            severity: 'critical',
            category: 'logical',
            nodeId: node.id,
            message: `Condition "${node.label}" must have paths for both True and False outcomes.`,
            suggestion: 'Add outgoing edges for both correct and incorrect branches.',
          });
        }
      }

      // 5. Randomization balance check
      if (node.type === 'randomization_balanced_block') {
        const factors = node.config.factors || [];
        if (factors.length === 0) {
          issues.push({
            id: `ERR_EMPTY_STIMULUS_POOL_${node.id}`,
            severity: 'critical',
            category: 'logical',
            nodeId: node.id,
            message: `Randomization node "${node.label}" has no experimental factors configured.`,
            suggestion: 'Add condition factors (e.g. Red, Blue) to the factor matrix.',
          });
        }
      }

      // 6. Timing verification
      if (node.type === 'presentation_fixation') {
        const dur = node.config.duration_ms || 0;
        if (dur < 200) {
          issues.push({
            id: `WARN_FIXATION_TOO_SHORT_${node.id}`,
            severity: 'warning',
            category: 'timing',
            nodeId: node.id,
            message: `Fixation duration (${dur}ms) is unusually brief (<200ms).`,
            suggestion: 'Set fixation between 400ms and 800ms for stable foveal centering.',
          });
        }
      }

      // 7. Key mapping check for keyboard-only nodes
      if (node.type === 'response_keyboard') {
        const keys = node.config.allowed_keys || [];
        if (keys.length < 2) {
          issues.push({
            id: `WARN_FEW_KEYS_${node.id}`,
            severity: 'warning',
            category: 'logical',
            nodeId: node.id,
            message: `Keyboard node "${node.label}" specifies fewer than 2 keys for a 2AFC task.`,
            suggestion: 'Ensure both choice keys (e.g., "a" and "l") are specified.',
          });
        }
      }

      // 8. Trial Template block check
      if (node.type === 'trial_template_block') {
        const templates = node.config.templates || [];
        if (templates.length === 0) {
          issues.push({
            id: `ERR_EMPTY_TEMPLATES_${node.id}`,
            severity: 'critical',
            category: 'logical',
            nodeId: node.id,
            message: `Trial template block "${node.label}" contains no question templates.`,
            suggestion: 'Add at least one trial template with question and response definition.',
          });
        }
      }
    });

    // TIER 3: Research Plan, Conditions & Trial Template Validation
    if (dsl.conditions && dsl.conditions.length > 0) {
      const conditionIds = new Set<string>();
      dsl.conditions.forEach((c) => {
        if (conditionIds.has(c.id)) {
          issues.push({
            id: `ERR_DUPLICATE_CONDITION_${c.id}`,
            severity: 'critical',
            category: 'logical',
            message: `Duplicate condition ID detected: "${c.id}".`,
            suggestion: 'Assign unique IDs to each experimental condition.',
          });
        }
        conditionIds.add(c.id);
      });
    }

    if (dsl.trial_templates && dsl.trial_templates.length > 0) {
      dsl.trial_templates.forEach((template) => {
        if (!template.question_template || template.question_template.trim().length === 0) {
          issues.push({
            id: `ERR_EMPTY_QUESTION_${template.id}`,
            severity: 'critical',
            category: 'logical',
            message: `Trial template "${template.id}" has an empty question string.`,
            suggestion: 'Specify the question prompt or statement.',
          });
        }

        // Branch target check
        if (template.branching) {
          template.branching.forEach((branch) => {
            if (branch.action === 'branch_node' && branch.target_node_id && !nodeMap.has(branch.target_node_id)) {
              issues.push({
                id: `ERR_INVALID_BRANCH_TARGET_${template.id}`,
                severity: 'critical',
                category: 'logical',
                message: `Branch rule in template "${template.id}" points to non-existent node "${branch.target_node_id}".`,
                suggestion: 'Ensure target node ID exists in the experiment nodes graph.',
              });
            }
          });
        }
      });
    }

    const hasCritical = issues.some((i) => i.severity === 'critical');
    return {
      isValid: !hasCritical,
      issues,
    };
  }
}
